# Building AUREVIA from a fresh checkout

This document describes the supported clean-checkout path. It does not claim that a build has already passed; the first CI run is the verification step.

## Requirements

- JDK 17
- Gradle 8.7 (Android Gradle Plugin 8.6.1)
- Android SDK Platform 35 and Build Tools 35.0.0
- Android Studio or a compatible Android IDE such as CodeAssist

## Project root

Open/import the directory that contains **both** `settings.gradle.kts` and `app/build.gradle.kts`. Do not open the `app/` directory by itself. The repository root must contain:

- `settings.gradle.kts`
- `build.gradle.kts`
- `gradle.properties`
- `app/build.gradle.kts`
- `app/src/main/AndroidManifest.xml`

`local.properties` is machine-specific and intentionally ignored by Git. Android Studio/CodeAssist should create or manage it for the local SDK installation.

## Commands

From the repository root, with Gradle 8.7 available on PATH:

```bash
gradle --version
gradle --no-daemon assembleDebug
gradle --no-daemon lintDebug
gradle --no-daemon testDebugUnitTest
```

The debug APK, if the build succeeds, is written to `app/build/outputs/apk/debug/`.

## Continuous integration

`.github/workflows/android-ci.yml` provisions JDK 17, Android SDK Platform 35, Build Tools 35.0.0 and Gradle 8.7, then runs assemble, lint and unit-test tasks on pushes to any branch, pull requests targeting `main` or `master`, and manual dispatch. It uploads lint/test reports even on failure and uploads the debug APK only if all checks pass. A successful workflow is evidence of a CI build only; install and test the APK on a physical device before release. Dependabot is configured to check GitHub Actions and Gradle dependencies weekly.

## Secrets and Supabase

- Never commit `local.properties`, signing keys, service-role keys, passwords, or private tokens.
- A Supabase publishable/anon key is intended for client use only when Row Level Security and least-privilege policies are correctly configured. It is not a substitute for server-side authorization.
- Never put a Supabase service-role key in an Android app, Gradle file, workflow, or APK.
- Do not execute `supabase/schema.sql` or migrations against a live project blindly. Review migration order, back up production data, and test changes in a non-production project first.

## Supabase static guardrail

Run the static SQL contract check from the project root:

```bash
python3 scripts/check_supabase_schema.py
```

It checks declared public tables for an explicit RLS enable statement and verifies key published/approved property policy text. It does not execute SQL or prove policy correctness.

## Current verification status

This package restores the Android Gradle project configuration and adds a CI workflow. At packaging time, this environment did not have Gradle, an Android SDK, or network access to provision them, so no full Gradle build is claimed. The first GitHub Actions run must be checked for actual compiler, lint, and test results.

## Stage 2 unit tests

The `app/src/test/java/com/aurevia/app/FormValidationTest.kt` suite tests the same pure validation rules used by the property listing and tenant forms. Run it with:

```bash
gradle --no-daemon testDebugUnitTest
```

The GitHub Actions workflow runs this task after the debug assemble and lint steps. These tests do not contact Supabase and do not need credentials.
