# Stage 3 — Continuous Integration

## Changes

- Run the Android debug build, Android lint, and JVM unit tests in one GitHub Actions workflow.
- Trigger CI on pushes to any branch, pull requests targeting `main` or `master`, and manual workflow dispatch.
- Use least-privilege workflow permissions (`contents: read`) and cancel superseded runs on the same ref.
- Upload lint/test reports even when a verification command fails, so errors can be diagnosed from the Actions run.
- Upload the debug APK only when all verification tasks succeed.
- Add a concise GitHub Actions job summary with result, ref, commit, and checks.
- Add weekly Dependabot checks for GitHub Actions and Gradle dependencies.
- Add a pull-request checklist to encourage tests, device checks, and secret hygiene.

## Verification status

The workflow and supporting YAML were inspected locally and the ZIP archive was validated. This environment does not have Gradle or the Android SDK available, and it cannot run GitHub Actions. Therefore, **no successful full Android build, lint run, or Gradle test run is claimed**. The first Actions run on GitHub is the authoritative verification. Resolve any failures before treating the project as build-clean.

## Important limitation

The project does not include the Gradle wrapper (`gradlew` and `gradle/wrapper/`). CI currently provisions Gradle 8.7 explicitly. Adding a standard wrapper is recommended once the wrapper files can be generated from a trusted Gradle installation. Do not add a fabricated wrapper JAR.
