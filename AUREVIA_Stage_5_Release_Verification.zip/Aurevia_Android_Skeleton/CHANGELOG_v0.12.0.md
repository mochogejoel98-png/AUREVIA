# AUREVIA v0.12.0 — Tenant Management

## Implemented
- Property-scoped tenant list with active/former status, contact details, rent, lease dates, room, and notes.
- Tenant creation and ending a tenancy through database RPCs.
- Room occupancy changes are performed transactionally in Supabase; active tenancy is unique per room.
- Tenant table RLS restricts listing to the owner of the property. Direct tenant table writes are not granted.

## Live backend status
- The tenant migration was applied to Supabase project `muilsyuudpscpvandgnf` and the `property_tenants` table, RLS, and RPC signatures were checked directly.
- Android build and device-level tenant-flow testing are the owner's validation steps; a successful build is not claimed by this changelog.
