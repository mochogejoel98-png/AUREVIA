# AUREVIA v0.15.0 — Private Messaging

## Added
- Added a **Message property owner** action to approved public property details. Signed-in users can start or reopen a private conversation.
- Replaced the inbox placeholder with a live conversation list for the signed-in user, whether they are the requester or property owner.
- Added a conversation screen with chronological messages, sender labels, refresh/retry states, and a text composer.
- Added Supabase REST methods to start/reuse conversations, list conversations, load messages, and send messages.
- Included `owner_id` in the approved public listing query only to address a message to the correct owner; private address fields remain excluded.

## Security
- `property_conversations` and `property_messages` have Row Level Security enabled.
- Only a signed-in requester can start a conversation, and only for a published, approved property owned by the stated owner. Self-messaging is rejected.
- Only conversation participants can read messages; inserted messages must identify the authenticated sender.
- Anonymous access and client-side update/delete privileges are revoked. No service-role key or new API service was added.
- Messages are not encrypted end-to-end; users should not send passwords, payment PINs or sensitive identity documents.

## Database
- Migration: `supabase/migrations/20261101_property_messaging.sql`.
- Applied to connected Supabase project `muilsyuudpscpvandgnf`; table columns and policies were queried after applying.

## Verification limits
- ZIP integrity, source structure and XML parsing are checked before delivery.
- A full Android Gradle build, authentication-backed conversation test and on-device UI test have not been completed in this environment. Please build and test in CodeAssist before relying on this release.
