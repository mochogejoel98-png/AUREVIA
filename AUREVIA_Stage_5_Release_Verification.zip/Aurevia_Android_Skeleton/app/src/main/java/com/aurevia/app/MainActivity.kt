package com.aurevia.app

import android.app.Activity
import android.app.AlertDialog
import android.os.Bundle
import android.os.Build
import android.graphics.Typeface
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.View
import android.widget.*
import android.text.InputType
import java.text.NumberFormat
import java.util.Locale
import java.util.Calendar
import java.util.Date
import java.util.TimeZone
import java.text.SimpleDateFormat

class MainActivity : Activity() {
    private val ink = Color.rgb(16, 16, 16)
    private val gold = Color.rgb(212, 175, 102)
    private val ivory = Color.rgb(245, 243, 238)
    private val muted = Color.rgb(125, 123, 117)
    private val card = Color.WHITE
    private lateinit var page: LinearLayout
    private lateinit var title: TextView
    private lateinit var subtitle: TextView
    private var listingMode = "Rent"
    private var addStep = 0
    private val draft = mutableMapOf<String, String>()
    private val saved = linkedSetOf<String>()
    private var favoritesLoading = false
    private var favoritesLoaded = false
    private var favoritesError: String? = null
    private var favoriteActionBusy = false
    private var authBusy = false
    @Volatile private var sessionRestoreComplete = false
    private var currentScreen = "Home"
    private val remoteListings = mutableListOf<PropertyListing>()
    private var listingsLoading = false
    private var listingsLoaded = false
    private var listingsError: String? = null
    private var filterLocation = ""
    private var filterBudget: Double? = null
    private var filterType = "Any property"
    private var filterBedrooms = 0
    private val selectedPropertyPhotos = mutableListOf<android.net.Uri>()
    private var myProperties = emptyList<SupabaseAuth.OwnedProperty>()
    private var myPropertiesLoading = false
    private var myPropertiesLoaded = false
    private var myPropertiesError: String? = null
    private var portfolioSearch = ""
    private var portfolioStatus = "All statuses"
    private var portfolioSort = "Newest first"
    private var appointmentsLoading = false
    private var appointmentsLoaded = false
    private var myAppointments = emptyList<SupabaseAuth.ViewingAppointment>()
    private var incomingAppointments = emptyList<SupabaseAuth.ViewingAppointment>()
    private var myAppointmentsError: String? = null
    private var incomingAppointmentsError: String? = null
    private var appointmentActionBusy = false
    private var roomsProperty: SupabaseAuth.OwnedProperty? = null
    private var propertyRooms = emptyList<SupabaseAuth.RoomRecord>()
    private var roomsLoading = false
    private var roomsError: String? = null
    private var tenantsProperty: SupabaseAuth.OwnedProperty? = null
    private var propertyTenants = emptyList<SupabaseAuth.TenantRecord>()
    private var tenantsLoading = false
    private var tenantsError: String? = null
    private var facilitiesProperty: SupabaseAuth.OwnedProperty? = null
    private var propertyFacilities = emptyList<SupabaseAuth.FacilityRecord>()
    private var facilitiesLoading = false
    private var facilitiesError: String? = null
    private var financeProperty: SupabaseAuth.OwnedProperty? = null
    private var financialRecords = emptyList<SupabaseAuth.FinancialRecord>()
    private var financeLoading = false
    private var financeError: String? = null
    private var selectedListing: PropertyListing? = null
    private var conversations = emptyList<SupabaseAuth.PropertyConversation>()
    private var conversationsLoading = false
    private var conversationsError: String? = null
    private var activeConversation: SupabaseAuth.PropertyConversation? = null
    private var conversationMessages = emptyList<SupabaseAuth.PropertyMessage>()
    private var messagesLoading = false
    private var messagesError: String? = null
    private var messageSending = false
    private var verificationPropertyId: String? = null
    private var verificationDocumentType = "ownership_proof"
    private var verificationDocuments = emptyList<SupabaseAuth.VerificationDocument>()
    private var verificationLoading = false
    private var verificationError: String? = null
    private var moderationLoading = false
    private var moderationError: String? = null
    private var moderationProperties = emptyList<SupabaseAuth.ModerationProperty>()
    private var moderationReports = emptyList<SupabaseAuth.PropertyReport>()
    private var moderationDocuments = emptyList<SupabaseAuth.VerificationDocument>()
    private var moderationActionBusy = false
    private var propertyVideos = emptyList<SupabaseAuth.PropertyVideo>()
    private var propertyVideosLoading = false
    private var propertyVideosLoaded = false
    private var propertyVideosError: String? = null
    private var videoUploadPropertyId: String? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = ink
        window.navigationBarColor = ink
        window.decorView.systemUiVisibility = 0
        SupabaseAuth.initialize(applicationContext)
        Thread {
            try {
                SupabaseAuth.restoreSession()
            } catch (_: Exception) {
                // Keep the locally restored session available; data requests will show a retryable error.
            } finally {
                sessionRestoreComplete = true
                runOnUiThread {
                    if (currentScreen == "DASH" || currentScreen == "Appointments" || currentScreen == "My Drafts") {
                        showScreen(currentScreen)
                    }
                }
            }
        }.start()
        setContentView(R.layout.activity_main)
        if (Build.VERSION.SDK_INT >= 35) {
            // Keep content clear of system bars while supporting Android 15 edge-to-edge enforcement.
            window.setDecorFitsSystemWindows(false)
            val contentRoot = findViewById<View>(android.R.id.content)
            val initialLeft = contentRoot.paddingLeft
            val initialTop = contentRoot.paddingTop
            val initialRight = contentRoot.paddingRight
            val initialBottom = contentRoot.paddingBottom
            contentRoot.setOnApplyWindowInsetsListener { view, insets ->
                val bars = insets.getInsets(android.view.WindowInsets.Type.systemBars())
                view.setPadding(initialLeft, initialTop + bars.top, initialRight, initialBottom + bars.bottom)
                insets
            }
            contentRoot.requestApplyInsets()
        }
        title = findViewById(R.id.screenTitle)
        subtitle = findViewById(R.id.screenSubtitle)
        page = findViewById(R.id.pageContent)
        findViewById<Button>(R.id.navHome).setOnClickListener { showScreen("Home") }
        findViewById<Button>(R.id.navExplore).setOnClickListener { showScreen("Explore") }
        findViewById<Button>(R.id.navSaved).setOnClickListener { showScreen("Saved") }
        findViewById<Button>(R.id.navAdd).setOnClickListener { addStep = 0; showScreen("Add Property") }
        findViewById<Button>(R.id.navInbox).setOnClickListener { showScreen("Inbox") }
        findViewById<Button>(R.id.navProfile).setOnClickListener { showScreen("Profile") }
        showScreen("Home")
    }

    @Deprecated("Uses the system document picker for broad Android compatibility")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: android.content.Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 8042 && resultCode == RESULT_OK && data != null) {
            selectedPropertyPhotos.clear()
            val clip = data.clipData
            if (clip != null) {
                for (i in 0 until clip.itemCount) selectedPropertyPhotos.add(clip.getItemAt(i).uri)
            } else data.data?.let { selectedPropertyPhotos.add(it) }
            if (selectedPropertyPhotos.size > 12) {
                selectedPropertyPhotos.subList(12, selectedPropertyPhotos.size).clear()
                Toast.makeText(this, "A maximum of 12 photos can be selected.", Toast.LENGTH_LONG).show()
            }
            if (currentScreen == "Add Property") showScreen("Add Property")
        } else if (requestCode == 8043 && resultCode == RESULT_OK && data?.data != null) {
            val uri = data.data!!
            val propertyId = verificationPropertyId ?: return
            val type = verificationDocumentType
            Toast.makeText(this, "Uploading privately for moderator review…", Toast.LENGTH_LONG).show()
            Thread {
                val result = SupabaseAuth.uploadVerificationDocument(this, uri, propertyId, type)
                runOnUiThread {
                    Toast.makeText(this, result.message, Toast.LENGTH_LONG).show()
                    if (result.success) { verificationError = null; loadVerificationDocuments() }
                }
            }.start()
        } else if (requestCode == 8044 && resultCode == RESULT_OK && data?.data != null) {
            val uri = data.data!!
            val propertyId = videoUploadPropertyId ?: return
            val captionField = EditText(this).apply { hint = "Caption (optional)"; setSingleLine(true) }
            AlertDialog.Builder(this).setTitle("Caption your property tour")
                .setView(captionField)
                .setPositiveButton("Upload MP4") { _, _ ->
                    Toast.makeText(this, "Uploading video securely… keep AUREVIA open.", Toast.LENGTH_LONG).show()
                    Thread {
                        val result = SupabaseAuth.uploadPropertyVideo(this, uri, propertyId, captionField.text.toString())
                        runOnUiThread {
                            Toast.makeText(this, result.message, Toast.LENGTH_LONG).show()
                            if (result.success) {
                                propertyVideosLoaded = false
                                propertyVideosError = null
                                myPropertiesLoaded = false
                                if (currentScreen == "My Drafts") loadMyProperties()
                            }
                        }
                    }.start()
                }.setNegativeButton("Cancel", null).show()
        }
    }

    private fun showScreen(name: String) {
        currentScreen = name
        val ownerMode = name == "DASH" || name == "Appointments" || name == "My Drafts" || name == "Portfolio" || name == "Property Rooms" || name == "Property Tenants" || name == "Property Facilities" || name == "Property Finance" || name == "Verification" || name == "Moderation"
        val headerColor = if (ownerMode) Color.rgb(18, 91, 62) else ink
        window.statusBarColor = headerColor
        findViewById<View>(R.id.topHeader)?.setBackgroundColor(headerColor)
        findViewById<TextView>(R.id.brandName)?.setTextColor(if (ownerMode) Color.WHITE else gold)
        title.text = when (name) {
            "Home" -> "Find somewhere special."
            "Explore" -> "Explore properties"
            "Video Discovery" -> "Property video discovery"
            "Saved" -> "Your saved places"
            "Add Property" -> "List a property"
            "Inbox" -> "Your conversations"
            "Appointments" -> "Viewing appointments"
            "DASH" -> "Landlord DASH"
            "Portfolio" -> "Property portfolio"
            "Property Rooms" -> "Room management"
            "Property Tenants" -> "Tenant management"
            "Property Facilities" -> "Facilities & map"
            "Property Finance" -> "Financial records"
            "Verification" -> "Property verification"
            "Moderation" -> "Verification & moderation"
            "Conversation" -> "Messages"
            else -> "Your AUREVIA"
        }
        subtitle.text = when (name) {
            "Home" -> "A better way to find your place."
            "Explore" -> "Narrow down the places that feel right."
            "Video Discovery" -> "Watch tours. Find your next place."
            "Saved" -> "Keep the places you love together."
            "Add Property" -> "Share a property with people looking for a home."
            "My Drafts" -> "Your saved listings, visible only to your account."
            "Portfolio" -> "Search, filter and open management tools for every property you own."
            "Inbox" -> "Private conversations with property owners and prospective tenants."
            "Conversation" -> activeConversation?.propertyTitle ?: "Private property conversation"
            "Appointments" -> "Arrange visits and manage viewing requests."
            "DASH" -> "Your properties, visits and owner tools in one place."
            "Property Rooms" -> roomsProperty?.title ?: "Manage this property’s rooms."
            "Property Tenants" -> tenantsProperty?.title ?: "Manage tenants for this property."
            "Property Facilities" -> facilitiesProperty?.title ?: "Manage amenities and location details."
            "Property Finance" -> financeProperty?.title ?: "Track income and expenses for this property."
            "Verification" -> "Submit evidence privately and track its review status."
            "Moderation" -> "Review submitted listings, verification evidence and safety reports."
            else -> "Manage your profile and preferences."
        }
        page.removeAllViews()
        when (name) {
            "Home" -> homePage()
            "Explore" -> explorePage()
            "Video Discovery" -> videoDiscoveryPage()
            "Saved" -> savedPage()
            "Add Property" -> addPropertyPage()
            "My Drafts" -> myDraftsPage()
            "Portfolio" -> propertyPortfolioPage()
            "Inbox" -> inboxPage()
            "Appointments" -> appointmentsPage()
            "DASH" -> landlordDashboardPage()
            "Property Rooms" -> propertyRoomsPage()
            "Property Tenants" -> propertyTenantsPage()
            "Property Facilities" -> propertyFacilitiesPage()
            "Property Finance" -> propertyFinancePage()
            "Verification" -> verificationPage()
            "Moderation" -> moderationPage()
            "Conversation" -> propertyConversationPage()
            else -> profilePage()
        }
    }

    private fun homePage() {
        val search = EditText(this).apply {
            hint = "City, area or neighbourhood"
            setSingleLine(true)
            textSize = 14f
            setPadding(dp(14), 0, dp(14), 0)
            background = rounded(Color.WHITE, 14)
        }
        page.addView(search, params(match = true, height = 52, top = 12))
        val actions = row()
        actions.addView(actionButton("Search", true) {
            filterLocation = search.text.toString().trim()
            showScreen("Explore")
        }, weightedParams())
        actions.addView(actionButton("Buy", false) {
            listingMode = "Buy"; showScreen("Explore")
        }, weightedParams(left = 8))
        actions.addView(actionButton("Rent", false) {
            listingMode = "Rent"; showScreen("Explore")
        }, weightedParams(left = 8))
        page.addView(actions, params(match = true, top = 10))
        sectionLabel("DISCOVER AUREVIA")
        infoCard("A place that feels like yours", "Explore homes and properties for rent or sale. Search by location, budget and the details that matter to you.")
        sectionLabel("POPULAR SEARCHES")
        quickTile("Apartments", "Explore apartment listings") { showScreen("Explore") }
        quickTile("Family homes", "Find space for everyday living") { showScreen("Explore") }
        quickTile("Land and plots", "Explore land opportunities") { showScreen("Explore") }
        sectionLabel("FOR PROPERTY OWNERS")
        infoCard("Manage your properties with DASH", "Owners can manage multiple properties from one AUREVIA account and respond to viewing requests in one place.")
        page.addView(actionButton("Open landlord DASH", false) {
            if (SupabaseAuth.isSignedIn()) showScreen("DASH") else showScreen("Profile")
        }, params(match = true, height = 48, top = 8))
        sectionLabel("HOW IT WORKS")
        infoCard("Search • Compare • Connect", "Explore properties that have been published and approved for public display. Save places you like and review the details before contacting an owner.")
        page.addView(actionButton("Explore live properties", true) { showScreen("Explore") },
            params(match = true, height = 50, top = 12))
        page.addView(actionButton("Watch property video tours ▶", false) {
            propertyVideosLoaded = false; propertyVideosError = null; showScreen("Video Discovery")
        }, params(match = true, height = 48, top = 8))
        note("Only published and approved property listings are shown in Explore. A listing's publication approval is not a guarantee of ownership or availability.")
    }

    private fun explorePage() {
        val location = field("Location", filterLocation, "City, area or neighbourhood")
        val budget = field("Maximum budget", filterBudget?.toString() ?: "", "Enter maximum amount")
        budget.inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL
        sectionLabel("I WANT TO")
        val modeRow = row()
        modeRow.addView(actionButton("Rent", listingMode == "Rent") {
            listingMode = "Rent"; showScreen("Explore")
        }, weightedParams())
        modeRow.addView(actionButton("Buy", listingMode == "Buy") {
            listingMode = "Buy"; showScreen("Explore")
        }, weightedParams(left = 8))
        page.addView(modeRow, params(match = true, top = 4))
        sectionLabel("PROPERTY TYPE")
        val types = Spinner(this)
        val typeOptions = listOf("Any property", "Apartment", "House", "Studio", "Townhouse", "Land", "Commercial", "Other")
        types.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, typeOptions)
        types.setSelection(typeOptions.indexOf(filterType).coerceAtLeast(0))
        page.addView(types, params(match = true, height = 48))
        sectionLabel("BEDROOMS")
        val beds = Spinner(this)
        val bedOptions = listOf("Any", "1+", "2+", "3+", "4+")
        beds.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, bedOptions)
        beds.setSelection(bedOptions.indexOf(if (filterBedrooms == 0) "Any" else "$filterBedrooms+").coerceAtLeast(0))
        page.addView(beds, params(match = true, height = 48))
        page.addView(actionButton("Apply filters", true) {
            filterLocation = location.text.toString().trim()
            filterBudget = budget.text.toString().toDoubleOrNull()
            filterType = types.selectedItem?.toString() ?: "Any property"
            filterBedrooms = beds.selectedItem?.toString()?.replace("+", "")?.toIntOrNull() ?: 0
            renderListings(filteredRemoteListings())
        }, params(match = true, height = 50, top = 16))
        page.addView(actionButton("Refresh listings", false) { fetchLiveListings(force = true) },
            params(match = true, height = 46, top = 8))
        page.addView(actionButton("Discover properties by video ▶", true) {
            propertyVideosLoaded = false; propertyVideosError = null; showScreen("Video Discovery")
        }, params(match = true, height = 48, top = 8))
        sectionLabel("LIVE LISTINGS")
        renderListings(filteredRemoteListings())
        if (!listingsLoaded && !listingsLoading) fetchLiveListings()
    }

    private fun filteredRemoteListings(): List<PropertyListing> {
        return remoteListings.filter { listing ->
            listing.purpose == listingMode &&
                (filterLocation.isBlank() || listing.location.contains(filterLocation, true) || listing.title.contains(filterLocation, true)) &&
                (filterBudget == null || listing.price <= filterBudget!!) &&
                (filterType == "Any property" || listing.type.equals(filterType, true)) &&
                (filterBedrooms == 0 || listing.beds >= filterBedrooms)
        }
    }

    private fun fetchLiveListings(force: Boolean = false) {
        if (listingsLoading) return
        if (listingsLoaded && !force) {
            if (currentScreen == "Explore") renderListings(filteredRemoteListings())
            return
        }
        listingsLoading = true
        listingsError = null
        if (currentScreen == "Explore") renderListings(filteredRemoteListings())
        Thread {
            val result = SupabaseAuth.fetchPublishedProperties()
            val parsed = mutableListOf<PropertyListing>()
            var parseFailure: String? = null
            if (result.success) {
                try {
                    val array = org.json.JSONArray(result.body)
                    for (i in 0 until array.length()) {
                        val item = array.optJSONObject(i) ?: continue
                        val id = item.optString("id")
                        val name = item.optString("title").trim()
                        if (id.isBlank() || name.isBlank()) continue
                        val purposeValue = item.optString("purpose")
                        val purpose = if (purposeValue == "sale") "Buy" else "Rent"
                        val rawType = item.optString("property_type", "other")
                        val propertyType = rawType.replaceFirstChar { if (it.isLowerCase()) it.titlecase(Locale.getDefault()) else it.toString() }
                        val neighbourhood = item.optString("neighbourhood").trim()
                        val city = item.optString("city").trim()
                        val country = item.optString("country_name").trim()
                        val location = listOf(neighbourhood, city, country).filter { it.isNotBlank() }.distinct().joinToString(", ")
                        val price = item.optDouble("price", 0.0)
                        val currency = item.optString("currency_code", "").trim()
                        val rentPeriod = item.optString("rent_period").takeIf { it.isNotBlank() }
                        val amount = NumberFormat.getNumberInstance(Locale.getDefault()).format(price)
                        val priceLabel = if (purpose == "Rent") "$currency $amount / ${rentPeriod ?: "month"}" else "$currency $amount"
                        val latitude = if (item.isNull("latitude")) null else item.optDouble("latitude").takeIf { it in -90.0..90.0 }
                        val longitude = if (item.isNull("longitude")) null else item.optDouble("longitude").takeIf { it in -180.0..180.0 }
                        parsed.add(PropertyListing(id, name, location, purpose, propertyType, price, priceLabel,
                            item.optInt("bedrooms", 0), item.optDouble("bathrooms", 0.0), item.optString("description", ""), latitude, longitude, item.optString("owner_id")))
                    }
                } catch (e: Exception) {
                    parseFailure = "The server returned property data that could not be read. Please refresh."
                }
            }
            runOnUiThread {
                listingsLoading = false
                listingsLoaded = result.success && parseFailure == null
                if (result.success && parseFailure == null) {
                    remoteListings.clear()
                    remoteListings.addAll(parsed)
                    listingsError = null
                } else {
                    listingsError = parseFailure ?: result.message
                }
                if (currentScreen == "Explore") renderListings(filteredRemoteListings())
                else if (currentScreen == "Saved") showScreen("Saved")
            }
        }.start()
    }

    private fun renderListings(items: List<PropertyListing>) {
        val headingIndex = (0 until page.childCount).lastOrNull {
            val child = page.getChildAt(it)
            child is TextView && child.text.toString() == "LIVE LISTINGS"
        } ?: return
        while (page.childCount > headingIndex + 1) page.removeViewAt(headingIndex + 1)
        if (listingsLoading) {
            infoCard("Loading live properties", "Connecting to AUREVIA to retrieve published and approved listings…")
            return
        }
        if (listingsError != null) {
            infoCard("Couldn't load properties", listingsError ?: "Please try again.")
            page.addView(actionButton("Try again", true) { fetchLiveListings(force = true) },
                params(match = true, height = 48, top = 8))
            return
        }
        if (items.isEmpty()) {
            val message = if (remoteListings.isEmpty())
                "There are no publicly published and approved properties yet. New property submissions remain private drafts until an administrator reviews and approves them."
            else "No live listings match these filters. Try a different location, budget, property type or bedroom count."
            infoCard("No properties found", message)
            return
        }
        items.forEach { listing ->
            val box = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(dp(15), dp(14), dp(15), dp(13))
                background = rounded(Color.WHITE, 15)
            }
            box.addView(TextView(this).apply {
                text = if (listing.purpose == "Rent") "FOR RENT" else "FOR SALE"
                textSize = 10f; setTextColor(Color.rgb(142, 108, 49)); setTypeface(null, Typeface.BOLD)
            })
            box.addView(TextView(this).apply {
                text = listing.title; textSize = 17f; setTextColor(ink)
                setTypeface(null, Typeface.BOLD); setPadding(0, dp(6), 0, dp(3))
            })
            box.addView(TextView(this).apply {
                text = listing.location + "  •  " + listing.type
                textSize = 12f; setTextColor(muted)
            })
            box.addView(TextView(this).apply {
                text = listing.priceLabel; textSize = 15f; setTextColor(ink)
                setTypeface(null, Typeface.BOLD); setPadding(0, dp(9), 0, dp(8))
            })
            val controls = row()
            controls.addView(actionButton("View details", true) { showListingDetails(listing) }, weightedParams())
            controls.addView(actionButton(if (saved.contains(listing.id)) "Saved ✓" else "Save ♡", false) {
                toggleSaved(listing)
            }, weightedParams(left = 8))
            box.addView(controls, params(match = true, top = 8))
            page.addView(box, params(match = true, top = 9))
        }
    }

    private fun showListingDetails(listing: PropertyListing) {
        selectedListing = listing
        currentScreen = "Listing Details"
        title.text = "Property details"
        subtitle.text = listing.title
        renderListingDetails(listing, null, null)
        Thread {
            val result = SupabaseAuth.fetchPropertyFacilities(listing.id, ownerView = false)
            runOnUiThread {
                if (currentScreen == "Listing Details" && selectedListing?.id == listing.id) {
                    renderListingDetails(listing, if (result.success) result.items else emptyList(), if (result.success) null else result.message)
                }
            }
        }.start()
    }

    private fun renderListingDetails(listing: PropertyListing, facilities: List<SupabaseAuth.FacilityRecord>?, facilitiesMessage: String?) {
        page.removeAllViews()
        sectionLabel("PROPERTY DETAILS")
        infoCard(listing.title, "${listing.location}\n${listing.type} • ${listing.purpose}\n${listing.priceLabel}\n${listing.beds} bedrooms • ${listing.baths} bathrooms")
        infoCard("About this property", listing.description.ifBlank { "No description has been provided for this property." })
        page.addView(actionButton("Open location in Maps", true) {
            openPropertyMap(listing.latitude, listing.longitude, listing.title, listing.location)
        }, params(match = true, height = 48, top = 8))
        when {
            facilities == null && facilitiesMessage == null -> infoCard("Property facilities", "Loading facilities…")
            facilitiesMessage != null -> infoCard("Facilities unavailable", "The listing is still viewable. ${facilitiesMessage}")
            facilities.isNullOrEmpty() -> infoCard("Property facilities", "No facilities have been added to this listing yet.")
            else -> infoCard("Property facilities", facilities.joinToString("\n") { "• ${it.name} (${it.category.replaceFirstChar { c -> c.uppercase() }})" })
        }
        infoCard("Safety reminder", "This listing has been approved for publication on AUREVIA. Publication approval does not independently guarantee ownership, property condition or current availability. Verify the owner or agent and inspect the property before making any payment.")
        page.addView(actionButton("Report this listing", false) {
            if (!SupabaseAuth.isSignedIn()) {
                Toast.makeText(this, "Sign in before reporting a listing.", Toast.LENGTH_LONG).show()
                showScreen("Profile")
            } else showReportDialog(listing)
        }, params(match = true, height = 46, top = 10))
        page.addView(actionButton("Message property owner", true) {
            if (!SupabaseAuth.isSignedIn()) {
                Toast.makeText(this, "Sign in before messaging a property owner.", Toast.LENGTH_LONG).show()
                showScreen("Profile")
            } else startConversationWithOwner(listing)
        }, params(match = true, height = 50, top = 14))
        page.addView(actionButton("Request a viewing", true) {
            if (!SupabaseAuth.isSignedIn()) {
                Toast.makeText(this, "Sign in before requesting a property viewing.", Toast.LENGTH_LONG).show()
                showScreen("Profile")
            } else showViewingRequestForm(listing)
        }, params(match = true, height = 50, top = 14))
        page.addView(actionButton(if (saved.contains(listing.id)) "Remove from saved" else "Save property", true) {
            toggleSaved(listing)
            renderListingDetails(listing, facilities, facilitiesMessage)
        }, params(match = true, height = 50, top = 14))
        page.addView(actionButton("Back to Explore", false) { showScreen("Explore") }, params(match = true, height = 46, top = 8))
    }

    private fun videoDiscoveryPage() {
        sectionLabel("AUREVIA VIDEO TOURS")
        infoCard("See a property before you visit", "Short vertical MP4 tours help you explore homes and spaces. Videos are visible to everyone only when the linked property is published and approved.")
        page.addView(actionButton("Refresh video feed", false) {
            propertyVideosLoaded = false; propertyVideosError = null; loadPropertyVideos()
        }, params(match = true, height = 44, top = 8))
        if (propertyVideosLoading) {
            infoCard("Loading video tours", "Fetching published property videos securely…")
            return
        }
        if (propertyVideosError != null) {
            infoCard("Video feed unavailable", propertyVideosError ?: "Please try again.")
            page.addView(actionButton("Try again", true) { propertyVideosLoaded = false; loadPropertyVideos() },
                params(match = true, height = 46, top = 8))
            return
        }
        if (!propertyVideosLoaded) {
            infoCard("Preparing your feed", "Connecting to AUREVIA video discovery…")
            loadPropertyVideos()
            return
        }
        if (propertyVideos.isEmpty()) {
            infoCard("No public video tours yet", "Owners can open Profile → My property drafts and listings → Upload vertical property video. The video appears here when its property is published and approved.")
            page.addView(actionButton("Browse all properties", true) { showScreen("Explore") },
                params(match = true, height = 48, top = 8))
            return
        }
        propertyVideos.forEach { video ->
            val videoCard = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(dp(12), dp(12), dp(12), dp(14))
                background = rounded(Color.WHITE, 16)
            }
            videoCard.addView(TextView(this).apply {
                text = video.propertyTitle; textSize = 17f; setTextColor(ink); setTypeface(null, Typeface.BOLD)
            })
            videoCard.addView(TextView(this).apply {
                text = listOf(video.city, video.propertyType.replaceFirstChar { it.uppercase() }).filter { it.isNotBlank() }.joinToString(" • ")
                textSize = 12f; setTextColor(muted); setPadding(0, dp(4), 0, dp(6))
            })
            val player = android.widget.VideoView(this).apply {
                setBackgroundColor(Color.BLACK)
                setOnErrorListener { _, _, _ ->
                    Toast.makeText(this@MainActivity, "This video could not play. Refresh the feed and try again.", Toast.LENGTH_LONG).show()
                    true
                }
            }
            videoCard.addView(player, params(match = true, height = 390, top = 4))
            var playbackRequested = false
            val playButton = actionButton("▶ Play property tour", true) { }
            playButton.setOnClickListener {
                if (player.isPlaying) {
                    player.pause()
                    playButton.text = "▶ Play property tour"
                } else if (!playbackRequested) {
                    playbackRequested = true
                    playButton.text = "Loading video…"
                    player.setOnPreparedListener { media ->
                        media.isLooping = true
                        media.setVolume(0f, 0f)
                        player.start()
                        playButton.text = "Ⅱ Pause tour"
                    }
                    player.setVideoURI(android.net.Uri.parse(video.playbackUrl))
                } else {
                    player.start()
                    playButton.text = "Ⅱ Pause tour"
                }
            }
            // The video URL is fetched only when the user taps play; cards do not preload or autoplay videos.
            videoCard.addView(playButton, params(match = true, height = 44, top = 6))
            if (video.caption.isNotBlank()) videoCard.addView(TextView(this).apply {
                text = video.caption; textSize = 13f; setTextColor(ink); setPadding(0, dp(8), 0, dp(4))
            })
            val priceText = NumberFormat.getNumberInstance(Locale.getDefault()).format(video.price)
            videoCard.addView(TextView(this).apply {
                text = "${video.currency} $priceText  •  ${video.purpose.replaceFirstChar { it.uppercase() }}"
                textSize = 14f; setTextColor(ink); setTypeface(null, Typeface.BOLD); setPadding(0, dp(6), 0, dp(8))
            })
            videoCard.addView(actionButton("View property details", true) {
                val listing = remoteListings.firstOrNull { it.id == video.propertyId }
                if (listing != null) showListingDetails(listing) else {
                    Toast.makeText(this, "Open Explore to load the current listing details.", Toast.LENGTH_LONG).show()
                    showScreen("Explore")
                }
            }, params(match = true, height = 46, top = 4))
            page.addView(videoCard, params(match = true, top = 12))
        }
        note("Video tours use short-lived signed links from private storage. Only videos tied to published and approved listings are shown in this feed.")
    }

    private fun loadPropertyVideos() {
        if (propertyVideosLoading || propertyVideosLoaded) return
        propertyVideosLoading = true
        propertyVideosError = null
        Thread {
            val result = SupabaseAuth.fetchPropertyVideos()
            runOnUiThread {
                propertyVideosLoading = false
                propertyVideosLoaded = result.success
                propertyVideosError = if (result.success) null else result.message
                if (result.success) propertyVideos = result.items
                if (currentScreen == "Video Discovery") videoDiscoveryPage()
            }
        }.start()
    }

    private fun openPropertyMap(latitude: Double?, longitude: Double?, label: String, fallbackLocation: String) {
        val query = if (latitude != null && longitude != null) {
            "geo:$latitude,$longitude?q=$latitude,$longitude(${android.net.Uri.encode(label)})"
        } else {
            val search = listOf(label, fallbackLocation).filter { it.isNotBlank() }.joinToString(", ")
            "geo:0,0?q=${android.net.Uri.encode(search)}"
        }
        try {
            startActivity(android.content.Intent(android.content.Intent.ACTION_VIEW, android.net.Uri.parse(query)))
        } catch (_: Exception) {
            Toast.makeText(this, "No maps app is available. Install or enable a maps app and try again.", Toast.LENGTH_LONG).show()
        }
    }

    private fun toggleSaved(listing: PropertyListing) {
        if (!SupabaseAuth.isSignedIn()) {
            Toast.makeText(this, "Sign in to save properties to your AUREVIA account.", Toast.LENGTH_LONG).show()
            showScreen("Profile")
            return
        }
        if (favoriteActionBusy) return
        favoriteActionBusy = true
        val removing = saved.contains(listing.id)
        Thread {
            val result = if (removing) SupabaseAuth.removeFavorite(listing.id)
                         else SupabaseAuth.addFavorite(listing.id)
            runOnUiThread {
                favoriteActionBusy = false
                if (result.success) {
                    if (removing) saved.remove(listing.id) else saved.add(listing.id)
                    favoritesLoaded = true
                    favoritesError = null
                    Toast.makeText(this, result.message, Toast.LENGTH_SHORT).show()
                    when (currentScreen) {
                        "Saved" -> showScreen("Saved")
                        "Explore" -> showScreen("Explore")
                    }
                } else {
                    Toast.makeText(this, result.message, Toast.LENGTH_LONG).show()
                }
            }
        }.start()
    }

    private fun loadFavorites(force: Boolean = false) {
        if (!SupabaseAuth.isSignedIn()) return
        if (favoritesLoading || (favoritesLoaded && !force)) return
        favoritesLoading = true
        favoritesError = null
        Thread {
            val result = SupabaseAuth.fetchFavoriteIds()
            runOnUiThread {
                favoritesLoading = false
                favoritesLoaded = result.success
                if (result.success) {
                    saved.clear()
                    saved.addAll(result.propertyIds)
                    favoritesError = null
                } else {
                    favoritesError = result.message
                }
                if (currentScreen == "Saved") showScreen("Saved")
            }
        }.start()
    }

    private fun savedPage() {
        sectionLabel("SAVED PROPERTIES")
        if (!SupabaseAuth.isSignedIn()) {
            infoCard("Sign in to see your saved properties", "Your saved places are linked to your AUREVIA account and will be available when you sign in on another device.")
            page.addView(actionButton("Go to Profile", true) { showScreen("Profile") },
                params(match = true, height = 48, top = 10))
            return
        }
        if (favoritesError != null && !favoritesLoading) {
            infoCard("Couldn't load saved properties", favoritesError ?: "Please try again.")
            page.addView(actionButton("Try again", true) { loadFavorites(force = true) },
                params(match = true, height = 48, top = 8))
            return
        }
        if (!favoritesLoaded) {
            infoCard("Loading your saved properties", "Retrieving favorites linked to your AUREVIA account…")
            if (!favoritesLoading) loadFavorites()
            return
        }
        if (!listingsLoaded && !listingsLoading) {
            infoCard("Loading property details", "Your saved property IDs are ready. Loading the current public property catalogue…")
            fetchLiveListings()
            return
        }
        if (listingsLoading) {
            infoCard("Loading property details", "Please wait while AUREVIA retrieves the current property catalogue.")
            return
        }
        val items = remoteListings.filter { saved.contains(it.id) }
        if (items.isEmpty()) {
            infoCard("Nothing saved yet", "Explore published properties and tap Save to keep them in your AUREVIA account. Your saved list will sync when you sign in on another device.")
            page.addView(actionButton("Explore properties", true) { showScreen("Explore") },
                params(match = true, height = 48, top = 10))
        } else {
            items.forEach { listing ->
                infoCard(listing.title, "${listing.location}\n${listing.priceLabel}")
                val controls = row()
                controls.addView(actionButton("View", true) { showListingDetails(listing) }, weightedParams())
                controls.addView(actionButton("Remove", false) {
                    toggleSaved(listing)
                }, weightedParams(left = 8))
                page.addView(controls, params(match = true, top = 5))
            }
        }
        page.addView(actionButton("Refresh saved properties", false) {
            favoritesLoaded = false
            loadFavorites(force = true)
        }, params(match = true, height = 44, top = 10))
        note("Saved properties are stored in your AUREVIA account. Only the signed-in account can read or change its favorites.")
    }

    private fun addPropertyPage() {
        sectionLabel("PROPERTY DETAILS  •  STEP ${addStep + 1} OF 3")
        when (addStep) {
            0 -> {
                val purpose = Spinner(this)
                purpose.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, listOf("For rent", "For sale"))
                page.addView(label("Listing purpose")); page.addView(purpose, params(match = true, height = 48))
                val type = Spinner(this)
                type.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, listOf("Apartment", "House", "Studio", "Townhouse", "Land", "Commercial"))
                page.addView(label("Property type")); page.addView(type, params(match = true, height = 48, top = 8))
                val titleField = field("Property title", draft["title"] ?: "", "e.g. Bright 2-bedroom apartment")
                val country = field("Country", draft["country"] ?: "Kenya", "Country name")
                val countryCode = field("Country code", draft["country_code"] ?: "KE", "2-letter code, e.g. KE")
                val city = field("City", draft["city"] ?: "", "City or town")
                val area = field("Neighbourhood / area", draft["area"] ?: "", "Area (optional)")
                val latitude = field("Latitude (optional)", draft["latitude"] ?: "", "e.g. -0.0917")
                latitude.inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL or InputType.TYPE_NUMBER_FLAG_SIGNED
                val longitude = field("Longitude (optional)", draft["longitude"] ?: "", "e.g. 34.7680")
                longitude.inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL or InputType.TYPE_NUMBER_FLAG_SIGNED
                page.addView(actionButton("Continue", true) {
                    val titleText = titleField.text.toString().trim()
                    val cityText = city.text.toString().trim()
                    val cc = countryCode.text.toString().trim().uppercase()
                    val latText = latitude.text.toString().trim()
                    val lonText = longitude.text.toString().trim()
                    val validationError = FormValidation.validatePropertyLocation(
                        titleText, country.text.toString(), cc, cityText, latText, lonText
                    )
                    if (validationError != null) {
                        Toast.makeText(this, validationError, Toast.LENGTH_LONG).show()
                        return@actionButton
                    }
                    draft["title"] = titleText
                    draft["country"] = country.text.toString().trim()
                    draft["country_code"] = cc
                    draft["city"] = cityText
                    draft["area"] = area.text.toString().trim()
                    draft["latitude"] = latText
                    draft["longitude"] = lonText
                    draft["purpose"] = purpose.selectedItem.toString()
                    draft["type"] = type.selectedItem.toString()
                    addStep = 1; showScreen("Add Property")
                }, params(match = true, height = 50, top = 18))
            }
            1 -> {
                val price = field("Price", draft["price"] ?: "", "Amount")
                price.inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL
                val currency = field("Currency code", draft["currency"] ?: "KES", "3-letter code, e.g. KES")
                val period = Spinner(this)
                period.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, listOf("Per month", "Per week", "Total price"))
                page.addView(label("Price period"))
                page.addView(period, params(match = true, height = 48))
                val bedrooms = field("Bedrooms", draft["bedrooms"] ?: "", "Number of bedrooms")
                bedrooms.inputType = InputType.TYPE_CLASS_NUMBER
                val bathrooms = field("Bathrooms", draft["bathrooms"] ?: "", "Number of bathrooms")
                bathrooms.inputType = InputType.TYPE_CLASS_NUMBER
                val description = field("Description", draft["description"] ?: "", "Describe the property")
                description.minLines = 3
                description.gravity = Gravity.TOP
                // field() already attaches each EditText to the page. Do not add them again.
                page.addView(actionButton("Continue", true) {
                    val amountText = price.text.toString()
                    val currencyCode = currency.text.toString().trim().uppercase()
                    val validationError = FormValidation.validatePrice(amountText, currencyCode)
                    if (validationError != null) {
                        Toast.makeText(this, validationError, Toast.LENGTH_LONG).show()
                        return@actionButton
                    }
                    draft["price"] = amountText
                    draft["currency"] = currencyCode
                    draft["price_period"] = period.selectedItem.toString()
                    draft["bedrooms"] = bedrooms.text.toString()
                    draft["bathrooms"] = bathrooms.text.toString()
                    draft["description"] = description.text.toString()
                    addStep = 2; showScreen("Add Property")
                }, params(match = true, height = 50, top = 18))
                page.addView(actionButton("Back", false) { addStep = 0; showScreen("Add Property") }, params(match = true, height = 46, top = 8))
            }
            else -> {
                infoCard("Add property photos", "Choose up to 12 JPEG, PNG or WebP images. Each image must be 10 MB or smaller. Photos are uploaded to your private owner folder and shown publicly only if the listing is approved and published.")
                page.addView(actionButton("Choose photos (${selectedPropertyPhotos.size}/12)", false) {
                    val intent = android.content.Intent(android.content.Intent.ACTION_OPEN_DOCUMENT).apply {
                        addCategory(android.content.Intent.CATEGORY_OPENABLE)
                        type = "image/*"
                        putExtra(android.content.Intent.EXTRA_ALLOW_MULTIPLE, true)
                        addFlags(android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION)
                    }
                    startActivityForResult(intent, 8042)
                }, params(match = true, height = 48, top = 8))
                if (selectedPropertyPhotos.isNotEmpty()) {
                    val previewLabel = TextView(this).apply { text = "SELECTED PHOTOS (${selectedPropertyPhotos.size})"; textSize = 11f; setTextColor(muted); setPadding(0, dp(12), 0, dp(4)) }
                    page.addView(previewLabel)
                    val strip = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
                    val scroll = HorizontalScrollView(this).apply { isHorizontalScrollBarEnabled = false; addView(strip) }
                    selectedPropertyPhotos.forEachIndexed { index, uri ->
                        val thumb = ImageView(this).apply {
                            scaleType = android.widget.ImageView.ScaleType.CENTER_CROP
                            background = rounded(Color.LTGRAY, 10)
                            try { setImageURI(uri) } catch (_: Exception) { setBackgroundColor(Color.LTGRAY) }
                            contentDescription = "Selected property photo ${index + 1}"
                        }
                        strip.addView(thumb, LinearLayout.LayoutParams(dp(92), dp(92)).apply { marginEnd = dp(8) })
                    }
                    page.addView(scroll, params(match = true, height = 100, top = 4))
                    page.addView(actionButton("Clear selected photos", false) { selectedPropertyPhotos.clear(); showScreen("Add Property") }, params(match = true, height = 42, top = 4))
                } else {
                    note("No photos selected yet. Choose photos to see previews here before saving.")
                }
                infoCard("Review and save", "Your listing will be saved as a private draft. It will not appear publicly until it has been reviewed and approved. You can save without photos and add them later.")
                page.addView(actionButton("Save property draft", true) {
                    if (!SupabaseAuth.isSignedIn()) {
                        Toast.makeText(this, "Please sign in from Profile before adding a property.", Toast.LENGTH_LONG).show()
                        showScreen("Profile")
                        return@actionButton
                    }
                    val amount = draft["price"]?.toDoubleOrNull()
                    val beds = draft["bedrooms"]?.toIntOrNull()
                    val baths = draft["bathrooms"]?.toDoubleOrNull()
                    if (amount == null || draft["title"].isNullOrBlank() || draft["city"].isNullOrBlank()) {
                        Toast.makeText(this, "Some required details are missing. Please go back and check the form.", Toast.LENGTH_LONG).show()
                        return@actionButton
                    }
                    val rentPeriod = when (draft["price_period"]) {
                        "Per month" -> "month"
                        "Per week" -> "week"
                        else -> null
                    }
                    val purpose = if (draft["purpose"] == "For sale") "sale" else "rent"
                    val propertyType = (draft["type"] ?: "other").lowercase()
                    val payload = org.json.JSONObject().apply {
                        put("owner_id", SupabaseAuth.currentUserId())
                        put("purpose", purpose)
                        put("property_type", propertyType)
                        put("title", draft["title"])
                        put("description", draft["description"] ?: "")
                        put("country_code", draft["country_code"] ?: "KE")
                        put("country_name", draft["country"] ?: "Kenya")
                        put("city", draft["city"])
                        put("neighbourhood", draft["area"] ?: "")
                        draft["latitude"]?.toDoubleOrNull()?.let { put("latitude", it) }
                        draft["longitude"]?.toDoubleOrNull()?.let { put("longitude", it) }
                        put("currency_code", draft["currency"] ?: "KES")
                        put("price", amount)
                        if (rentPeriod != null) put("rent_period", rentPeriod)
                        if (beds != null) put("bedrooms", beds)
                        if (baths != null) put("bathrooms", baths)
                        put("listing_status", "draft")
                        put("review_status", "pending")
                    }
                    if (authBusy) return@actionButton
                    authBusy = true
                    Toast.makeText(this, "Saving your property…", Toast.LENGTH_SHORT).show()
                    Thread {
                        val result = SupabaseAuth.createProperty(payload)
                        if (result.success && !result.propertyId.isNullOrBlank() && selectedPropertyPhotos.isNotEmpty()) {
                            var uploaded = 0
                            var photoError: String? = null
                            selectedPropertyPhotos.toList().forEachIndexed { index, uri ->
                                val photo = SupabaseAuth.uploadPropertyPhoto(applicationContext, uri, result.propertyId, index)
                                if (photo.success) uploaded++ else if (photoError == null) photoError = photo.message
                            }
                            runOnUiThread {
                                authBusy = false
                                Toast.makeText(this, if (photoError == null) "Draft saved. $uploaded photo(s) uploaded successfully." else "Draft saved. $uploaded photo(s) uploaded; one or more failed: $photoError", Toast.LENGTH_LONG).show()
                                draft.clear(); selectedPropertyPhotos.clear(); addStep = 0; showScreen("Profile")
                            }
                        } else {
                            runOnUiThread {
                                authBusy = false
                                Toast.makeText(this, if (result.success && selectedPropertyPhotos.isNotEmpty()) "Draft saved, but the server did not return its ID. Photos were not uploaded." else result.message, Toast.LENGTH_LONG).show()
                                if (result.success) { draft.clear(); selectedPropertyPhotos.clear(); addStep = 0; showScreen("Profile") }
                            }
                        }
                    }.start()
                }, params(match = true, height = 50, top = 16))
                page.addView(actionButton("Back", false) { addStep = 1; showScreen("Add Property") }, params(match = true, height = 46, top = 8))
                note("This saves a private draft to your AUREVIA account. It is not published automatically.")
            }
        }
    }

    private fun loadMyProperties() {
        if (myPropertiesLoading) return
        if (!sessionRestoreComplete) {
            myPropertiesError = "The secure sign-in check has not finished. Leave DASH open and tap Refresh dashboard again."
            myPropertiesLoaded = true
            if (currentScreen == "DASH") landlordDashboardPage()
            if (currentScreen == "My Drafts") myDraftsPage()
            if (currentScreen == "Portfolio") propertyPortfolioPage()
            return
        }
        if (!SupabaseAuth.isSignedIn()) {
            myPropertiesError = "No active Supabase access session is available. Open Profile, sign in again, then return to DASH."
            myPropertiesLoaded = true
            if (currentScreen == "DASH") landlordDashboardPage()
            if (currentScreen == "My Drafts") myDraftsPage()
            if (currentScreen == "Portfolio") propertyPortfolioPage()
            return
        }
        myPropertiesLoading = true
        myPropertiesError = null
        Thread {
            val result = try { SupabaseAuth.fetchMyProperties() }
                catch (e: Exception) { SupabaseAuth.OwnedPropertiesResult(false, emptyList(), "${e.javaClass.simpleName}: ${e.message ?: "Unknown request error"}") }
            runOnUiThread {
                myPropertiesLoading = false
                myPropertiesLoaded = true
                myPropertiesError = if (result.success) null else result.message
                if (result.success) myProperties = result.items
                if (currentScreen == "My Drafts") showScreen("My Drafts")
                if (currentScreen == "Portfolio") showScreen("Portfolio")
                if (currentScreen == "DASH") showScreen("DASH")
            }
        }.start()
    }

    private fun myDraftsPage() {
        sectionLabel("MY PROPERTIES")
        if (!SupabaseAuth.isSignedIn()) {
            infoCard("Sign in required", "Sign in to the same AUREVIA account you used when saving the property.")
            page.addView(actionButton("Go to Profile", true) { showScreen("Profile") }, params(match = true, height = 48, top = 12))
            return
        }
        if (myPropertiesLoading) infoCard("Loading your properties", "Checking your private AUREVIA listings…")
        else if (myPropertiesError != null) {
            infoCard("Couldn't load your properties", myPropertiesError ?: "Please try again.")
            page.addView(actionButton("Try again", true) { loadMyProperties() }, params(match = true, height = 48, top = 10))
        } else if (myProperties.isEmpty()) {
            infoCard("No saved properties found", "This account has no property records yet. Check that you are signed in with the same email used when saving your draft.")
        } else {
            myProperties.forEach { item ->
                val state = if (item.status == "draft") "Draft • ${item.reviewStatus}" else "${item.status} • ${item.reviewStatus}"
                infoCard(item.title, "${item.city}\n$state\nCreated: ${item.createdAt.take(10)}\nPhotos: ${item.photoUrls.size}")
                page.addView(actionButton("Upload vertical property video", true) {
                    if (!SupabaseAuth.isSignedIn()) {
                        Toast.makeText(this, "Sign in before uploading a video.", Toast.LENGTH_LONG).show()
                    } else {
                        videoUploadPropertyId = item.id
                        val intent = android.content.Intent(android.content.Intent.ACTION_OPEN_DOCUMENT).apply {
                            addCategory(android.content.Intent.CATEGORY_OPENABLE); type = "video/mp4"
                        }
                        startActivityForResult(intent, 8044)
                    }
                }, params(match = true, height = 44, top = 4))
                page.addView(actionButton("Verify ownership / authorization", false) {
                    chooseVerificationDocument(item.id)
                }, params(match = true, height = 44, top = 4))
                if (item.photoUrls.isNotEmpty()) {
                    val strip = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
                    val scroll = HorizontalScrollView(this).apply { isHorizontalScrollBarEnabled = false; addView(strip) }
                    item.photoUrls.forEachIndexed { photoIndex, photoUrl ->
                        val image = ImageView(this).apply { scaleType = ImageView.ScaleType.CENTER_CROP; background = rounded(Color.LTGRAY, 10); contentDescription = "Uploaded property photo ${photoIndex + 1}" }
                        strip.addView(image, LinearLayout.LayoutParams(dp(112), dp(88)).apply { marginEnd = dp(8) })
                        Thread {
                            try {
                                val connection = (java.net.URL(photoUrl).openConnection() as java.net.HttpURLConnection).apply { connectTimeout = 10000; readTimeout = 15000 }
                                val bitmap = try { connection.inputStream.use { android.graphics.BitmapFactory.decodeStream(it) } } finally { connection.disconnect() }
                                if (bitmap != null) runOnUiThread { if (currentScreen == "My Drafts") image.setImageBitmap(bitmap) }
                            } catch (_: Exception) { }
                        }.start()
                    }
                    page.addView(scroll, params(match = true, height = 96, top = 6))
                }
            }
        }
        page.addView(actionButton("Open property portfolio", true) { showScreen("Portfolio"); if (!myPropertiesLoaded || myPropertiesError != null) loadMyProperties() }, params(match = true, height = 46, top = 10))
        page.addView(actionButton("Refresh", false) { myProperties = emptyList(); myPropertiesError = null; myPropertiesLoaded = false; loadMyProperties() }, params(match = true, height = 46, top = 8))
        note("Drafts are stored in your AUREVIA account database, not in your phone's Gallery or Downloads. Only this signed-in owner account can see unpublished drafts.")
    }

    private fun propertyPortfolioPage() {
        sectionLabel("MULTI-PROPERTY WORKSPACE")
        if (!SupabaseAuth.isSignedIn()) {
            infoCard("Sign in required", "Sign in to view and manage properties attached to your AUREVIA account.")
            page.addView(actionButton("Go to Profile", true) { showScreen("Profile") }, params(match = true, height = 48, top = 10))
            return
        }
        val total = myProperties.size
        val published = myProperties.count { it.status.equals("published", true) }
        val drafts = myProperties.count { it.status.equals("draft", true) }
        val inReview = myProperties.count { it.reviewStatus.equals("pending", true) }
        val metrics = row()
        metrics.addView(dashMetricCard("Total", total.toString(), "Owned listings"), weightedParams())
        metrics.addView(dashMetricCard("Published", published.toString(), "Live status"), weightedParams(left = 7))
        page.addView(metrics, params(match = true, top = 6))
        val metrics2 = row()
        metrics2.addView(dashMetricCard("Drafts", drafts.toString(), "Not public"), weightedParams())
        metrics2.addView(dashMetricCard("In review", inReview.toString(), "Awaiting review"), weightedParams(left = 7))
        page.addView(metrics2, params(match = true, top = 7))
        val search = EditText(this).apply {
            setSingleLine(true); hint = "Search by property name or city"; textSize = 14f
            setText(portfolioSearch); setPadding(dp(14), dp(10), dp(14), dp(10)); background = rounded(Color.WHITE, 12)
        }
        page.addView(search, params(match = true, height = 48, top = 14))
        val filters = row()
        val statusSpinner = Spinner(this)
        val statusOptions = listOf("All statuses", "Published", "Draft", "Pending review", "Approved", "Rejected")
        statusSpinner.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, statusOptions)
        statusSpinner.setSelection(statusOptions.indexOf(portfolioStatus).coerceAtLeast(0))
        filters.addView(statusSpinner, LinearLayout.LayoutParams(0, dp(46), 1f))
        val sortSpinner = Spinner(this)
        val sortOptions = listOf("Newest first", "Oldest first", "Name A–Z", "Name Z–A")
        sortSpinner.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, sortOptions)
        sortSpinner.setSelection(sortOptions.indexOf(portfolioSort).coerceAtLeast(0))
        filters.addView(sortSpinner, LinearLayout.LayoutParams(0, dp(46), 1f).apply { marginStart = dp(8) })
        page.addView(filters, params(match = true, top = 8))
        val resultsHost = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        page.addView(resultsHost, params(match = true, top = 8))
        fun renderResults() {
            portfolioSearch = search.text.toString()
            portfolioStatus = statusOptions[statusSpinner.selectedItemPosition.coerceIn(statusOptions.indices)]
            portfolioSort = sortOptions[sortSpinner.selectedItemPosition.coerceIn(sortOptions.indices)]
            resultsHost.removeAllViews()
            if (myPropertiesLoading) {
                resultsHost.addView(buildInfoCard("Loading portfolio", "Fetching your property records securely…"), params(match = true, top = 7)); return
            }
            if (myPropertiesError != null) {
                resultsHost.addView(buildInfoCard("Portfolio unavailable", myPropertiesError ?: "Please retry."), params(match = true, top = 7))
                resultsHost.addView(actionButton("Retry loading properties", true) { myPropertiesLoaded = false; myPropertiesError = null; loadMyProperties() }, params(match = true, height = 44, top = 6)); return
            }
            val query = portfolioSearch.trim().lowercase(Locale.getDefault())
            var filtered = myProperties.filter { item ->
                val matchesQuery = query.isBlank() || item.title.lowercase(Locale.getDefault()).contains(query) || item.city.lowercase(Locale.getDefault()).contains(query)
                val matchesStatus = when (portfolioStatus) {
                    "Published" -> item.status.equals("published", true)
                    "Draft" -> item.status.equals("draft", true)
                    "Pending review" -> item.reviewStatus.equals("pending", true)
                    "Approved" -> item.reviewStatus.equals("approved", true)
                    "Rejected" -> item.reviewStatus.equals("rejected", true)
                    else -> true
                }
                matchesQuery && matchesStatus
            }
            filtered = when (portfolioSort) {
                "Oldest first" -> filtered.sortedBy { it.createdAt }
                "Name A–Z" -> filtered.sortedBy { it.title.lowercase(Locale.getDefault()) }
                "Name Z–A" -> filtered.sortedByDescending { it.title.lowercase(Locale.getDefault()) }
                else -> filtered.sortedByDescending { it.createdAt }
            }
            resultsHost.addView(TextView(this).apply {
                text = "${filtered.size} of ${myProperties.size} properties"; textSize = 12f; setTextColor(muted); setPadding(dp(2), dp(4), 0, dp(8))
            })
            if (filtered.isEmpty()) {
                resultsHost.addView(buildInfoCard("No matching properties", if (myProperties.isEmpty()) "Add your first property to start building your portfolio." else "Try a different search or status filter."), params(match = true, top = 7))
                if (myProperties.isEmpty()) resultsHost.addView(actionButton("Add a property", true) { addStep = 0; showScreen("Add Property") }, params(match = true, height = 46, top = 8))
                return
            }
            filtered.forEach { property ->
                val status = if (property.status.equals("published", true)) "PUBLISHED" else property.reviewStatus.uppercase(Locale.getDefault())
                val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(14), dp(13), dp(14), dp(13)); background = rounded(Color.WHITE, 15) }
                val header = row()
                header.addView(TextView(this).apply { text = property.title.ifBlank { "Untitled property" }; textSize = 15f; setTextColor(ink); setTypeface(null, Typeface.BOLD) }, LinearLayout.LayoutParams(0, -2, 1f))
                header.addView(TextView(this).apply { text = status; textSize = 9f; setTypeface(null, Typeface.BOLD); setTextColor(when(status) { "PUBLISHED", "APPROVED" -> Color.rgb(22,125,78); "REJECTED" -> Color.rgb(190,65,58); else -> Color.rgb(176,113,25) }); setPadding(dp(7), dp(5), dp(7), dp(5)); background = rounded(Color.rgb(239,247,241), 18) })
                box.addView(header)
                box.addView(TextView(this).apply { text = "${property.city.ifBlank { "Location not added" }}  •  ${property.photoUrls.size} photo(s)\nCreated ${property.createdAt.take(10)}"; textSize = 11f; setTextColor(muted); setPadding(0, dp(6), 0, dp(8)) })
                box.addView(actionButton("Manage rooms / units", true) { roomsProperty = property; propertyRooms = emptyList(); roomsError = null; showScreen("Property Rooms"); loadPropertyRooms() }, params(match = true, height = 42, top = 3))
                box.addView(actionButton("Manage tenants", false) { tenantsProperty = property; propertyTenants = emptyList(); tenantsError = null; showScreen("Property Tenants"); loadPropertyTenants() }, params(match = true, height = 42, top = 5))
                box.addView(actionButton("Facilities & map", false) { facilitiesProperty = property; propertyFacilities = emptyList(); facilitiesError = null; showScreen("Property Facilities"); loadPropertyFacilities() }, params(match = true, height = 42, top = 5))
                box.addView(actionButton("Financial records", false) { openPropertyFinance(property) }, params(match = true, height = 42, top = 5))
                val actions = row()
                actions.addView(actionButton("Verification", false) { chooseVerificationDocument(property.id) }, weightedParams())
                actions.addView(actionButton("Add video", false) { videoUploadPropertyId = property.id; val intent = android.content.Intent(android.content.Intent.ACTION_OPEN_DOCUMENT).apply { addCategory(android.content.Intent.CATEGORY_OPENABLE); type = "video/mp4" }; try { startActivityForResult(intent, 8044) } catch (_: Exception) { Toast.makeText(this, "The video picker could not be opened.", Toast.LENGTH_LONG).show() } }, weightedParams(left = 6))
                box.addView(actions, params(match = true, top = 5))
                resultsHost.addView(box, params(match = true, top = 8))
            }
        }
        val listener = object : android.widget.AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: android.widget.AdapterView<*>?, view: View?, position: Int, id: Long) = renderResults()
            override fun onNothingSelected(parent: android.widget.AdapterView<*>?) {}
        }
        statusSpinner.onItemSelectedListener = listener
        sortSpinner.onItemSelectedListener = listener
        search.addTextChangedListener(object : android.text.TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) { renderResults() }
            override fun afterTextChanged(s: android.text.Editable?) {}
        })
        renderResults()
        page.addView(actionButton("Refresh portfolio", false) { myProperties = emptyList(); myPropertiesError = null; myPropertiesLoaded = false; loadMyProperties() }, params(match = true, height = 44, top = 12))
        page.addView(actionButton("Back to landlord dashboard", false) { showScreen("DASH") }, params(match = true, height = 44, top = 7))
        page.addView(actionButton("Add a new property", true) { addStep = 0; showScreen("Add Property") }, params(match = true, height = 46, top = 7))
        note("Portfolio figures are calculated from the properties returned for your signed-in account. Property-specific screens still enforce Supabase Row Level Security.")
    }

    private fun loadPropertyRooms() {
        val property = roomsProperty ?: return
        if (roomsLoading) return
        roomsLoading = true; roomsError = null
        Thread {
            val result = SupabaseAuth.fetchRooms(property.id)
            runOnUiThread {
                roomsLoading = false
                if (result.success) propertyRooms = result.items else roomsError = result.message
                if (currentScreen == "Property Rooms") propertyRoomsPage()
            }
        }.start()
    }

    private fun propertyRoomsPage() {
        val property = roomsProperty ?: run { infoCard("Choose a property", "Return to DASH and select a property first."); return }
        sectionLabel("${property.title.uppercase(Locale.getDefault())} • ROOM INVENTORY")
        val available = propertyRooms.count { it.status == "available" }
        val reserved = propertyRooms.count { it.status == "reserved" }
        val occupied = propertyRooms.count { it.status == "occupied" }
        val maintenance = propertyRooms.count { it.status == "maintenance" }
        infoCard("${propertyRooms.size} rooms recorded", "Available: $available   Reserved: $reserved\nOccupied: $occupied   Maintenance: $maintenance")
        page.addView(actionButton("+ Add room", true) { showAddRoomDialog(property.id) }, params(match = true, height = 48, top = 10))
        page.addView(actionButton("Manage tenants", false) {
            tenantsProperty = property; propertyTenants = emptyList(); tenantsError = null
            showScreen("Property Tenants"); loadPropertyTenants()
        }, params(match = true, height = 46, top = 7))
        page.addView(actionButton("Financial records", false) { openPropertyFinance(property) }, params(match = true, height = 46, top = 7))
        when {
            roomsLoading -> infoCard("Loading room inventory", "Retrieving rooms belonging to this property…")
            roomsError != null -> {
                infoCard("Couldn't load rooms", roomsError ?: "Please try again.")
                page.addView(actionButton("Retry", false) { loadPropertyRooms() }, params(match = true, height = 44, top = 8))
            }
            propertyRooms.isEmpty() -> infoCard("No rooms added yet", "Add the first room for this property. Room records are kept separate from other properties.")
            else -> propertyRooms.forEach { room ->
                infoCard("Room ${room.roomNumber} • ${room.category}", "Rent: ${room.currencyCode} ${NumberFormat.getNumberInstance(Locale.US).format(room.rentAmount)}\nStatus: ${room.status.replaceFirstChar { it.uppercase() }}${if (room.description.isBlank()) "" else "\n${room.description}"}")
                val statuses = arrayOf("available", "reserved", "occupied", "maintenance")
                val picker = Spinner(this).apply { adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item, statuses.map { it.replaceFirstChar { c -> c.uppercase() } }); setSelection(statuses.indexOf(room.status).coerceAtLeast(0)) }
                page.addView(picker, params(match = true, height = 48, top = 4))
                page.addView(actionButton("Update room status", false) {
                    val status = statuses[picker.selectedItemPosition]
                    Thread { val result = SupabaseAuth.updateRoomStatus(room.id, status); runOnUiThread { Toast.makeText(this, result.message, Toast.LENGTH_LONG).show(); if (result.success) loadPropertyRooms() } }.start()
                }, params(match = true, height = 42, top = 4))
            }
        }
        page.addView(actionButton("Back to Landlord DASH", false) { showScreen("DASH") }, params(match = true, height = 46, top = 12))
        note("Room status changes are saved to Supabase. Tenant assignment is managed through the tenant workflow so occupancy is updated transactionally.")
    }


    private fun loadPropertyFacilities() {
        val property = facilitiesProperty ?: return
        if (facilitiesLoading) return
        facilitiesLoading = true; facilitiesError = null
        if (currentScreen == "Property Facilities") propertyFacilitiesPage()
        Thread {
            val result = SupabaseAuth.fetchPropertyFacilities(property.id, ownerView = true)
            runOnUiThread {
                facilitiesLoading = false
                if (result.success) propertyFacilities = result.items else facilitiesError = result.message
                if (currentScreen == "Property Facilities") propertyFacilitiesPage()
            }
        }.start()
    }

    private fun propertyFacilitiesPage() {
        val property = facilitiesProperty ?: run { infoCard("Choose a property", "Return to DASH and select a property first."); return }
        sectionLabel("${property.title.uppercase(Locale.getDefault())} • FACILITIES & MAP")
        infoCard("Property location", "${property.city.ifBlank { "City not provided" }}\nCoordinates can be added when creating a new listing. Older listings can still be searched by name and city in Maps.")
        page.addView(actionButton("Open property search in Maps", true) {
            openPropertyMap(null, null, property.title, property.city)
        }, params(match = true, height = 46, top = 6))
        page.addView(actionButton("+ Add facility", false) { showAddFacilityDialog(property) }, params(match = true, height = 46, top = 8))
        when {
            facilitiesLoading -> infoCard("Loading facilities", "Retrieving amenities for this property…")
            facilitiesError != null -> {
                infoCard("Facilities could not load", facilitiesError ?: "Please try again.")
                page.addView(actionButton("Retry", false) { loadPropertyFacilities() }, params(match = true, height = 42, top = 6))
            }
            propertyFacilities.isEmpty() -> infoCard("No facilities added", "Add amenities such as parking, water, electricity, security, Wi-Fi or nearby transport. Facilities on draft listings remain private until the listing is published and approved.")
            else -> propertyFacilities.forEach { facility ->
                infoCard(facility.name, "${facility.category.replaceFirstChar { c -> c.uppercase() } }${if (facility.notes.isBlank()) "" else "\n${facility.notes}"}")
                page.addView(actionButton("Remove ${facility.name}", false) {
                    android.app.AlertDialog.Builder(this)
                        .setTitle("Remove facility?")
                        .setMessage("Remove ‘${facility.name}’ from ${property.title}?")
                        .setNegativeButton("Cancel", null)
                        .setPositiveButton("Remove") { _, _ ->
                            Thread {
                                val result = SupabaseAuth.deletePropertyFacility(facility.id)
                                runOnUiThread {
                                    Toast.makeText(this, result.message, Toast.LENGTH_LONG).show()
                                    if (result.success) loadPropertyFacilities()
                                }
                            }.start()
                        }.show()
                }, params(match = true, height = 40, top = 3))
            }
        }
        page.addView(actionButton("Back to Landlord DASH", false) { showScreen("DASH") }, params(match = true, height = 46, top = 12))
        note("Facility records are protected by Supabase row-level security. Public visitors can read facilities only for published and approved listings.")
    }

    private fun showAddFacilityDialog(property: SupabaseAuth.OwnedProperty) {
        val layout = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(20), dp(8), dp(20), 0) }
        val name = EditText(this).apply { hint = "Facility name (e.g. Borehole water)"; setSingleLine(true); textSize = 15f }
        val categoryNames = listOf("Utilities", "Security", "Parking", "Recreation", "Connectivity", "Nearby", "Accessibility", "Other")
        val categoryValues = listOf("utilities", "security", "parking", "recreation", "connectivity", "nearby", "accessibility", "other")
        val category = Spinner(this).apply { adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item, categoryNames) }
        val notes = EditText(this).apply { hint = "Notes (optional)"; textSize = 14f; minLines = 2; gravity = Gravity.TOP }
        layout.addView(name, params(match = true, height = 50))
        layout.addView(label("Category")); layout.addView(category, params(match = true, height = 48))
        layout.addView(notes, params(match = true, height = 72, top = 6))
        android.app.AlertDialog.Builder(this)
            .setTitle("Add property facility")
            .setView(layout)
            .setNegativeButton("Cancel", null)
            .setPositiveButton("Save", null)
            .create().also { dialog ->
                dialog.setOnShowListener {
                    dialog.getButton(android.app.AlertDialog.BUTTON_POSITIVE).setOnClickListener {
                        val facilityName = name.text.toString().trim()
                        if (facilityName.length !in 2..100) {
                            name.error = "Enter 2–100 characters"; return@setOnClickListener
                        }
                        val categoryValue = categoryValues[category.selectedItemPosition.coerceIn(categoryValues.indices)]
                        Thread {
                            val result = SupabaseAuth.createPropertyFacility(property.id, facilityName, categoryValue, notes.text.toString())
                            runOnUiThread {
                                Toast.makeText(this, result.message, Toast.LENGTH_LONG).show()
                                if (result.success) {
                                    dialog.dismiss()
                                    loadPropertyFacilities()
                                }
                            }
                        }.start()
                    }
                }
                dialog.show()
            }
    }

    private fun openPropertyFinance(property: SupabaseAuth.OwnedProperty) {
        financeProperty = property; financialRecords = emptyList(); financeError = null
        showScreen("Property Finance"); loadPropertyFinancialRecords()
    }

    private fun loadPropertyFinancialRecords() {
        val property = financeProperty ?: return
        if (financeLoading) return
        financeLoading = true; financeError = null
        Thread {
            val result = SupabaseAuth.fetchPropertyFinancialRecords(property.id)
            runOnUiThread {
                financeLoading = false
                if (result.success) financialRecords = result.items else financeError = result.message
                if (currentScreen == "Property Finance") propertyFinancePage()
            }
        }.start()
    }

    private fun propertyFinancePage() {
        val property = financeProperty ?: run { infoCard("Choose a property", "Return to DASH and select a property first."); return }
        sectionLabel("${property.title.uppercase(Locale.getDefault())} • FINANCIAL LEDGER")
        val currencySummary = financialRecords.groupBy { it.currencyCode }.entries.joinToString("\n") { (currency, rows) ->
            val income = rows.filter { it.recordType == "income" }.sumOf { it.amount }
            val expenses = rows.filter { it.recordType == "expense" }.sumOf { it.amount }
            "$currency — Income: ${NumberFormat.getNumberInstance(Locale.US).format(income)}  •  Expenses: ${NumberFormat.getNumberInstance(Locale.US).format(expenses)}  •  Net: ${NumberFormat.getNumberInstance(Locale.US).format(income - expenses)}"
        }.ifBlank { "No totals until you add your first entry." }
        infoCard("${financialRecords.size} records", currencySummary)
        page.addView(actionButton("+ Add financial record", true) { showAddFinancialRecordDialog(property) }, params(match = true, height = 48, top = 10))
        when {
            financeLoading -> infoCard("Loading ledger", "Retrieving this property's private financial records…")
            financeError != null -> {
                infoCard("Financial records unavailable", financeError ?: "Please retry.")
                page.addView(actionButton("Retry", false) { loadPropertyFinancialRecords() }, params(match = true, height = 44, top = 8))
            }
            financialRecords.isEmpty() -> infoCard("No financial records yet", "Record rent received, deposits, repairs, utilities or other property-related income and expenses.")
            else -> financialRecords.forEach { record ->
                val sign = if (record.recordType == "income") "+" else "−"
                infoCard("$sign ${record.currencyCode} ${NumberFormat.getNumberInstance(Locale.US).format(record.amount)} • ${record.category}", "${record.recordType.uppercase(Locale.getDefault())} • ${record.transactionDate}${if (record.description.isBlank()) "" else "\n${record.description}"}${if (record.paymentReference.isBlank()) "" else "\nReference: ${record.paymentReference}"}")
            }
        }
        page.addView(actionButton("Refresh records", false) { loadPropertyFinancialRecords() }, params(match = true, height = 44, top = 8))
        page.addView(actionButton("Back to Landlord DASH", false) { showScreen("DASH") }, params(match = true, height = 46, top = 10))
        note("Ledger entries are insert-only in this release to preserve an audit trail. This is a recordkeeping tool, not a payment processor or proof of bank settlement. Keep receipts separately.")
    }

    private fun showAddFinancialRecordDialog(property: SupabaseAuth.OwnedProperty) {
        val layout = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(20), dp(8), dp(20), 0) }
        fun field(hintText: String, type: Int = InputType.TYPE_CLASS_TEXT): EditText = EditText(this).apply {
            hint = hintText; inputType = type; textSize = 15f; setSingleLine(true)
        }
        val type = Spinner(this).apply {
            adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item, listOf("Income", "Expense"))
        }
        val category = field("Category (e.g. Rent, Repairs, Utilities)")
        val amount = field("Amount", InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL)
        val currency = field("Currency code (KES)").apply { setText("KES"); setFilters(arrayOf(android.text.InputFilter.LengthFilter(3))) }
        val date = field("Transaction date YYYY-MM-DD").apply { setText(SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date())) }
        val description = field("Description (optional)").apply { inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_CAP_SENTENCES }
        val reference = field("Receipt / payment reference (optional)")
        layout.addView(TextView(this).apply { text = "Record type"; textSize = 13f; setTextColor(muted) })
        layout.addView(type); layout.addView(category); layout.addView(amount); layout.addView(currency); layout.addView(date); layout.addView(description); layout.addView(reference)
        val dialog = android.app.AlertDialog.Builder(this).setTitle("Add financial record").setView(ScrollView(this).apply { addView(layout) })
            .setNegativeButton("Cancel", null).setPositiveButton("Save record", null).create()
        dialog.setOnShowListener {
            dialog.getButton(android.app.AlertDialog.BUTTON_POSITIVE).setOnClickListener {
                val value = amount.text.toString().trim().toDoubleOrNull()
                val currencyValue = currency.text.toString().trim().uppercase(Locale.US)
                val dateValue = date.text.toString().trim()
                if (category.text.toString().trim().length !in 2..80 || value == null || value <= 0.0 || currencyValue.length != 3 || !dateValue.matches(Regex("^\\d{4}-\\d{2}-\\d{2}$"))) {
                    Toast.makeText(this, "Enter category, positive amount, 3-letter currency and date YYYY-MM-DD.", Toast.LENGTH_LONG).show(); return@setOnClickListener
                }
                dialog.getButton(android.app.AlertDialog.BUTTON_POSITIVE).isEnabled = false
                Thread {
                    val result = SupabaseAuth.createPropertyFinancialRecord(property.id, if (type.selectedItemPosition == 0) "income" else "expense", category.text.toString(), value, currencyValue, dateValue, description.text.toString(), reference.text.toString())
                    runOnUiThread {
                        Toast.makeText(this, result.message, Toast.LENGTH_LONG).show()
                        if (result.success) { dialog.dismiss(); loadPropertyFinancialRecords() }
                        else dialog.getButton(android.app.AlertDialog.BUTTON_POSITIVE).isEnabled = true
                    }
                }.start()
            }
        }
        dialog.show()
    }

    private fun loadPropertyTenants() {
        val property = tenantsProperty ?: return
        if (tenantsLoading) return
        tenantsLoading = true; tenantsError = null
        if (currentScreen == "Property Tenants") propertyTenantsPage()
        Thread {
            val result = SupabaseAuth.fetchPropertyTenants(property.id)
            runOnUiThread {
                tenantsLoading = false
                if (result.success) propertyTenants = result.items else tenantsError = result.message
                if (currentScreen == "Property Tenants") propertyTenantsPage()
            }
        }.start()
    }

    private fun propertyTenantsPage() {
        val property = tenantsProperty ?: run { infoCard("Choose a property", "Return to DASH and select a property first."); return }
        sectionLabel("${property.title.uppercase(Locale.getDefault())} • TENANTS")
        val active = propertyTenants.count { it.status == "active" }
        infoCard("$active active • ${propertyTenants.size - active} former", "Tenant records belong only to ${property.title}. Ending a tenancy releases its assigned room through a database transaction.")
        page.addView(actionButton("+ Add tenant", true) { showAddTenantDialog(property) }, params(match = true, height = 48, top = 10))
        when {
            tenantsLoading -> infoCard("Loading tenants", "Retrieving tenant records for this property…")
            tenantsError != null -> {
                infoCard("Tenants unavailable", tenantsError ?: "Please retry.")
                page.addView(actionButton("Retry", false) { loadPropertyTenants() }, params(match = true, height = 44, top = 8))
            }
            propertyTenants.isEmpty() -> infoCard("No tenant records yet", "Add a tenant to assign them to an available room and record lease details.")
            else -> propertyTenants.forEach { tenant ->
                val lease = "Lease: ${tenant.leaseStart.ifBlank { "—" }}${if (tenant.leaseEnd.isBlank() || tenant.leaseEnd == "null") "" else " to ${tenant.leaseEnd}"}"
                infoCard(tenant.fullName, "${tenant.status.uppercase(Locale.getDefault())} • Room ${tenant.roomNumber}\nPhone: ${tenant.phone}\n${if (tenant.email.isBlank() || tenant.email == "null") "" else "Email: ${tenant.email}\n"}Rent: ${tenant.currencyCode} ${NumberFormat.getNumberInstance(Locale.US).format(tenant.rentAmount)} / month\n$lease${if (tenant.notes.isBlank()) "" else "\nNotes: ${tenant.notes}"}")
                if (tenant.status == "active") page.addView(actionButton("End tenancy", false) {
                    android.app.AlertDialog.Builder(this).setTitle("End tenancy?")
                        .setMessage("This will mark ${tenant.fullName}'s tenancy as ended and release the assigned room if it is still occupied.")
                        .setNegativeButton("Cancel", null).setPositiveButton("End tenancy") { _, _ ->
                            Thread { val result = SupabaseAuth.endPropertyTenancy(tenant.id); runOnUiThread {
                                Toast.makeText(this, result.message, Toast.LENGTH_LONG).show()
                                if (result.success) { loadPropertyTenants(); roomsProperty = property; loadPropertyRooms() }
                            } }.start()
                        }.show()
                }, params(match = true, height = 42, top = 4))
            }
        }
        page.addView(actionButton("Refresh tenants", false) { loadPropertyTenants() }, params(match = true, height = 44, top = 8))
        page.addView(actionButton("Back to room inventory", false) { roomsProperty = property; showScreen("Property Rooms"); loadPropertyRooms() }, params(match = true, height = 44, top = 8))
        note("Tenant records are management records only. They are not identity verification, proof of payment, or a signed legal lease.")
    }

    private fun showAddTenantDialog(property: SupabaseAuth.OwnedProperty) {
        val layout = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(20), dp(8), dp(20), 0) }
        fun edit(hint: String, type: Int = InputType.TYPE_CLASS_TEXT): EditText = EditText(this).apply { this.hint = hint; inputType = type; textSize = 14f; setSingleLine(true) }
        val name = edit("Tenant full name")
        val phone = edit("Phone number", InputType.TYPE_CLASS_PHONE)
        val email = edit("Email (optional)", InputType.TYPE_TEXT_VARIATION_EMAIL_ADDRESS)
        val rent = edit("Monthly rent", InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL)
        val start = edit("Lease start date (YYYY-MM-DD)")
        val end = edit("Lease end date (YYYY-MM-DD, optional)")
        val notes = edit("Notes (optional)")
        val roomSpinner = Spinner(this)
        val availableRooms = propertyRooms.filter { it.status == "available" }
        roomSpinner.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item,
            availableRooms.map { "${it.roomNumber} • ${it.category} • ${it.currencyCode} ${it.rentAmount}" })
        layout.addView(TextView(this).apply { text = "Available room"; textSize = 13f; setPadding(0, dp(8), 0, dp(4)) })
        layout.addView(roomSpinner)
        listOf(name, phone, email, rent, start, end, notes).forEach { layout.addView(it) }
        if (availableRooms.isEmpty()) {
            android.app.AlertDialog.Builder(this).setTitle("No available rooms")
                .setMessage("Add a room or change a room's status to Available before assigning a tenant.")
                .setPositiveButton("OK", null).show(); return
        }
        android.app.AlertDialog.Builder(this).setTitle("Add tenant to ${property.title}").setView(layout)
            .setNegativeButton("Cancel", null).setPositiveButton("Save tenant", null).create().also { dialog ->
                dialog.setOnShowListener { dialog.getButton(android.app.AlertDialog.BUTTON_POSITIVE).setOnClickListener {
                    val startDate = start.text.toString().trim(); val endDate = end.text.toString().trim()
                    val validationError = FormValidation.validateTenant(name.text.toString(), phone.text.toString(), rent.text.toString(), startDate, endDate)
                    if (validationError != null) {
                        Toast.makeText(this, validationError, Toast.LENGTH_LONG).show(); return@setOnClickListener
                    }
                    // The shared validator has confirmed this is a finite numeric value.
                    val amount = rent.text.toString().toDouble()
                    val room = availableRooms[roomSpinner.selectedItemPosition.coerceIn(0, availableRooms.lastIndex)]
                    dialog.dismiss()
                    Thread { val result = SupabaseAuth.createPropertyTenant(property.id, room.id, name.text.toString(), phone.text.toString(), email.text.toString(), amount, startDate, endDate, notes.text.toString()); runOnUiThread {
                        Toast.makeText(this, result.message, Toast.LENGTH_LONG).show()
                        if (result.success) { loadPropertyTenants(); roomsProperty = property; loadPropertyRooms() }
                    } }.start()
                } }
                dialog.show()
            }
    }

    private fun showAddRoomDialog(propertyId: String) {
        val layout = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(20), dp(8), dp(20), 0) }
        fun edit(hint: String, type: Int = InputType.TYPE_CLASS_TEXT): EditText = EditText(this).apply { this.hint = hint; inputType = type; textSize = 15f; setSingleLine(true) }
        val number = edit("Room number / name")
        val category = edit("Category (e.g. Single, Bedsitter, 1 Bedroom)")
        val rent = edit("Monthly rent in KES", InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL)
        val description = edit("Description (optional)")
        listOf(number, category, rent, description).forEach { layout.addView(it) }
        android.app.AlertDialog.Builder(this).setTitle("Add a room").setView(layout)
            .setNegativeButton("Cancel", null).setPositiveButton("Save room", null).create().also { dialog ->
                dialog.setOnShowListener { dialog.getButton(android.app.AlertDialog.BUTTON_POSITIVE).setOnClickListener {
                    val amount = rent.text.toString().toDoubleOrNull()
                    if (number.text.isBlank() || category.text.isBlank() || amount == null || amount < 0) { Toast.makeText(this, "Enter a room number, category and valid rent amount.", Toast.LENGTH_LONG).show(); return@setOnClickListener }
                    dialog.dismiss()
                    Thread { val result = SupabaseAuth.createRoom(propertyId, number.text.toString(), category.text.toString(), amount, description.text.toString()); runOnUiThread { Toast.makeText(this, result.message, Toast.LENGTH_LONG).show(); if (result.success) loadPropertyRooms() } }.start()
                } }
                dialog.show()
            }
    }

    private fun showViewingRequestForm(listing: PropertyListing) {
        page.removeAllViews()
        sectionLabel("REQUEST A PROPERTY VIEWING")
        infoCard(listing.title, "${listing.location}\n${listing.priceLabel}\nChoose a date and time that suits you. Your request remains pending until the owner responds.")
        val viewingTime = Calendar.getInstance().apply {
            add(Calendar.DAY_OF_MONTH, 1)
            set(Calendar.HOUR_OF_DAY, 10)
            set(Calendar.MINUTE, 0)
            set(Calendar.SECOND, 0)
            set(Calendar.MILLISECOND, 0)
        }
        val dateText = TextView(this).apply { textSize = 14f; setTextColor(ink); setPadding(dp(4), dp(10), dp(4), dp(4)) }
        val timeText = TextView(this).apply { textSize = 14f; setTextColor(ink); setPadding(dp(4), dp(10), dp(4), dp(4)) }
        val dateFormat = SimpleDateFormat("EEE, d MMM yyyy", Locale.getDefault())
        val timeFormat = SimpleDateFormat("h:mm a", Locale.getDefault())
        fun refreshChosenTime() {
            dateText.text = "Date: ${dateFormat.format(Date(viewingTime.timeInMillis))}"
            timeText.text = "Time: ${timeFormat.format(Date(viewingTime.timeInMillis))}"
        }
        refreshChosenTime()
        page.addView(actionButton("Choose viewing date", false) {
            val dialog = android.app.DatePickerDialog(this, { _, year, month, day ->
                viewingTime.set(Calendar.YEAR, year)
                viewingTime.set(Calendar.MONTH, month)
                viewingTime.set(Calendar.DAY_OF_MONTH, day)
                refreshChosenTime()
            }, viewingTime.get(Calendar.YEAR), viewingTime.get(Calendar.MONTH), viewingTime.get(Calendar.DAY_OF_MONTH))
            dialog.datePicker.minDate = System.currentTimeMillis()
            dialog.show()
        }, params(match = true, height = 48, top = 12))
        page.addView(dateText, params(match = true, top = 2))
        page.addView(actionButton("Choose viewing time", false) {
            android.app.TimePickerDialog(this, { _, hour, minute ->
                viewingTime.set(Calendar.HOUR_OF_DAY, hour)
                viewingTime.set(Calendar.MINUTE, minute)
                viewingTime.set(Calendar.SECOND, 0)
                viewingTime.set(Calendar.MILLISECOND, 0)
                refreshChosenTime()
            }, viewingTime.get(Calendar.HOUR_OF_DAY), viewingTime.get(Calendar.MINUTE), false).show()
        }, params(match = true, height = 48, top = 8))
        page.addView(timeText, params(match = true, top = 2))
        val message = field("Message to owner (optional)", "", "e.g. I would like to view the property after work.")
        page.addView(actionButton("Send viewing request", true) {
            if (!SupabaseAuth.isSignedIn()) {
                Toast.makeText(this, "Please sign in again.", Toast.LENGTH_LONG).show()
                showScreen("Profile")
                return@actionButton
            }
            if (viewingTime.timeInMillis <= System.currentTimeMillis()) {
                Toast.makeText(this, "Choose a future date and time.", Toast.LENGTH_LONG).show()
                return@actionButton
            }
            if (appointmentActionBusy) return@actionButton
            appointmentActionBusy = true
            val utc = SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'", Locale.US).apply {
                timeZone = TimeZone.getTimeZone("UTC")
            }.format(Date(viewingTime.timeInMillis))
            Toast.makeText(this, "Sending your viewing request…", Toast.LENGTH_SHORT).show()
            Thread {
                val result = SupabaseAuth.createViewingRequest(listing.id, utc, message.text.toString())
                runOnUiThread {
                    appointmentActionBusy = false
                    Toast.makeText(this, result.message, Toast.LENGTH_LONG).show()
                    if (result.success) {
                        appointmentsLoaded = false
                        showScreen("Appointments")
                    }
                }
            }.start()
        }, params(match = true, height = 50, top = 16))
        page.addView(actionButton("Back to property", false) { showListingDetails(listing) },
            params(match = true, height = 46, top = 8))
        note("A request is not a confirmed appointment. Wait for the property owner or authorized agent to accept it before visiting.")
    }

    private fun appointmentsPage() {
        if (!SupabaseAuth.isSignedIn()) {
            infoCard("Sign in to manage viewings", "Viewing requests are linked to your AUREVIA account. Sign in to request visits or manage requests for your properties.")
            page.addView(actionButton("Go to Profile", true) { showScreen("Profile") },
                params(match = true, height = 48, top = 10))
            return
        }
        if (!appointmentsLoaded && !appointmentsLoading) loadAppointments()
        if (appointmentsLoading) {
            infoCard("Loading appointments", "Retrieving your viewing requests and requests for your properties…")
            return
        }
        sectionLabel("MY VIEWING REQUESTS")
        if (myAppointmentsError != null) infoCard("Could not load your requests", myAppointmentsError ?: "Please try again.")
        else if (myAppointments.isEmpty()) infoCard("No viewing requests yet", "When you request to visit a property, its status and appointment time will appear here.")
        else myAppointments.forEach { appointmentCard(it, incoming = false) }

        sectionLabel("REQUESTS FOR YOUR PROPERTIES")
        if (incomingAppointmentsError != null) infoCard("Could not load incoming requests", incomingAppointmentsError ?: "Please try again.")
        else if (incomingAppointments.isEmpty()) infoCard("No incoming requests", "Viewing requests for properties you own will appear here. You can accept or decline pending requests.")
        else incomingAppointments.forEach { appointmentCard(it, incoming = true) }

        page.addView(actionButton("Refresh appointments", false) {
            appointmentsLoaded = false
            loadAppointments(force = true)
        }, params(match = true, height = 46, top = 12))
        note("Pending means the owner has not responded. Accepted means the owner confirmed the visit. A chat or phone call alone does not confirm an appointment.")
    }

    private fun loadAppointments(force: Boolean = false) {
        if (appointmentsLoading) return
        if (appointmentsLoaded && !force) return
        if (!sessionRestoreComplete) {
            appointmentsLoaded = true
            myAppointmentsError = "Secure sign-in has not finished. Refresh the dashboard and try again."
            incomingAppointmentsError = myAppointmentsError
            if (currentScreen == "DASH") showScreen("DASH")
            if (currentScreen == "Appointments") showScreen("Appointments")
            return
        }
        if (!SupabaseAuth.isSignedIn()) {
            appointmentsLoaded = true
            myAppointmentsError = "No active Supabase access session is available. Sign in again from Profile."
            incomingAppointmentsError = myAppointmentsError
            if (currentScreen == "DASH") showScreen("DASH")
            if (currentScreen == "Appointments") showScreen("Appointments")
            return
        }
        appointmentsLoading = true
        myAppointmentsError = null
        incomingAppointmentsError = null
        Thread {
            val mine = try { SupabaseAuth.fetchViewingRequests(incoming = false) }
                catch (e: Exception) { SupabaseAuth.ViewingRequestsResult(false, emptyList(), "${e.javaClass.simpleName}: ${e.message ?: "Unknown request error"}") }
            val incoming = try { SupabaseAuth.fetchViewingRequests(incoming = true) }
                catch (e: Exception) { SupabaseAuth.ViewingRequestsResult(false, emptyList(), "${e.javaClass.simpleName}: ${e.message ?: "Unknown request error"}") }
            runOnUiThread {
                appointmentsLoading = false
                appointmentsLoaded = true
                myAppointmentsError = if (mine.success) null else mine.message
                incomingAppointmentsError = if (incoming.success) null else incoming.message
                if (mine.success) myAppointments = mine.items
                if (incoming.success) incomingAppointments = incoming.items
                if (currentScreen == "Appointments") showScreen("Appointments")
                if (currentScreen == "DASH") showScreen("DASH")
            }
        }.start()
    }

    private fun appointmentCard(item: SupabaseAuth.ViewingAppointment, incoming: Boolean) {
        val state = item.status.replaceFirstChar { it.uppercase() }
        val date = try {
            val parser = SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss", Locale.US).apply { timeZone = TimeZone.getTimeZone("UTC") }
            val parsed = parser.parse(item.requestedAt.take(19))
            if (parsed != null) SimpleDateFormat("EEE, d MMM yyyy • h:mm a", Locale.getDefault()).format(parsed) else item.requestedAt
        } catch (_: Exception) { item.requestedAt }
        infoCard(item.propertyTitle, "${item.propertyCity}\nViewing: $date\nStatus: $state${if (item.message.isBlank()) "" else "\nMessage: ${item.message}"}")
        val controls = row()
        if (incoming && item.status == "pending") {
            controls.addView(actionButton("Accept", true) { changeAppointmentStatus(item.id, "accepted") }, weightedParams())
            controls.addView(actionButton("Decline", false) { changeAppointmentStatus(item.id, "declined") }, weightedParams(left = 8))
        } else if (incoming && item.status == "accepted") {
            controls.addView(actionButton("Mark completed", true) { changeAppointmentStatus(item.id, "completed") }, weightedParams())
        } else if (!incoming && item.status in listOf("pending", "accepted")) {
            controls.addView(actionButton("Cancel request", false) { changeAppointmentStatus(item.id, "cancelled") }, weightedParams())
        }
        if (controls.childCount > 0) page.addView(controls, params(match = true, top = 5))
    }

    private fun changeAppointmentStatus(id: String, status: String) {
        if (appointmentActionBusy) return
        appointmentActionBusy = true
        Thread {
            val result = SupabaseAuth.updateViewingRequestStatus(id, status)
            runOnUiThread {
                appointmentActionBusy = false
                Toast.makeText(this, result.message, Toast.LENGTH_LONG).show()
                if (result.success) {
                    appointmentsLoaded = false
                    loadAppointments(force = true)
                }
            }
        }.start()
    }

    private fun inboxPage() {
        if (!SupabaseAuth.isSignedIn()) {
            infoCard("Sign in to use your inbox", "Your property conversations are private and available only to conversation participants.")
            page.addView(actionButton("Sign in", true) { showScreen("Profile") }, params(match = true, height = 48, top = 12))
            return
        }
        renderInboxPage()
        if (!conversationsLoading) loadConversations()
    }

    private fun renderInboxPage() {
        page.removeAllViews()
        page.addView(actionButton("Explore properties", false) { showScreen("Explore") }, params(match = true, height = 44, top = 6))
        when {
            conversationsLoading -> infoCard("Loading your inbox", "Retrieving conversations available to your signed-in account…")
            conversationsError != null -> {
                infoCard("Inbox unavailable", conversationsError ?: "Please try again.")
                page.addView(actionButton("Retry", true) { loadConversations() }, params(match = true, height = 44, top = 8))
            }
            conversations.isEmpty() -> infoCard("No conversations yet", "Open a published property and tap Message property owner to start a private conversation.")
            else -> conversations.forEach { conversation ->
                val uid = SupabaseAuth.currentUserId()
                val role = if (conversation.ownerId == uid) "Property enquiry" else "Your enquiry"
                infoCard(conversation.propertyTitle, "$role${if (conversation.propertyCity.isBlank()) "" else " • ${conversation.propertyCity}"}\nTap to view messages about this property.")
                page.addView(actionButton("Open conversation", true) { openConversation(conversation) }, params(match = true, height = 44, top = 5))
            }
        }
        page.addView(actionButton("Refresh inbox", false) { loadConversations() }, params(match = true, height = 44, top = 10))
        note("Messages are private to the property owner and the person who started the conversation. Do not send passwords, payment PINs or sensitive identity documents.")
    }

    private fun loadConversations() {
        if (!SupabaseAuth.isSignedIn()) { conversationsLoading = false; conversationsError = "Please sign in to view your inbox."; renderInboxPage(); return }
        if (conversationsLoading) return
        conversationsLoading = true; conversationsError = null
        if (currentScreen == "Inbox") renderInboxPage()
        Thread {
            val result = SupabaseAuth.fetchPropertyConversations()
            runOnUiThread {
                conversationsLoading = false
                if (result.success) { conversations = result.items; conversationsError = null } else conversationsError = result.message
                if (currentScreen == "Inbox") renderInboxPage()
            }
        }.start()
    }

    private fun startConversationWithOwner(listing: PropertyListing) {
        Thread {
            val result = SupabaseAuth.startOrGetPropertyConversation(listing.id, listing.ownerId)
            runOnUiThread {
                if (result.success && !result.propertyId.isNullOrBlank()) {
                    val conversation = SupabaseAuth.PropertyConversation(result.propertyId, listing.id,
                        SupabaseAuth.currentUserId().orEmpty(), listing.ownerId, listing.title, listing.location, "")
                    conversations = (listOf(conversation) + conversations.filterNot { it.id == conversation.id }).distinctBy { it.id }
                    openConversation(conversation)
                } else Toast.makeText(this, result.message, Toast.LENGTH_LONG).show()
            }
        }.start()
    }

    private fun openConversation(conversation: SupabaseAuth.PropertyConversation) {
        activeConversation = conversation
        conversationMessages = emptyList(); messagesError = null; messagesLoading = true
        showScreen("Conversation")
        Thread {
            val result = SupabaseAuth.fetchPropertyMessages(conversation.id)
            runOnUiThread {
                messagesLoading = false
                if (result.success) { conversationMessages = result.items; messagesError = null } else messagesError = result.message
                if (currentScreen == "Conversation" && activeConversation?.id == conversation.id) renderPropertyConversationPage()
            }
        }.start()
    }

    private fun propertyConversationPage() {
        renderPropertyConversationPage()
    }

    private fun renderPropertyConversationPage() {
        val conversation = activeConversation ?: run {
            infoCard("Choose a conversation", "Return to your inbox and select a property conversation.")
            page.addView(actionButton("Back to inbox", false) { showScreen("Inbox") }, params(match = true, height = 44, top = 8))
            return
        }
        page.removeAllViews()
        page.addView(actionButton("← Back to inbox", false) { showScreen("Inbox") }, params(match = true, height = 42, top = 5))
        infoCard(conversation.propertyTitle, "${conversation.propertyCity}\nPrivate messages about this listing.")
        when {
            messagesLoading -> infoCard("Loading messages", "Please wait while the conversation is retrieved…")
            messagesError != null -> {
                infoCard("Messages unavailable", messagesError ?: "Please retry.")
                page.addView(actionButton("Retry", false) { openConversation(conversation) }, params(match = true, height = 42, top = 5))
            }
            conversationMessages.isEmpty() -> infoCard("Start the conversation", "Ask a question about availability, viewing arrangements or property details.")
            else -> conversationMessages.forEach { message ->
                val mine = message.senderId == SupabaseAuth.currentUserId()
                infoCard(if (mine) "You" else "Property contact", message.body + "\n" + message.createdAt.replace("T", " ").take(16))
            }
        }
        val composer = EditText(this).apply {
            hint = "Write a message…"; setTextSize(14f); minLines = 2; maxLines = 5
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_CAP_SENTENCES or InputType.TYPE_TEXT_FLAG_MULTI_LINE
            setPadding(dp(12), dp(10), dp(12), dp(10)); background = rounded(Color.WHITE, 12)
        }
        page.addView(composer, params(match = true, height = 96, top = 12))
        page.addView(actionButton(if (messageSending) "Sending…" else "Send message", true) {
            if (messageSending) return@actionButton
            val text = composer.text.toString().trim()
            if (text.isBlank()) { Toast.makeText(this, "Write a message first.", Toast.LENGTH_SHORT).show(); return@actionButton }
            messageSending = true
            Thread {
                val result = SupabaseAuth.sendPropertyMessage(conversation.id, text)
                runOnUiThread {
                    messageSending = false
                    Toast.makeText(this, result.message, Toast.LENGTH_SHORT).show()
                    if (result.success) {
                        messagesLoading = true; messagesError = null; renderPropertyConversationPage()
                        Thread {
                            val refreshed = SupabaseAuth.fetchPropertyMessages(conversation.id)
                            runOnUiThread {
                                messagesLoading = false
                                if (refreshed.success) { conversationMessages = refreshed.items; messagesError = null } else messagesError = refreshed.message
                                if (currentScreen == "Conversation") renderPropertyConversationPage()
                            }
                        }.start()
                    }
                }
            }.start()
        }, params(match = true, height = 48, top = 8))
        page.addView(actionButton("Refresh messages", false) { openConversation(conversation) }, params(match = true, height = 42, top = 6))
    }

    private fun chooseVerificationDocument(propertyId: String) {
        if (!SupabaseAuth.isSignedIn()) {
            Toast.makeText(this, "Sign in before submitting verification evidence.", Toast.LENGTH_LONG).show()
            showScreen("Profile"); return
        }
        val labels = arrayOf("Proof of ownership", "Authorization letter", "Identity document", "Other supporting document")
        val values = arrayOf("ownership_proof", "authorization_letter", "identity_document", "other")
        AlertDialog.Builder(this)
            .setTitle("Choose verification document")
            .setItems(labels) { _, which ->
                verificationPropertyId = propertyId
                verificationDocumentType = values[which]
                val intent = android.content.Intent(android.content.Intent.ACTION_OPEN_DOCUMENT).apply {
                    addCategory(android.content.Intent.CATEGORY_OPENABLE)
                    type = "*/*"
                    putExtra(android.content.Intent.EXTRA_MIME_TYPES, arrayOf("image/jpeg", "image/png", "application/pdf"))
                }
                try { startActivityForResult(intent, 8043) }
                catch (_: Exception) { Toast.makeText(this, "The document picker could not be opened.", Toast.LENGTH_LONG).show() }
            }
            .setNegativeButton("Cancel", null).show()
    }

    private fun loadVerificationDocuments() {
        if (verificationLoading) return
        verificationLoading = true; verificationError = null
        Thread {
            val result = SupabaseAuth.fetchMyVerificationDocuments()
            runOnUiThread {
                verificationLoading = false
                if (result.success) verificationDocuments = result.items else verificationError = result.message
                if (currentScreen == "Verification") verificationPage()
            }
        }.start()
    }

    private fun verificationPage() {
        sectionLabel("PRIVATE VERIFICATION")
        infoCard("How verification works", "Choose a property under My Drafts and submit proof of ownership or authorization. Files are uploaded to a private storage bucket, not public property photos. AUREVIA review is not a substitute for legal due diligence.")
        page.addView(actionButton("Choose a property to verify", true) {
            myProperties = emptyList(); myPropertiesError = null; showScreen("My Drafts"); loadMyProperties()
        }, params(match = true, height = 48, top = 8))
        when {
            verificationLoading -> infoCard("Loading status", "Retrieving your verification submissions…")
            verificationError != null -> {
                infoCard("Status unavailable", verificationError ?: "Please try again.")
                page.addView(actionButton("Retry", false) { loadVerificationDocuments() }, params(match = true, height = 44, top = 6))
            }
            verificationDocuments.isEmpty() -> infoCard("No verification documents", "You have not submitted verification evidence yet.")
            else -> verificationDocuments.forEach { item ->
                val kind = when (item.documentType) {
                    "ownership_proof" -> "Proof of ownership"
                    "authorization_letter" -> "Authorization letter"
                    "identity_document" -> "Identity document"
                    else -> "Other supporting document"
                }
                infoCard(kind, "Property reference: ${item.propertyId}\nReview status: ${item.reviewStatus.uppercase(Locale.getDefault())}\nSubmitted: ${item.createdAt.take(10)}")
            }
        }
        note("Never submit passwords, bank card details or unrelated sensitive documents. Only authorized moderators can review evidence.")
        page.addView(actionButton("Refresh status", false) { loadVerificationDocuments() }, params(match = true, height = 44, top = 8))
    }

    private fun showReportDialog(listing: PropertyListing) {
        val reasons = arrayOf("Suspicious or fraudulent listing", "Incorrect price or details", "Property may be unavailable", "Duplicate listing", "Inappropriate content", "Other safety concern")
        val values = arrayOf("suspicious_or_fraudulent", "incorrect_details", "unavailable_property", "duplicate_listing", "inappropriate_content", "other_safety_concern")
        AlertDialog.Builder(this).setTitle("Why are you reporting this listing?")
            .setItems(reasons) { _, index ->
                val details = EditText(this).apply { hint = "Additional details (optional)"; minLines = 2; maxLines = 5; inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE }
                AlertDialog.Builder(this).setTitle("Add details") .setView(details)
                    .setPositiveButton("Submit report") { _, _ ->
                        Thread {
                            val result = SupabaseAuth.submitPropertyReport(listing.id, values[index], details.text.toString())
                            runOnUiThread { Toast.makeText(this, result.message, Toast.LENGTH_LONG).show() }
                        }.start()
                    }.setNegativeButton("Cancel", null).show()
            }.setNegativeButton("Cancel", null).show()
    }

    private fun loadModerationQueues() {
        if (moderationLoading) return
        moderationLoading = true; moderationError = null
        Thread {
            val moderator = SupabaseAuth.isCurrentUserModerator()
            val properties = if (moderator) SupabaseAuth.fetchModerationProperties() else SupabaseAuth.QueueResult(false, emptyList(), "This account is not authorized for moderator tools.")
            val reports = if (moderator) SupabaseAuth.fetchModerationReports() else SupabaseAuth.QueueResult(false, emptyList(), properties.message)
            val documents = if (moderator) SupabaseAuth.fetchModerationVerificationDocuments() else SupabaseAuth.QueueResult(false, emptyList(), properties.message)
            runOnUiThread {
                moderationLoading = false
                if (!moderator) moderationError = "Moderator access is restricted to trusted admin accounts. The database enforces this restriction too."
                else if (!properties.success || !reports.success || !documents.success) moderationError = listOf(properties.message, reports.message, documents.message).firstOrNull { it.isNotBlank() } ?: "Could not load moderation queues."
                if (moderator) {
                    moderationProperties = properties.items; moderationReports = reports.items; moderationDocuments = documents.items
                }
                if (currentScreen == "Moderation") moderationPage()
            }
        }.start()
    }

    private fun moderationPage() {
        sectionLabel("MODERATOR WORKSPACE")
        when {
            moderationLoading -> infoCard("Loading review queues", "Checking moderator permissions and fetching pending items…")
            moderationError != null -> {
                infoCard("Moderator access / queue error", moderationError ?: "Please sign in with a trusted admin account.")
                page.addView(actionButton("Retry", false) { loadModerationQueues() }, params(match = true, height = 44, top = 8))
                note("Do not promote your own account to admin just to unlock this screen. Promote only a trusted moderator manually in Supabase after verifying their identity.")
            }
            else -> {
                infoCard("Pending listings: ${moderationProperties.size}", "Approve only when the submission is complete and complies with marketplace rules. Approval publishes the listing.")
                moderationProperties.forEach { item ->
                    infoCard(item.title, "${item.city}\nProperty ID: ${item.id}\nSubmitted: ${item.createdAt.take(10)}")
                    val actions = row()
                    actions.addView(actionButton("Approve & publish", true) { confirmModeration("Approve this listing?", "This makes the listing public.") {
                        runModerationAction { SupabaseAuth.moderateProperty(item.id, true) }
                    } }, weightedParams())
                    actions.addView(actionButton("Reject", false) { confirmModeration("Reject this listing?", "The owner will need to correct and resubmit it.") {
                        runModerationAction { SupabaseAuth.moderateProperty(item.id, false) }
                    } }, weightedParams(left = 8))
                    page.addView(actions, params(match = true, top = 6))
                }
                page.addView(View(this), params(match = true, height = 8))
                infoCard("Pending verification evidence: ${moderationDocuments.size}", "Review documents only when the evidence is relevant. The actual file remains in private storage and is not displayed in this queue.")
                moderationDocuments.forEach { item ->
                    infoCard(item.documentType.replace('_', ' ').replaceFirstChar { it.uppercase() }, "Property ID: ${item.propertyId}\nOwner ID: ${item.ownerId}\nSubmitted: ${item.createdAt.take(10)}")
                    val actions = row()
                    actions.addView(actionButton("Approve evidence", true) { confirmModeration("Approve verification?", "This marks the submitted evidence as approved.") {
                        runModerationAction { SupabaseAuth.moderateVerificationDocument(item.id, true) }
                    } }, weightedParams())
                    actions.addView(actionButton("Reject evidence", false) { confirmModeration("Reject verification?", "The owner can submit corrected evidence later.") {
                        runModerationAction { SupabaseAuth.moderateVerificationDocument(item.id, false) }
                    } }, weightedParams(left = 8))
                    page.addView(actions, params(match = true, top = 6))
                }
                page.addView(View(this), params(match = true, height = 8))
                infoCard("Open safety reports: ${moderationReports.size}", "Reports are private to the reporter and authorized moderators.")
                moderationReports.forEach { item ->
                    infoCard(item.reason.replace('_', ' ').replaceFirstChar { it.uppercase() }, "Property ID: ${item.propertyId}\nStatus: ${item.status}\n${item.details}")
                    val actions = row()
                    actions.addView(actionButton("Investigating", false) { runModerationAction { SupabaseAuth.updateReportStatus(item.id, "reviewing") } }, weightedParams())
                    actions.addView(actionButton("Resolve", true) { runModerationAction { SupabaseAuth.updateReportStatus(item.id, "resolved") } }, weightedParams(left = 6))
                    actions.addView(actionButton("Dismiss", false) { runModerationAction { SupabaseAuth.updateReportStatus(item.id, "dismissed") } }, weightedParams(left = 6))
                    page.addView(actions, params(match = true, top = 6))
                }
                page.addView(actionButton("Refresh queues", false) { loadModerationQueues() }, params(match = true, height = 44, top = 12))
            }
        }
    }

    private fun confirmModeration(titleText: String, messageText: String, action: () -> Unit) {
        AlertDialog.Builder(this).setTitle(titleText).setMessage(messageText)
            .setPositiveButton("Continue") { _, _ -> action() }.setNegativeButton("Cancel", null).show()
    }

    private fun runModerationAction(action: () -> SupabaseAuth.Result) {
        if (moderationActionBusy) return
        moderationActionBusy = true
        Thread {
            val result = action()
            runOnUiThread {
                moderationActionBusy = false
                Toast.makeText(this, result.message, Toast.LENGTH_LONG).show()
                if (result.success) loadModerationQueues()
            }
        }.start()
    }

    private fun profilePage() {
        sectionLabel("ACCOUNT")
        if (SupabaseAuth.isSignedIn()) {
            infoCard("You're signed in", SupabaseAuth.currentEmail() ?: "AUREVIA account")
            page.addView(actionButton("Open landlord DASH", true) { showScreen("DASH") },
                params(match = true, height = 50, top = 12))
            page.addView(actionButton("My property drafts and listings", false) {
                myProperties = emptyList(); myPropertiesLoaded = false; myPropertiesError = null; showScreen("My Drafts"); loadMyProperties()
            }, params(match = true, height = 50, top = 8))
            page.addView(actionButton("Verification status", false) {
                verificationDocuments = emptyList(); verificationError = null; showScreen("Verification"); loadVerificationDocuments()
            }, params(match = true, height = 48, top = 8))
            page.addView(actionButton("Moderator tools", false) {
                moderationProperties = emptyList(); moderationReports = emptyList(); moderationDocuments = emptyList()
                moderationError = null; showScreen("Moderation"); loadModerationQueues()
            }, params(match = true, height = 48, top = 8))
            page.addView(actionButton("Sign out", true) {
                SupabaseAuth.signOut()
                Toast.makeText(this, "Signed out on this device.", Toast.LENGTH_SHORT).show()
                showScreen("Profile")
            }, params(match = true, height = 50, top = 12))
        } else {
            infoCard("Welcome to AUREVIA", "Create an account or sign in to begin using your AUREVIA account.")
            val email = field("Email address", "", "you@example.com").apply {
                inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_EMAIL_ADDRESS
            }
            val password = field("Password", "", "At least 8 characters").apply {
                inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
            }
            val displayName = field("Name (for new accounts)", "", "Your name")
            page.addView(actionButton("Create account", true) {
                val e = email.text.toString().trim()
                val pw = password.text.toString()
                val name = displayName.text.toString().trim()
                if (!android.util.Patterns.EMAIL_ADDRESS.matcher(e).matches()) {
                    Toast.makeText(this, "Enter a valid email address.", Toast.LENGTH_SHORT).show()
                } else if (pw.length < 8) {
                    Toast.makeText(this, "Use a password with at least 8 characters.", Toast.LENGTH_SHORT).show()
                } else if (name.isBlank()) {
                    Toast.makeText(this, "Enter your name to create an account.", Toast.LENGTH_SHORT).show()
                } else {
                    performAuth("Creating your account…") { SupabaseAuth.signUp(e, pw, name) }
                }
            }, params(match = true, height = 50, top = 14))
            page.addView(actionButton("Sign in", false) {
                val e = email.text.toString().trim()
                val pw = password.text.toString()
                if (!android.util.Patterns.EMAIL_ADDRESS.matcher(e).matches() || pw.isBlank()) {
                    Toast.makeText(this, "Enter your email and password.", Toast.LENGTH_SHORT).show()
                } else {
                    performAuth("Signing in…") { SupabaseAuth.signIn(e, pw) }
                }
            }, params(match = true, height = 48, top = 8))
            note("Sessions are stored encrypted with Android Keystore and refreshed with Supabase when the app starts. Email confirmation may be required for new accounts.")
        }
        quickTile("Viewing appointments", "Manage property visits and incoming requests") { showScreen("Appointments") }
        quickTile("Preferences", "Language, currency and units") { infoCard("Preferences", "Country, currency, language and measurement settings will be added in the localization phase.") }
        quickTile("Help and safety", "Stay safe while searching") { infoCard("Safety first", "Never send money before verifying the property and the person authorized to rent or sell it.") }
        quickTile("About AUREVIA", "Find your place") { infoCard("AUREVIA", "A property marketplace designed to help people find a place to call home.") }
    }

    private fun landlordDashboardPage() {
        if (!sessionRestoreComplete) {
            dashboardPanel("Restoring your secure session", "AUREVIA is checking your saved sign-in before requesting private property records…")
            return
        }
        if (!SupabaseAuth.isSignedIn()) {
            dashboardPanel("Your private property workspace", "Sign in to manage your properties, respond to viewing requests and access landlord tools.")
            page.addView(actionButton("Sign in or create account", true) { showScreen("Profile") },
                params(match = true, height = 50, top = 12))
            return
        }
        if (!myPropertiesLoaded && !myPropertiesLoading && myPropertiesError == null) loadMyProperties()
        if (!appointmentsLoaded && !appointmentsLoading) loadAppointments()

        // Welcome header
        val welcome = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(18), dp(18), dp(18))
            background = rounded(Color.rgb(18, 91, 62), 20)
        }
        welcome.addView(TextView(this).apply {
            text = "AUREVIA  /  OWNER SPACE"; textSize = 10f; letterSpacing = .13f
            setTextColor(Color.rgb(202, 235, 216)); setTypeface(null, Typeface.BOLD)
        })
        welcome.addView(TextView(this).apply {
            text = "Your property dashboard"; textSize = 22f; setTextColor(Color.WHITE)
            setTypeface(null, Typeface.BOLD); setPadding(0, dp(8), 0, dp(4))
        })
        welcome.addView(TextView(this).apply {
            text = SupabaseAuth.currentEmail() ?: "Manage your properties in one place"
            textSize = 12f; setTextColor(Color.rgb(224, 242, 230))
        })
        page.addView(welcome, params(match = true, top = 8))

        val topActions = row()
        topActions.addView(actionButton("+ Add property", true) { addStep = 0; showScreen("Add Property") }, weightedParams())
        topActions.addView(actionButton("View appointments", false) { showScreen("Appointments") }, weightedParams(left = 8))
        page.addView(topActions, params(match = true, top = 12))

        dashboardSection("AT A GLANCE", "Live figures from your account")
        if (myPropertiesLoading || appointmentsLoading) {
            dashboardPanel("Updating your dashboard", "Fetching your property and appointment records…")
        }
        if (myPropertiesError != null) {
            dashboardPanel("Properties could not load", myPropertiesError ?: "Please try again.")
            page.addView(actionButton("Retry", false) {
                myPropertiesError = null; myPropertiesLoaded = false; myPropertiesLoading = false; loadMyProperties()
            }, params(match = true, height = 44, top = 6))
        } else if (myPropertiesLoaded) {
            val total = myProperties.size
            val published = myProperties.count { it.status.equals("published", true) }
            val pending = myProperties.count { it.reviewStatus.equals("pending", true) }
            val draftCount = myProperties.count { it.status.equals("draft", true) }
            val pendingVisits = incomingAppointments.count { it.status.equals("pending", true) }
            val grid1 = row()
            grid1.addView(dashMetricCard("Properties", total.toString(), "Your account"), weightedParams())
            grid1.addView(dashMetricCard("Published", published.toString(), "Live listings"), weightedParams(left = 8))
            page.addView(grid1, params(match = true, top = 6))
            val grid2 = row()
            grid2.addView(dashMetricCard("In review", pending.toString(), "Awaiting approval"), weightedParams())
            grid2.addView(dashMetricCard("Drafts", draftCount.toString(), "Not public yet"), weightedParams(left = 8))
            page.addView(grid2, params(match = true, top = 8))
            val visitLine = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
                setPadding(dp(14), dp(13), dp(14), dp(13)); background = rounded(Color.WHITE, 15)
            }
            visitLine.addView(LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                addView(TextView(this@MainActivity).apply { text = "Pending viewings"; textSize = 13f; setTextColor(ink); setTypeface(null, Typeface.BOLD) })
                addView(TextView(this@MainActivity).apply { text = "Requests needing your response"; textSize = 11f; setTextColor(muted); setPadding(0, dp(3), 0, 0) })
            }, LinearLayout.LayoutParams(0, -2, 1f))
            visitLine.addView(TextView(this).apply {
                text = pendingVisits.toString(); textSize = 24f; setTextColor(Color.rgb(21, 112, 72)); setTypeface(null, Typeface.BOLD)
            })
            page.addView(visitLine, params(match = true, top = 8))
        }

        dashboardSection("YOUR PROPERTIES", "Every property stays under this account")
        when {
            myPropertiesLoading -> dashboardPanel("Loading properties", "Your property cards will appear here.")
            myPropertiesError != null -> dashboardPanel("Property list unavailable", "Use the retry option above to load your properties.")
            myProperties.isEmpty() -> {
                dashboardPanel("Start with your first property", "Add a house, apartment, building or plot. You can manage more properties later from this same account.")
                page.addView(actionButton("Create your first property", true) { addStep = 0; showScreen("Add Property") },
                    params(match = true, height = 48, top = 8))
            }
            else -> {
                myProperties.take(5).forEach { property ->
                    val state = if (property.status.equals("published", true)) "PUBLISHED" else property.reviewStatus.uppercase(Locale.getDefault())
                    val prop = LinearLayout(this).apply {
                        orientation = LinearLayout.VERTICAL; setPadding(dp(15), dp(14), dp(15), dp(14))
                        background = rounded(Color.WHITE, 16)
                        isClickable = true; isFocusable = true
                        setOnClickListener {
                            myPropertiesError = null; showScreen("My Drafts"); loadMyProperties()
                        }
                    }
                    val head = row()
                    head.addView(TextView(this).apply {
                        text = property.title.ifBlank { "Untitled property" }; textSize = 15f
                        setTextColor(ink); setTypeface(null, Typeface.BOLD)
                    }, LinearLayout.LayoutParams(0, -2, 1f))
                    val statusColor = when (state) {
                        "PUBLISHED", "APPROVED" -> Color.rgb(22, 125, 78)
                        "REJECTED" -> Color.rgb(190, 65, 58)
                        else -> Color.rgb(176, 113, 25)
                    }
                    head.addView(TextView(this).apply {
                        text = state; textSize = 9f; setTypeface(null, Typeface.BOLD); setTextColor(statusColor)
                        setPadding(dp(8), dp(5), dp(8), dp(5)); background = rounded(Color.rgb(239, 247, 241), 20)
                    })
                    prop.addView(head)
                    prop.addView(TextView(this).apply {
                        text = if (property.city.isBlank()) "Location not added" else property.city
                        textSize = 12f; setTextColor(muted); setPadding(0, dp(6), 0, dp(2))
                    })
                    prop.addView(TextView(this).apply {
                        text = "${property.photoUrls.size} photo(s)  •  ${property.city.ifBlank { "Location not added" }}"
                        textSize = 11f; setTextColor(Color.rgb(90, 112, 99)); setPadding(0, dp(5), 0, 0)
                    })
                    prop.addView(actionButton("Manage rooms", true) {
                        roomsProperty = property; propertyRooms = emptyList(); roomsError = null; showScreen("Property Rooms"); loadPropertyRooms()
                    }, params(match = true, height = 42, top = 10))
                    prop.addView(actionButton("Manage facilities & map", false) {
                        facilitiesProperty = property; propertyFacilities = emptyList(); facilitiesError = null
                        showScreen("Property Facilities"); loadPropertyFacilities()
                    }, params(match = true, height = 42, top = 6))
                    prop.addView(actionButton("Financial records", false) { openPropertyFinance(property) }, params(match = true, height = 42, top = 6))
                    page.addView(prop, params(match = true, top = 8))
                }
                if (myProperties.size > 5) {
                    page.addView(actionButton("View all ${myProperties.size} properties", false) {
                        showScreen("My Drafts"); loadMyProperties()
                    }, params(match = true, height = 44, top = 8))
                }
            }
        }
        page.addView(actionButton("Open multi-property portfolio", true) {
            showScreen("Portfolio"); if (!myPropertiesLoaded || myPropertiesError != null) loadMyProperties()
        }, params(match = true, height = 46, top = 8))
        page.addView(actionButton("Manage all listings / drafts", false) {
            showScreen("My Drafts"); loadMyProperties()
        }, params(match = true, height = 44, top = 7))

        dashboardSection("VIEWING APPOINTMENTS", "Respond quickly to people interested in your properties")
        if (incomingAppointmentsError != null) {
            dashboardPanel("Appointments unavailable", incomingAppointmentsError ?: "Please refresh and try again.")
        } else if (appointmentsLoaded && incomingAppointments.isEmpty()) {
            dashboardPanel("No incoming requests", "When someone requests to view one of your published properties, the request will appear here.")
        } else {
            val pendingItems = incomingAppointments.filter { it.status.equals("pending", true) }
            if (pendingItems.isNotEmpty()) {
                pendingItems.take(3).forEach { item ->
                    val card = LinearLayout(this).apply {
                        orientation = LinearLayout.VERTICAL; setPadding(dp(14), dp(13), dp(14), dp(13))
                        background = rounded(Color.WHITE, 15)
                    }
                    card.addView(TextView(this).apply {
                        text = item.propertyTitle; textSize = 14f; setTextColor(ink); setTypeface(null, Typeface.BOLD)
                    })
                    card.addView(TextView(this).apply {
                        text = "${item.propertyCity}  •  ${item.requestedAt.take(16).replace('T', ' ')}"
                        textSize = 11f; setTextColor(muted); setPadding(0, dp(5), 0, dp(8))
                    })
                    card.addView(actionButton("Review request", true) { showScreen("Appointments") }, params(match = true, height = 42))
                    page.addView(card, params(match = true, top = 8))
                }
            } else if (appointmentsLoaded) {
                dashboardPanel("You're all caught up", "There are no pending viewing requests. Accepted visits remain available in Appointments.")
            } else {
                dashboardPanel("Loading viewing requests", "Your latest requests will appear here shortly.")
            }
        }
        page.addView(actionButton("Open appointment manager", true) { showScreen("Appointments") },
            params(match = true, height = 48, top = 8))

        dashboardSection("MANAGEMENT TOOLS", "Quick access to your landlord workspace")
        dashboardTool("Property drafts & listings", "Edit details and review listing status") {
            myPropertiesError = null; showScreen("My Drafts"); loadMyProperties()
        }
        dashboardTool("Add another property", "Register another building or home") { addStep = 0; showScreen("Add Property") }
        dashboardTool("Refresh dashboard", "Reconnect securely and sync your account records") {
            myPropertiesError = null; myPropertiesLoaded = false; myPropertiesLoading = false
            appointmentsLoaded = false; appointmentsLoading = false
            myProperties = emptyList(); incomingAppointments = emptyList()
            page.removeAllViews()
            dashboardPanel("Reconnecting securely", "Refreshing your saved sign-in before loading property and appointment records…")
            Thread {
                val restored = try { SupabaseAuth.restoreSession() } catch (_: Exception) { false }
                runOnUiThread {
                    sessionRestoreComplete = true
                    if (!SupabaseAuth.isSignedIn()) {
                        myPropertiesError = "Your session could not be restored. Please sign in again from Profile."
                        myPropertiesLoaded = false
                        landlordDashboardPage()
                    } else {
                        landlordDashboardPage()
                    }
                }
            }.start()
        }
        dashboardSection("PROPERTY MANAGEMENT", "Manage inventory and occupancy per property")
        dashboardPanel("Room and tenant management", "Open a property card above to manage its room inventory and tenant records. Tenant and room status changes are handled by secured database functions.")
        note("All figures above come from your signed-in Supabase records. A draft or pending property is private and is not visible in public Explore. Payment totals and occupancy are not shown until those records are implemented.")
    }

    private fun dashboardSection(heading: String, detail: String) {
        val block = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(0, dp(20), 0, dp(4)) }
        block.addView(TextView(this).apply {
            text = heading; textSize = 11f; letterSpacing = .1f; setTextColor(Color.rgb(24, 113, 75)); setTypeface(null, Typeface.BOLD)
        })
        block.addView(TextView(this).apply { text = detail; textSize = 11f; setTextColor(muted); setPadding(0, dp(3), 0, 0) })
        page.addView(block)
    }

    private fun dashboardPanel(heading: String, body: String) {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(dp(15), dp(14), dp(15), dp(14))
            background = rounded(Color.WHITE, 16)
        }
        box.addView(TextView(this).apply { text = heading; textSize = 14f; setTextColor(ink); setTypeface(null, Typeface.BOLD) })
        box.addView(TextView(this).apply { text = body; textSize = 12f; setTextColor(muted); setPadding(0, dp(6), 0, 0); setLineSpacing(dp(2).toFloat(), 1f) })
        page.addView(box, params(match = true, top = 6))
    }

    private fun dashMetricCard(labelText: String, value: String, hintText: String): View {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(dp(14), dp(13), dp(12), dp(13))
            background = rounded(Color.WHITE, 16)
        }
        box.addView(TextView(this).apply { text = value; textSize = 25f; setTextColor(Color.rgb(19, 111, 72)); setTypeface(null, Typeface.BOLD) })
        box.addView(TextView(this).apply { text = labelText; textSize = 12f; setTextColor(ink); setTypeface(null, Typeface.BOLD); setPadding(0, dp(3), 0, 0) })
        box.addView(TextView(this).apply { text = hintText; textSize = 10f; setTextColor(muted); setPadding(0, dp(3), 0, 0) })
        return box
    }

    private fun dashboardTool(heading: String, body: String, click: () -> Unit) {
        val tile = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(dp(14), dp(13), dp(14), dp(13))
            background = rounded(Color.WHITE, 14); isClickable = true; isFocusable = true
            setOnClickListener { click() }
        }
        tile.addView(TextView(this).apply { text = "$heading  ›"; textSize = 14f; setTextColor(Color.rgb(22, 105, 69)); setTypeface(null, Typeface.BOLD) })
        tile.addView(TextView(this).apply { text = body; textSize = 11f; setTextColor(muted); setPadding(0, dp(4), 0, 0) })
        page.addView(tile, params(match = true, top = 7))
    }

    private fun dashboardMetric(labelText: String, value: String, detail: String) {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(15), dp(16), dp(15))
            background = rounded(Color.rgb(21, 57, 43), 16)
        }
        box.addView(TextView(this).apply {
            text = labelText; textSize = 11f; letterSpacing = .1f
            setTextColor(Color.rgb(190, 224, 203)); setTypeface(null, Typeface.BOLD)
        })
        box.addView(TextView(this).apply {
            text = value; textSize = 30f; setTextColor(Color.WHITE)
            setTypeface(null, Typeface.BOLD); setPadding(0, dp(5), 0, dp(2))
        })
        box.addView(TextView(this).apply { text = detail; textSize = 12f; setTextColor(Color.rgb(218, 233, 222)) })
        page.addView(box, params(match = true, top = 6))
    }

    private fun dashboardMiniMetric(labelText: String, value: String): View {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(13), dp(13), dp(13), dp(13))
            background = rounded(Color.WHITE, 14)
        }
        box.addView(TextView(this).apply { text = value; textSize = 23f; setTextColor(Color.rgb(21, 95, 64)); setTypeface(null, Typeface.BOLD) })
        box.addView(TextView(this).apply { text = labelText; textSize = 11f; setTextColor(muted); setPadding(0, dp(3), 0, 0) })
        return box
    }

    private fun performAuth(loadingMessage: String, action: () -> SupabaseAuth.Result) {
        if (authBusy) return
        authBusy = true
        Toast.makeText(this, loadingMessage, Toast.LENGTH_SHORT).show()
        Thread {
            val result = action()
            runOnUiThread {
                authBusy = false
                Toast.makeText(this, result.message, Toast.LENGTH_LONG).show()
                if (result.success && SupabaseAuth.isSignedIn()) showScreen("Profile")
            }
        }.start()
    }

    private fun field(caption: String, value: String, hintText: String): EditText {
        page.addView(label(caption))
        return EditText(this).apply {
            hint = hintText; setText(value); textSize = 14f
            setPadding(dp(13), dp(10), dp(13), dp(10))
            background = rounded(Color.WHITE, 12)
            page.addView(this, params(match = true, height = 50, top = 4))
        }
    }

    private fun label(text: String) = TextView(this).apply {
        this.text = text; textSize = 13f; setTextColor(ink); setTypeface(null, Typeface.BOLD)
        setPadding(0, dp(12), 0, dp(4))
    }

    private fun sectionLabel(text: String) {
        val t = TextView(this).apply {
            this.text = text; textSize = 11f; letterSpacing = .12f
            setTextColor(Color.rgb(142, 108, 49)); setTypeface(null, Typeface.BOLD)
            setPadding(0, dp(22), 0, dp(8))
        }
        page.addView(t)
    }

    private fun infoCard(heading: String, body: String) {
        page.addView(buildInfoCard(heading, body), params(match = true, top = 7))
    }

    private fun buildInfoCard(heading: String, body: String): View {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(dp(16), dp(15), dp(16), dp(15))
            background = rounded(card, 16)
        }
        box.addView(TextView(this).apply { text = heading; textSize = 16f; setTextColor(ink); setTypeface(null, Typeface.BOLD) })
        box.addView(TextView(this).apply { text = body; textSize = 13f; setTextColor(muted); setPadding(0, dp(7), 0, 0); setLineSpacing(dp(3).toFloat(), 1f) })
        return box
    }

    private fun quickTile(heading: String, body: String, click: () -> Unit) {
        val b = actionButton("$heading   ›\n$body", false, click)
        b.gravity = Gravity.CENTER_VERTICAL or Gravity.START
        b.textSize = 14f
        page.addView(b, params(match = true, height = 62, top = 7))
    }

    private fun note(text: String) {
        page.addView(TextView(this).apply {
            this.text = text; textSize = 11f; setTextColor(muted)
            setPadding(dp(4), dp(14), dp(4), dp(18))
        })
    }

    private fun actionButton(text: String, primary: Boolean, click: () -> Unit): Button {
        return Button(this).apply {
            this.text = text; isAllCaps = false; textSize = 13f
            setTextColor(if (primary) ink else gold)
            background = rounded(if (primary) gold else Color.rgb(36, 36, 36), 12)
            setOnClickListener { click() }
        }
    }

    private fun row() = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
    private fun rounded(color: Int, radius: Int) = GradientDrawable().apply {
        setColor(color); cornerRadius = dp(radius).toFloat()
    }
    private fun params(match: Boolean, height: Int = -2, top: Int = 0): LinearLayout.LayoutParams =
        LinearLayout.LayoutParams(if (match) -1 else -2, if (height < 0) height else dp(height)).apply { topMargin = dp(top) }
    private fun weightedParams(left: Int = 0) = LinearLayout.LayoutParams(0, dp(48), 1f).apply { marginStart = dp(left) }
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
}
