package com.aurevia.app

import java.text.ParsePosition
import java.text.SimpleDateFormat
import java.util.Locale

/** Pure input rules shared by the UI and local unit tests. */
internal object FormValidation {
    fun validatePropertyLocation(
        title: String,
        country: String,
        countryCode: String,
        city: String,
        latitude: String,
        longitude: String
    ): String? {
        if (title.trim().length !in 5..120 || country.isBlank() || city.isBlank() ||
            !countryCode.trim().uppercase(Locale.ROOT).matches(Regex("[A-Z]{2}"))) {
            return "Enter a title (5–120 characters), country, 2-letter country code and city."
        }
        if (latitude.isBlank() && longitude.isBlank()) return null
        val lat = latitude.trim().toDoubleOrNull()
        val lon = longitude.trim().toDoubleOrNull()
        if (lat == null || lon == null || !lat.isFinite() || !lon.isFinite() ||
            lat !in -90.0..90.0 || lon !in -180.0..180.0) {
            return "Enter both valid coordinates (latitude −90 to 90, longitude −180 to 180), or leave both blank."
        }
        return null
    }

    fun validatePrice(amountText: String, currencyCode: String): String? {
        val amount = amountText.trim().toDoubleOrNull()
        if (amount == null || !amount.isFinite() || amount <= 0.0 ||
            !currencyCode.trim().uppercase(Locale.ROOT).matches(Regex("[A-Z]{3}"))) {
            return "Enter a valid price and 3-letter currency code."
        }
        return null
    }

    fun validateTenant(name: String, phone: String, rentText: String, startDate: String, endDate: String): String? {
        val rent = rentText.trim().toDoubleOrNull()
        if (name.isBlank() || phone.isBlank() || rent == null || !rent.isFinite() || rent < 0.0 ||
            !isValidIsoDate(startDate) || (endDate.isNotBlank() && !isValidIsoDate(endDate))) {
            return "Enter name, phone, valid rent, and dates in YYYY-MM-DD format."
        }
        if (endDate.isNotBlank() && endDate < startDate) {
            return "Lease end must not be before start."
        }
        return null
    }

    private fun isValidIsoDate(value: String): Boolean {
        if (!value.matches(Regex("\\d{4}-\\d{2}-\\d{2}"))) return false
        val format = SimpleDateFormat("yyyy-MM-dd", Locale.ROOT).apply { isLenient = false }
        val position = ParsePosition(0)
        val parsed = format.parse(value, position)
        return parsed != null && position.index == value.length
    }
}
