package com.aurevia.app

/** UI-independent model for a property card/detail view in the public catalogue. */
internal data class PropertyListing(
    val id: String,
    val title: String,
    val location: String,
    val purpose: String,
    val type: String,
    val price: Double,
    val priceLabel: String,
    val beds: Int,
    val baths: Double,
    val description: String,
    val latitude: Double? = null,
    val longitude: Double? = null,
    val ownerId: String = ""
)
