package com.aurevia.app

import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

/** Shared JSON REST transport. Business operations and session state remain in SupabaseAuth. */
internal object SupabaseHttpClient {
    fun execute(
        baseUrl: String,
        publishableKey: String,
        path: String,
        method: String,
        body: JSONObject,
        bearer: String?,
        prefer: String? = null
    ): Pair<Int, String> {
        var connection: HttpURLConnection? = null
        return try {
            connection = (URL(baseUrl + path).openConnection() as HttpURLConnection).apply {
                requestMethod = method
                connectTimeout = 15_000
                readTimeout = 15_000
                doOutput = method != "GET" && method != "DELETE"
                setRequestProperty("Content-Type", "application/json")
                setRequestProperty("apikey", publishableKey)
                setRequestProperty("Authorization", "Bearer ${bearer ?: publishableKey}")
                if (prefer != null) setRequestProperty("Prefer", prefer)
            }
            if (method != "GET" && method != "DELETE") {
                connection.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }
            }
            val code = connection.responseCode
            val stream = if (code in 200..299) connection.inputStream else connection.errorStream
            val text = stream?.bufferedReader()?.use { it.readText() }.orEmpty()
            code to text
        } catch (error: Exception) {
            -1 to (error.message ?: "Network error. Check your internet connection and try again.")
        } finally {
            connection?.disconnect()
        }
    }
}
