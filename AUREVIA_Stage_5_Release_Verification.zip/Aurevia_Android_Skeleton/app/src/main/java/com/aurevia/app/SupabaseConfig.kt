package com.aurevia.app

/** Public client configuration. Never place a Supabase service-role key in the Android app. */
internal object SupabaseConfig {
    const val BASE_URL = "https://muilsyuudpscpvandgnf.supabase.co"
    // Supabase publishable key is designed for client apps; authorization still depends on RLS.
    const val PUBLISHABLE_KEY = "sb_publishable_uAylwkAS7VBTuN3trJVHcQ_Va7g6LXy"
}
