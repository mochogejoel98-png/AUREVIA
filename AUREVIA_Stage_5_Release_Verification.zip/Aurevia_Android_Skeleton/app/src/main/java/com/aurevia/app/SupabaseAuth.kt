package com.aurevia.app

import android.content.Context
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import android.util.Base64
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.security.KeyStore
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec

/** Supabase Auth REST client with encrypted, persistent Android Keystore session storage. */
object SupabaseAuth {
    private const val PREFS = "aurevia_secure_session"
    private const val SESSION_KEY = "session_blob"
    private const val KEY_ALIAS = "aurevia_session_encryption_v1"

    @Volatile private var accessToken: String? = null
    @Volatile private var refreshToken: String? = null
    @Volatile private var signedInEmail: String? = null
    @Volatile private var userId: String? = null
    @Volatile private var appContext: Context? = null

    data class Result(val success: Boolean, val message: String, val email: String? = null, val propertyId: String? = null)

    fun initialize(context: Context) {
        appContext = context.applicationContext
        loadStoredSession()
    }

    fun currentEmail(): String? = signedInEmail
    fun currentUserId(): String? = userId
    fun isSignedIn(): Boolean = !accessToken.isNullOrBlank() && !userId.isNullOrBlank()

    fun signUp(email: String, password: String, displayName: String): Result {
        val body = JSONObject().apply {
            put("email", email.trim())
            put("password", password)
            put("data", JSONObject().put("display_name", displayName.trim()))
        }
        val response = request("/auth/v1/signup", "POST", body, null)
        if (response.first !in 200..299) return Result(false, errorMessage(response.second))
        val json = parse(response.second)
        val token = json?.optString("access_token").orEmpty()
        if (token.isNotBlank()) {
            acceptSession(json!!, email.trim())
            return Result(true, "Your account was created and you are signed in.", signedInEmail)
        }
        return Result(true, "Account created. Check your email for the confirmation link, then sign in.", email.trim())
    }

    fun signIn(email: String, password: String): Result {
        val response = request("/auth/v1/token?grant_type=password", "POST", JSONObject().apply {
            put("email", email.trim())
            put("password", password)
        }, null)
        if (response.first !in 200..299) return Result(false, errorMessage(response.second))
        val json = parse(response.second)
        if (json?.optString("access_token").isNullOrBlank()) return Result(false, "Sign-in response did not contain a session. Please try again.")
        acceptSession(json!!, email.trim())
        return Result(true, "You are signed in. Your session is saved securely on this device.", signedInEmail)
    }

    /** Refresh the saved session on app launch; Supabase rotates refresh tokens. */
    fun restoreSession(): Boolean {
        val refresh = refreshToken ?: return false
        val response = request("/auth/v1/token?grant_type=refresh_token", "POST", JSONObject().put("refresh_token", refresh), null)
        if (response.first !in 200..299) {
            // Keep the encrypted refresh token during temporary network/server failures.
            // Clear it only when Supabase explicitly rejects the refresh token/session.
            if (response.first in 400..499) clearSession()
            return false
        }
        val json = parse(response.second) ?: run { clearSession(); return false }
        if (json.optString("access_token").isBlank() || json.optString("refresh_token").isBlank()) {
            clearSession(); return false
        }
        acceptSession(json, signedInEmail)
        return true
    }

    data class PropertiesResult(val success: Boolean, val body: String, val message: String)

    /** Public catalogue read: explicitly requests only published + approved rows and never selects address_private. */
    fun fetchPublishedProperties(): PropertiesResult {
        val columns = "id,owner_id,title,description,purpose,property_type,country_name,city,neighbourhood,currency_code,price,rent_period,bedrooms,bathrooms,floor_area,floor_area_unit,latitude,longitude,created_at"
        val path = "/rest/v1/properties?select=$columns&listing_status=eq.published&review_status=eq.approved&order=created_at.desc&limit=100"
        var connection: HttpURLConnection? = null
        return try {
            connection = (URL(SupabaseConfig.BASE_URL + path).openConnection() as HttpURLConnection).apply {
                requestMethod = "GET"
                connectTimeout = 15000
                readTimeout = 20000
                doOutput = false
                setRequestProperty("apikey", SupabaseConfig.PUBLISHABLE_KEY)
                // Public catalogue requests deliberately use the publishable key so they do not depend on
                // whether a user's saved access token has finished refreshing during app startup.
                setRequestProperty("Authorization", "Bearer ${SupabaseConfig.PUBLISHABLE_KEY}")
                setRequestProperty("Accept", "application/json")
            }
            val code = connection.responseCode
            val stream = if (code in 200..299) connection.inputStream else connection.errorStream
            val text = stream?.bufferedReader()?.use { it.readText() } ?: ""
            if (code in 200..299) PropertiesResult(true, text, "")
            else PropertiesResult(false, "", errorMessage(text))
        } catch (e: Exception) {
            PropertiesResult(false, "", e.message ?: "Could not connect. Check your internet connection and try again.")
        } finally {
            connection?.disconnect()
        }
    }


    data class FavoritesResult(val success: Boolean, val propertyIds: Set<String>, val message: String)

    /** Loads only the signed-in user's favorite property IDs; RLS enforces ownership. */
    fun fetchFavoriteIds(): FavoritesResult {
        val token = accessToken ?: return FavoritesResult(false, emptySet(), "Please sign in to view your saved properties.")
        val owner = userId ?: return FavoritesResult(false, emptySet(), "Your account session is incomplete. Please sign in again.")
        var connection: HttpURLConnection? = null
        return try {
            val encodedOwner = java.net.URLEncoder.encode(owner, "UTF-8")
            val path = "/rest/v1/favorites?select=property_id&user_id=eq.$encodedOwner&order=created_at.desc&limit=500"
            connection = (URL(SupabaseConfig.BASE_URL + path).openConnection() as HttpURLConnection).apply {
                requestMethod = "GET"; connectTimeout = 15000; readTimeout = 20000
                setRequestProperty("apikey", SupabaseConfig.PUBLISHABLE_KEY)
                setRequestProperty("Authorization", "Bearer $token")
                setRequestProperty("Accept", "application/json")
            }
            val code = connection.responseCode
            val body = (if (code in 200..299) connection.inputStream else connection.errorStream)
                ?.bufferedReader()?.use { it.readText() }.orEmpty()
            if (code !in 200..299) return FavoritesResult(false, emptySet(), errorMessage(body))
            val rows = org.json.JSONArray(body)
            val ids = (0 until rows.length()).mapNotNull { i ->
                rows.optJSONObject(i)?.optString("property_id")?.takeIf { it.isNotBlank() }
            }.toSet()
            FavoritesResult(true, ids, "")
        } catch (e: Exception) {
            FavoritesResult(false, emptySet(), e.message ?: "Could not load saved properties.")
        } finally { connection?.disconnect() }
    }

    /** Add a favorite for the authenticated account. Duplicate rows are ignored safely. */
    fun addFavorite(propertyId: String): Result {
        val token = accessToken ?: return Result(false, "Please sign in to save properties.")
        val owner = userId ?: return Result(false, "Your account session is incomplete. Please sign in again.")
        val body = JSONObject().put("user_id", owner).put("property_id", propertyId)
        val response = request("/rest/v1/favorites", "POST", body, token, "resolution=ignore-duplicates,return=minimal")
        return if (response.first in 200..299) Result(true, "Property saved to your AUREVIA account.")
            else Result(false, errorMessage(response.second))
    }

    /** Remove a favorite belonging to the authenticated account. */
    fun removeFavorite(propertyId: String): Result {
        val token = accessToken ?: return Result(false, "Please sign in to manage saved properties.")
        val owner = userId ?: return Result(false, "Your account session is incomplete. Please sign in again.")
        val encodedOwner = java.net.URLEncoder.encode(owner, "UTF-8")
        val encodedProperty = java.net.URLEncoder.encode(propertyId, "UTF-8")
        var connection: HttpURLConnection? = null
        return try {
            val path = "/rest/v1/favorites?user_id=eq.$encodedOwner&property_id=eq.$encodedProperty"
            connection = (URL(SupabaseConfig.BASE_URL + path).openConnection() as HttpURLConnection).apply {
                requestMethod = "DELETE"; connectTimeout = 15000; readTimeout = 20000
                setRequestProperty("apikey", SupabaseConfig.PUBLISHABLE_KEY)
                setRequestProperty("Authorization", "Bearer $token")
                setRequestProperty("Prefer", "return=minimal")
            }
            val code = connection.responseCode
            val body = (if (code in 200..299) connection.inputStream else connection.errorStream)
                ?.bufferedReader()?.use { it.readText() }.orEmpty()
            if (code in 200..299) Result(true, "Property removed from your saved list.")
            else Result(false, errorMessage(body))
        } catch (e: Exception) {
            Result(false, e.message ?: "Could not remove this saved property.")
        } finally { connection?.disconnect() }
    }

    fun createProperty(payload: JSONObject): Result {
        val token = accessToken ?: return Result(false, "Please sign in again before adding a property.")
        if (userId.isNullOrBlank()) return Result(false, "Your account session is incomplete. Please sign in again.")
        val response = request("/rest/v1/properties", "POST", payload, token, "return=representation")
        if (response.first !in 200..299) return Result(false, errorMessage(response.second))
        val rows = try { org.json.JSONArray(response.second) } catch (_: Exception) { null }
        val propertyId = rows?.optJSONObject(0)?.optString("id")?.takeIf { it.isNotBlank() }
        return Result(true, "Your property draft was saved to AUREVIA. It is not public until reviewed and approved.", propertyId = propertyId)
    }


    data class RoomRecord(val id: String, val propertyId: String, val roomNumber: String, val category: String, val rentAmount: Double, val currencyCode: String, val status: String, val description: String)
    data class RoomsResult(val success: Boolean, val items: List<RoomRecord>, val message: String)

    /** Room inventory is always scoped to one property; Postgres RLS verifies property ownership. */
    fun fetchRooms(propertyId: String): RoomsResult {
        val token = accessToken ?: return RoomsResult(false, emptyList(), "Please sign in again to manage rooms.")
        return try {
            val pid = java.net.URLEncoder.encode(propertyId, "UTF-8")
            val path = "/rest/v1/property_rooms?select=id,property_id,room_number,category,rent_amount,currency_code,status,description&property_id=eq.$pid&order=room_number.asc"
            var connection: HttpURLConnection? = null
            val pair = try {
                connection = (URL(SupabaseConfig.BASE_URL + path).openConnection() as HttpURLConnection).apply {
                    requestMethod = "GET"; connectTimeout = 15000; readTimeout = 20000
                    setRequestProperty("apikey", SupabaseConfig.PUBLISHABLE_KEY); setRequestProperty("Authorization", "Bearer $token"); setRequestProperty("Accept", "application/json")
                }
                val code = connection.responseCode
                Pair(code, (if (code in 200..299) connection.inputStream else connection.errorStream)?.bufferedReader()?.use { it.readText() }.orEmpty())
            } finally { connection?.disconnect() }
            val code = pair.first; val body = pair.second
            if (code !in 200..299) return RoomsResult(false, emptyList(), errorMessage(body))
            val rows = org.json.JSONArray(body)
            val items = (0 until rows.length()).mapNotNull { i -> rows.optJSONObject(i)?.let { r ->
                RoomRecord(r.optString("id"), r.optString("property_id"), r.optString("room_number"), r.optString("category"), r.optDouble("rent_amount"), r.optString("currency_code", "KES"), r.optString("status", "available"), r.optString("description"))
            } }
            RoomsResult(true, items, "")
        } catch (e: Exception) { RoomsResult(false, emptyList(), e.message ?: "Could not load rooms.") }
    }

    fun createRoom(propertyId: String, roomNumber: String, category: String, rentAmount: Double, description: String): Result {
        val token = accessToken ?: return Result(false, "Please sign in again.")
        val owner = userId ?: return Result(false, "Your account session is incomplete.")
        if (roomNumber.isBlank() || category.isBlank() || rentAmount < 0) return Result(false, "Enter a room number, category and a valid rent amount.")
        val body = JSONObject().put("property_id", propertyId).put("owner_id", owner).put("room_number", roomNumber.trim()).put("category", category.trim()).put("rent_amount", rentAmount).put("currency_code", "KES").put("status", "available").put("description", description.trim())
        val (code, response) = request("/rest/v1/property_rooms", "POST", body, token, "return=minimal")
        return if (code in 200..299) Result(true, "Room added successfully.") else Result(false, errorMessage(response))
    }

    fun updateRoomStatus(roomId: String, status: String): Result {
        val token = accessToken ?: return Result(false, "Please sign in again.")
        val body = JSONObject().put("p_room_id", roomId).put("p_status", status)
        val (code, response) = request("/rest/v1/rpc/set_property_room_status", "POST", body, token)
        return if (code in 200..299) Result(true, "Room status updated to ${status.replaceFirstChar { it.uppercase() }}.") else Result(false, errorMessage(response))
    }


    data class FacilityRecord(val id: String, val propertyId: String, val name: String, val category: String, val notes: String)
    data class FacilitiesResult(val success: Boolean, val items: List<FacilityRecord>, val message: String)

    /** Public visitors see facilities only for approved listings; signed-in owners can also see their drafts via RLS. */
    fun fetchPropertyFacilities(propertyId: String, ownerView: Boolean = false): FacilitiesResult {
        val token: String = if (ownerView) {
            accessToken ?: return FacilitiesResult(false, emptyList(), "Please sign in again to manage facilities.")
        } else SupabaseConfig.PUBLISHABLE_KEY
        return try {
            val pid = java.net.URLEncoder.encode(propertyId, "UTF-8")
            val path = "/rest/v1/property_facilities?select=id,property_id,facility_name,category,notes&property_id=eq.$pid&order=category.asc,facility_name.asc&limit=200"
            var connection: HttpURLConnection? = null
            val pair = try {
                connection = (URL(SupabaseConfig.BASE_URL + path).openConnection() as HttpURLConnection).apply {
                    requestMethod = "GET"; connectTimeout = 12000; readTimeout = 18000
                    setRequestProperty("apikey", SupabaseConfig.PUBLISHABLE_KEY)
                    setRequestProperty("Authorization", "Bearer $token")
                    setRequestProperty("Accept", "application/json")
                }
                val code = connection.responseCode
                Pair(code, (if (code in 200..299) connection.inputStream else connection.errorStream)?.bufferedReader()?.use { it.readText() }.orEmpty())
            } finally { connection?.disconnect() }
            if (pair.first !in 200..299) return FacilitiesResult(false, emptyList(), errorMessage(pair.second))
            val rows = org.json.JSONArray(pair.second)
            val items = (0 until rows.length()).mapNotNull { i -> rows.optJSONObject(i)?.let { r ->
                FacilityRecord(r.optString("id"), r.optString("property_id"), r.optString("facility_name"), r.optString("category", "other"), r.optString("notes"))
            } }
            FacilitiesResult(true, items, "")
        } catch (e: Exception) { FacilitiesResult(false, emptyList(), e.message ?: "Could not load facilities.") }
    }

    fun createPropertyFacility(propertyId: String, name: String, category: String, notes: String = ""): Result {
        val token = accessToken ?: return Result(false, "Please sign in again to manage facilities.")
        if (name.trim().length !in 2..100) return Result(false, "Facility name must be 2–100 characters.")
        val body = JSONObject().put("property_id", propertyId).put("facility_name", name.trim())
            .put("category", category).put("notes", notes.trim())
        val response = request("/rest/v1/property_facilities", "POST", body, token, "return=representation")
        return if (response.first in 200..299) Result(true, "Facility added to this property.") else Result(false, errorMessage(response.second))
    }

    fun deletePropertyFacility(facilityId: String): Result {
        val token = accessToken ?: return Result(false, "Please sign in again to manage facilities.")
        val id = java.net.URLEncoder.encode(facilityId, "UTF-8")
        var connection: HttpURLConnection? = null
        return try {
            connection = (URL(SupabaseConfig.BASE_URL + "/rest/v1/property_facilities?id=eq.$id").openConnection() as HttpURLConnection).apply {
                requestMethod = "DELETE"; connectTimeout = 12000; readTimeout = 18000
                setRequestProperty("apikey", SupabaseConfig.PUBLISHABLE_KEY)
                setRequestProperty("Authorization", "Bearer $token")
                setRequestProperty("Accept", "application/json")
            }
            val code = connection.responseCode
            val body = (if (code in 200..299) connection.inputStream else connection.errorStream)?.bufferedReader()?.use { it.readText() }.orEmpty()
            if (code in 200..299) Result(true, "Facility removed.") else Result(false, errorMessage(body))
        } catch (e: Exception) { Result(false, e.message ?: "Could not remove facility.") }
        finally { connection?.disconnect() }
    }

    data class TenantRecord(
        val id: String, val propertyId: String, val roomId: String?, val fullName: String,
        val phone: String, val email: String, val rentAmount: Double, val currencyCode: String,
        val leaseStart: String, val leaseEnd: String, val notes: String, val status: String,
        val roomNumber: String
    )
    data class TenantsResult(val success: Boolean, val items: List<TenantRecord>, val message: String)

    /** GET tenant records for one property. RLS and the RPC enforce owner access on the server. */
    fun fetchPropertyTenants(propertyId: String): TenantsResult {
        val token = accessToken ?: return TenantsResult(false, emptyList(), "Please sign in again to manage tenants.")
        return try {
            val pid = java.net.URLEncoder.encode(propertyId, "UTF-8")
            val path = "/rest/v1/property_tenants?select=id,property_id,room_id,full_name,phone,email,rent_amount,currency_code,lease_start,lease_end,notes,status,property_rooms(room_number)&property_id=eq.$pid&order=created_at.desc&limit=500"
            var connection: HttpURLConnection? = null
            val pair = try {
                connection = (URL(SupabaseConfig.BASE_URL + path).openConnection() as HttpURLConnection).apply {
                    requestMethod = "GET"; connectTimeout = 12000; readTimeout = 18000; doOutput = false
                    setRequestProperty("apikey", SupabaseConfig.PUBLISHABLE_KEY); setRequestProperty("Authorization", "Bearer $token")
                    setRequestProperty("Accept", "application/json")
                }
                val code = connection.responseCode
                Pair(code, (if (code in 200..299) connection.inputStream else connection.errorStream)?.bufferedReader()?.use { it.readText() }.orEmpty())
            } finally { connection?.disconnect() }
            if (pair.first !in 200..299) return TenantsResult(false, emptyList(), errorMessage(pair.second))
            val rows = org.json.JSONArray(pair.second)
            val items = (0 until rows.length()).mapNotNull { i -> rows.optJSONObject(i)?.let { r ->
                val room = r.optJSONObject("property_rooms")
                TenantRecord(r.optString("id"), r.optString("property_id"), r.optString("room_id").takeIf { it.isNotBlank() && it != "null" },
                    r.optString("full_name"), r.optString("phone"), r.optString("email"), r.optDouble("rent_amount"),
                    r.optString("currency_code", "KES"), r.optString("lease_start"), r.optString("lease_end"), r.optString("notes"),
                    r.optString("status", "active"), room?.optString("room_number") ?: "Unassigned")
            } }
            TenantsResult(true, items, "")
        } catch (e: Exception) { TenantsResult(false, emptyList(), e.message ?: "Could not load tenants. Check your connection and retry.") }
    }

    /** Tenant creation is transactional on PostgreSQL; the server derives the owner from auth.uid(). */
    fun createPropertyTenant(propertyId: String, roomId: String, fullName: String, phone: String, email: String,
                             rentAmount: Double, leaseStart: String, leaseEnd: String, notes: String): Result {
        val token = accessToken ?: return Result(false, "Please sign in again.")
        if (fullName.isBlank() || phone.isBlank() || rentAmount < 0 || leaseStart.isBlank())
            return Result(false, "Enter the tenant name, phone, valid rent and lease start date.")
        if (leaseEnd.isNotBlank() && leaseEnd < leaseStart) return Result(false, "Lease end date must not be before the start date.")
        val body = JSONObject().put("p_property_id", propertyId).put("p_room_id", roomId)
            .put("p_full_name", fullName.trim()).put("p_phone", phone.trim())
            .put("p_email", email.trim().ifBlank { JSONObject.NULL }).put("p_rent_amount", rentAmount)
            .put("p_lease_start", leaseStart).put("p_lease_end", leaseEnd.ifBlank { JSONObject.NULL })
            .put("p_notes", notes.trim())
        val (code, response) = request("/rest/v1/rpc/create_property_tenant", "POST", body, token)
        return if (code in 200..299) Result(true, "Tenant added and room occupancy updated.") else Result(false, errorMessage(response))
    }

    fun endPropertyTenancy(tenantId: String): Result {
        val token = accessToken ?: return Result(false, "Please sign in again.")
        val (code, response) = request("/rest/v1/rpc/end_property_tenancy", "POST", JSONObject().put("p_tenant_id", tenantId), token)
        return if (code in 200..299) Result(true, "Tenancy ended and the room was released.") else Result(false, errorMessage(response))
    }

    data class FinancialRecord(
        val id: String, val propertyId: String, val recordType: String, val category: String,
        val amount: Double, val currencyCode: String, val transactionDate: String,
        val description: String, val paymentReference: String, val createdAt: String
    )
    data class FinancialRecordsResult(val success: Boolean, val items: List<FinancialRecord>, val message: String)

    /** Finance data is private to the signed-in property owner; RLS is enforced by PostgreSQL. */
    fun fetchPropertyFinancialRecords(propertyId: String): FinancialRecordsResult {
        val token = accessToken ?: return FinancialRecordsResult(false, emptyList(), "Please sign in again to view financial records.")
        return try {
            val pid = java.net.URLEncoder.encode(propertyId, "UTF-8")
            val path = "/rest/v1/property_financial_records?select=id,property_id,record_type,category,amount,currency_code,transaction_date,description,payment_reference,created_at&property_id=eq.$pid&order=transaction_date.desc,created_at.desc&limit=500"
            var connection: HttpURLConnection? = null
            val pair = try {
                connection = (URL(SupabaseConfig.BASE_URL + path).openConnection() as HttpURLConnection).apply {
                    requestMethod = "GET"; connectTimeout = 12000; readTimeout = 18000
                    setRequestProperty("apikey", SupabaseConfig.PUBLISHABLE_KEY); setRequestProperty("Authorization", "Bearer $token")
                    setRequestProperty("Accept", "application/json")
                }
                val code = connection.responseCode
                Pair(code, (if (code in 200..299) connection.inputStream else connection.errorStream)?.bufferedReader()?.use { it.readText() }.orEmpty())
            } finally { connection?.disconnect() }
            if (pair.first !in 200..299) return FinancialRecordsResult(false, emptyList(), errorMessage(pair.second))
            val rows = org.json.JSONArray(pair.second)
            val items = (0 until rows.length()).mapNotNull { i -> rows.optJSONObject(i)?.let { r ->
                FinancialRecord(r.optString("id"), r.optString("property_id"), r.optString("record_type"), r.optString("category"),
                    r.optDouble("amount"), r.optString("currency_code", "KES"), r.optString("transaction_date"),
                    r.optString("description"), r.optString("payment_reference"), r.optString("created_at"))
            } }
            FinancialRecordsResult(true, items, "")
        } catch (e: Exception) { FinancialRecordsResult(false, emptyList(), e.message ?: "Could not load financial records.") }
    }

    /** Insert-only ledger entries preserve an audit trail; ownership is checked again by database RLS. */
    fun createPropertyFinancialRecord(propertyId: String, recordType: String, category: String, amount: Double,
                                      currencyCode: String, transactionDate: String, description: String,
                                      paymentReference: String): Result {
        val token = accessToken ?: return Result(false, "Please sign in again.")
        if (recordType !in setOf("income", "expense")) return Result(false, "Choose income or expense.")
        if (category.trim().length !in 2..80 || amount <= 0.0 || !amount.isFinite()) return Result(false, "Enter a category and an amount greater than zero.")
        if (!currencyCode.matches(Regex("^[A-Z]{3}$"))) return Result(false, "Currency must be a three-letter code such as KES, USD or EUR.")
        if (!transactionDate.matches(Regex("^\\d{4}-\\d{2}-\\d{2}$"))) return Result(false, "Use a date in YYYY-MM-DD format.")
        if (description.length > 1000 || paymentReference.length > 120) return Result(false, "Description or reference is too long.")
        val body = JSONObject().put("property_id", propertyId).put("record_type", recordType)
            .put("category", category.trim()).put("amount", amount).put("currency_code", currencyCode)
            .put("transaction_date", transactionDate).put("description", description.trim())
            .put("payment_reference", paymentReference.trim())
        val (code, response) = request("/rest/v1/property_financial_records", "POST", body, token, "return=minimal")
        return if (code in 200..299) Result(true, "Financial record saved securely.") else Result(false, errorMessage(response))
    }

    data class PropertyConversation(
        val id: String, val propertyId: String, val requesterId: String, val ownerId: String,
        val propertyTitle: String, val propertyCity: String, val createdAt: String
    )
    data class ConversationsResult(val success: Boolean, val items: List<PropertyConversation>, val message: String)
    data class PropertyMessage(val id: String, val conversationId: String, val senderId: String, val body: String, val createdAt: String)
    data class MessagesResult(val success: Boolean, val items: List<PropertyMessage>, val message: String)

    /** Starts or reuses a private conversation; database RLS verifies listing ownership and participation. */
    fun startOrGetPropertyConversation(propertyId: String, ownerId: String): Result {
        val token = accessToken ?: return Result(false, "Please sign in before contacting a property owner.")
        val requester = userId ?: return Result(false, "Your session is incomplete. Please sign in again.")
        if (propertyId.isBlank() || ownerId.isBlank()) return Result(false, "This listing is missing owner contact information. Refresh the listings and try again.")
        if (requester == ownerId) return Result(false, "You cannot start a conversation with yourself about your own property.")
        val existing = getJsonArray("/rest/v1/property_conversations?select=id&property_id=eq.$propertyId&requester_id=eq.$requester&limit=1", token)
        if (existing.first in 200..299) {
            val rows = org.json.JSONArray(existing.second)
            if (rows.length() > 0) return Result(true, "Conversation opened.", propertyId = rows.getJSONObject(0).optString("id"))
        } else return Result(false, errorMessage(existing.second))
        val body = JSONObject().put("property_id", propertyId).put("requester_id", requester).put("owner_id", ownerId)
        val created = request("/rest/v1/property_conversations", "POST", body, token, "return=representation")
        if (created.first in 200..299) {
            val rows = try { org.json.JSONArray(created.second) } catch (_: Exception) { org.json.JSONArray() }
            if (rows.length() > 0) return Result(true, "Conversation started.", propertyId = rows.getJSONObject(0).optString("id"))
        }
        // A concurrent tap may have created the unique conversation first; safely re-fetch it.
        val retry = getJsonArray("/rest/v1/property_conversations?select=id&property_id=eq.$propertyId&requester_id=eq.$requester&limit=1", token)
        if (retry.first in 200..299) {
            val rows = org.json.JSONArray(retry.second)
            if (rows.length() > 0) return Result(true, "Conversation opened.", propertyId = rows.getJSONObject(0).optString("id"))
        }
        return Result(false, errorMessage(created.second))
    }

    fun fetchPropertyConversations(): ConversationsResult {
        val token = accessToken ?: return ConversationsResult(false, emptyList(), "Please sign in to view your inbox.")
        val uid = userId ?: return ConversationsResult(false, emptyList(), "Your session is incomplete. Please sign in again.")
        val result = getJsonArray("/rest/v1/property_conversations?select=id,property_id,requester_id,owner_id,created_at,properties(title,city)&or=(requester_id.eq.$uid,owner_id.eq.$uid)&order=created_at.desc&limit=100", token)
        if (result.first !in 200..299) return ConversationsResult(false, emptyList(), errorMessage(result.second))
        return try {
            val rows = org.json.JSONArray(result.second)
            val items = (0 until rows.length()).mapNotNull { i -> rows.optJSONObject(i)?.let { r ->
                val property = r.optJSONObject("properties")
                PropertyConversation(r.optString("id"), r.optString("property_id"), r.optString("requester_id"), r.optString("owner_id"),
                    property?.optString("title").orEmpty().ifBlank { "Property conversation" }, property?.optString("city").orEmpty(), r.optString("created_at"))
            } }
            ConversationsResult(true, items, "")
        } catch (e: Exception) { ConversationsResult(false, emptyList(), e.message ?: "Could not read your conversations.") }
    }

    fun fetchPropertyMessages(conversationId: String): MessagesResult {
        val token = accessToken ?: return MessagesResult(false, emptyList(), "Please sign in to view messages.")
        val result = getJsonArray("/rest/v1/property_messages?select=id,conversation_id,sender_id,body,created_at&conversation_id=eq.$conversationId&order=created_at.asc&limit=500", token)
        if (result.first !in 200..299) return MessagesResult(false, emptyList(), errorMessage(result.second))
        return try {
            val rows = org.json.JSONArray(result.second)
            val items = (0 until rows.length()).mapNotNull { i -> rows.optJSONObject(i)?.let { r ->
                PropertyMessage(r.optString("id"), r.optString("conversation_id"), r.optString("sender_id"), r.optString("body"), r.optString("created_at"))
            } }
            MessagesResult(true, items, "")
        } catch (e: Exception) { MessagesResult(false, emptyList(), e.message ?: "Could not read messages.") }
    }

    fun sendPropertyMessage(conversationId: String, bodyText: String): Result {
        val token = accessToken ?: return Result(false, "Please sign in to send a message.")
        val sender = userId ?: return Result(false, "Your session is incomplete. Please sign in again.")
        val message = bodyText.trim()
        if (message.isEmpty() || message.length > 4000) return Result(false, "Enter a message between 1 and 4000 characters.")
        val payload = JSONObject().put("conversation_id", conversationId).put("sender_id", sender).put("body", message)
        val result = request("/rest/v1/property_messages", "POST", payload, token, "return=minimal")
        return if (result.first in 200..299) Result(true, "Message sent.") else Result(false, errorMessage(result.second))
    }

    private fun getJsonArray(path: String, token: String): Pair<Int, String> {
        var connection: HttpURLConnection? = null
        return try {
            connection = (URL(SupabaseConfig.BASE_URL + path).openConnection() as HttpURLConnection).apply {
                requestMethod = "GET"; connectTimeout = 12000; readTimeout = 18000; doOutput = false
                setRequestProperty("apikey", SupabaseConfig.PUBLISHABLE_KEY); setRequestProperty("Authorization", "Bearer $token")
                setRequestProperty("Accept", "application/json")
            }
            val code = connection.responseCode
            Pair(code, (if (code in 200..299) connection.inputStream else connection.errorStream)?.bufferedReader()?.use { it.readText() }.orEmpty())
        } catch (e: Exception) { Pair(-1, e.message ?: "Network error. Check your connection and retry.") }
        finally { connection?.disconnect() }
    }

    data class OwnedProperty(val id: String, val title: String, val city: String, val status: String, val reviewStatus: String, val createdAt: String, val photoUrls: List<String> = emptyList())
    data class OwnedPropertiesResult(val success: Boolean, val items: List<OwnedProperty>, val message: String)

    /** Fetch only the signed-in owner's properties; RLS remains the final access-control boundary. */
    fun fetchMyProperties(): OwnedPropertiesResult {
        val token = accessToken ?: return OwnedPropertiesResult(false, emptyList(), "Please sign in again to view your drafts.")
        val owner = userId ?: return OwnedPropertiesResult(false, emptyList(), "Your account session is incomplete.")
        var connection: HttpURLConnection? = null
        return try {
            val encodedOwner = java.net.URLEncoder.encode(owner, "UTF-8")
            val path = "/rest/v1/properties?select=id,title,city,listing_status,review_status,created_at&owner_id=eq.$encodedOwner&order=created_at.desc&limit=100"
            connection = (URL(SupabaseConfig.BASE_URL + path).openConnection() as HttpURLConnection).apply {
                requestMethod = "GET"; connectTimeout = 15000; readTimeout = 20000
                setRequestProperty("apikey", SupabaseConfig.PUBLISHABLE_KEY)
                setRequestProperty("Authorization", "Bearer $token")
                setRequestProperty("Accept", "application/json")
            }
            val code = connection.responseCode
            val body = (if (code in 200..299) connection.inputStream else connection.errorStream)?.bufferedReader()?.use { it.readText() }.orEmpty()
            if (code !in 200..299) return OwnedPropertiesResult(false, emptyList(), errorMessage(body))
            val rows = org.json.JSONArray(body)
            val basicItems = (0 until rows.length()).mapNotNull { i ->
                val row = rows.optJSONObject(i) ?: return@mapNotNull null
                OwnedProperty(row.optString("id"), row.optString("title", "Untitled property"), row.optString("city"), row.optString("listing_status", "draft"), row.optString("review_status", "pending"), row.optString("created_at"))
            }
            val photoMap = mutableMapOf<String, MutableList<String>>()
            if (basicItems.isNotEmpty()) {
                var photoConnection: HttpURLConnection? = null
                try {
                    val ids = basicItems.joinToString(",") { it.id }
                    val photoPath = "/rest/v1/property_photos?select=property_id,storage_path&property_id=in.($ids)&order=display_order.asc"
                    photoConnection = (URL(SupabaseConfig.BASE_URL + photoPath).openConnection() as HttpURLConnection).apply {
                        requestMethod = "GET"; connectTimeout = 12000; readTimeout = 15000
                        setRequestProperty("apikey", SupabaseConfig.PUBLISHABLE_KEY); setRequestProperty("Authorization", "Bearer $token")
                        setRequestProperty("Accept", "application/json")
                    }
                    if (photoConnection.responseCode in 200..299) {
                        val photoRows = org.json.JSONArray(photoConnection.inputStream.bufferedReader().use { it.readText() })
                        for (i in 0 until photoRows.length()) {
                            val photo = photoRows.optJSONObject(i) ?: continue
                            val propertyId = photo.optString("property_id")
                            val storagePath = photo.optString("storage_path")
                            if (propertyId.isNotBlank() && storagePath.isNotBlank()) {
                                val encoded = storagePath.split("/").joinToString("/") { java.net.URLEncoder.encode(it, "UTF-8").replace("+", "%20") }
                                photoMap.getOrPut(propertyId) { mutableListOf() }.add("${SupabaseConfig.BASE_URL}/storage/v1/object/public/property-photos/$encoded")
                            }
                        }
                    }
                } catch (_: Exception) { /* Property records remain visible even if photo metadata cannot be loaded. */ }
                finally { photoConnection?.disconnect() }
            }
            val items = basicItems.map { it.copy(photoUrls = photoMap[it.id]?.toList() ?: emptyList()) }
            OwnedPropertiesResult(true, items, "")
        } catch (e: Exception) {
            OwnedPropertiesResult(false, emptyList(), e.message ?: "Could not load your properties. Please try again.")
        } finally { connection?.disconnect() }
    }

    data class ViewingAppointment(
        val id: String,
        val propertyId: String,
        val requesterId: String,
        val propertyTitle: String,
        val propertyCity: String,
        val requestedAt: String,
        val message: String,
        val status: String
    )
    data class ViewingRequestsResult(val success: Boolean, val items: List<ViewingAppointment>, val message: String)

    /** Fetches requests for the signed-in requester or for properties owned by that account. */
    fun fetchViewingRequests(incoming: Boolean): ViewingRequestsResult {
        val token = accessToken ?: return ViewingRequestsResult(false, emptyList(), "Please sign in to view appointments.")
        val owner = userId ?: return ViewingRequestsResult(false, emptyList(), "Your account session is incomplete.")
        var connection: HttpURLConnection? = null
        return try {
            val encodedOwner = java.net.URLEncoder.encode(owner, "UTF-8")
            val filter = if (incoming) "&properties.owner_id=eq.$encodedOwner" else "&requester_id=eq.$encodedOwner"
            val path = "/rest/v1/viewing_requests?select=id,property_id,requester_id,requested_at,message,status,properties(title,city,owner_id)&order=requested_at.asc&limit=100$filter"
            connection = (URL(SupabaseConfig.BASE_URL + path).openConnection() as HttpURLConnection).apply {
                requestMethod = "GET"; connectTimeout = 15000; readTimeout = 20000
                setRequestProperty("apikey", SupabaseConfig.PUBLISHABLE_KEY)
                setRequestProperty("Authorization", "Bearer $token")
                setRequestProperty("Accept", "application/json")
            }
            val code = connection.responseCode
            val body = (if (code in 200..299) connection.inputStream else connection.errorStream)
                ?.bufferedReader()?.use { it.readText() }.orEmpty()
            if (code !in 200..299) return ViewingRequestsResult(false, emptyList(), errorMessage(body))
            val rows = org.json.JSONArray(body)
            val items = (0 until rows.length()).mapNotNull { i ->
                val row = rows.optJSONObject(i) ?: return@mapNotNull null
                val property = row.optJSONObject("properties")
                ViewingAppointment(
                    id = row.optString("id"),
                    propertyId = row.optString("property_id"),
                    requesterId = row.optString("requester_id"),
                    propertyTitle = property?.optString("title")?.takeIf { !it.isNullOrBlank() } ?: "Property",
                    propertyCity = property?.optString("city") ?: "",
                    requestedAt = row.optString("requested_at"),
                    message = row.optString("message"),
                    status = row.optString("status", "pending")
                ).takeIf { it.id.isNotBlank() }
            }
            ViewingRequestsResult(true, items, "")
        } catch (e: Exception) {
            ViewingRequestsResult(false, emptyList(), e.message ?: "Could not load viewing requests.")
        } finally { connection?.disconnect() }
    }

    /** Creates a pending viewing request; the database validates ownership, publication and future time. */
    fun createViewingRequest(propertyId: String, requestedAtUtc: String, message: String): Result {
        val token = accessToken ?: return Result(false, "Please sign in before requesting a viewing.")
        val requester = userId ?: return Result(false, "Your account session is incomplete. Please sign in again.")
        val payload = JSONObject().apply {
            put("property_id", propertyId)
            put("requester_id", requester)
            put("requested_at", requestedAtUtc)
            put("message", message.trim())
            put("status", "pending")
        }
        val response = request("/rest/v1/viewing_requests", "POST", payload, token, "return=minimal")
        return if (response.first in 200..299) Result(true, "Viewing request sent. The property owner must confirm it.")
            else Result(false, errorMessage(response.second))
    }

    /** Status changes are also restricted by a database trigger, not just by this UI. */
    fun updateViewingRequestStatus(requestId: String, status: String): Result {
        val token = accessToken ?: return Result(false, "Please sign in to manage viewing requests.")
        if (status !in setOf("accepted", "declined", "cancelled", "completed")) {
            return Result(false, "That appointment action is not supported.")
        }
        val payload = JSONObject().put("p_request_id", requestId).put("p_status", status)
        val response = request("/rest/v1/rpc/respond_to_viewing_request", "POST", payload, token)
        return if (response.first in 200..299) Result(true, "Viewing request updated: ${status.replaceFirstChar { it.uppercase() }}.")
            else Result(false, errorMessage(response.second))
    }

    data class PhotoResult(val success: Boolean, val message: String, val publicUrl: String? = null)

    /** Uploads a picked image to the owner's folder, then records its metadata. */
    fun uploadPropertyPhoto(context: Context, uri: android.net.Uri, propertyId: String, order: Int): PhotoResult {
        val token = accessToken ?: return PhotoResult(false, "Please sign in again before uploading photos.")
        val owner = userId ?: return PhotoResult(false, "Your account session is incomplete.")
        var connection: HttpURLConnection? = null
        var uploadedPath: String? = null
        return try {
            val mime = context.contentResolver.getType(uri)?.lowercase() ?: return PhotoResult(false, "This file type could not be identified.")
            if (mime !in listOf("image/jpeg", "image/png", "image/webp")) return PhotoResult(false, "Choose a JPEG, PNG or WebP image.")
            val bytes = context.contentResolver.openInputStream(uri)?.use { input ->
                val out = java.io.ByteArrayOutputStream()
                val buffer = ByteArray(8192)
                var total = 0
                while (true) {
                    val n = input.read(buffer); if (n < 0) break
                    total += n
                    if (total > 10 * 1024 * 1024) return PhotoResult(false, "Each photo must be 10 MB or smaller.")
                    out.write(buffer, 0, n)
                }
                out.toByteArray()
            } ?: return PhotoResult(false, "Could not read the selected photo.")
            if (bytes.isEmpty()) return PhotoResult(false, "The selected photo is empty.")
            val ext = when (mime) { "image/jpeg" -> "jpg"; "image/png" -> "png"; else -> "webp" }
            val filename = java.util.UUID.randomUUID().toString() + "." + ext
            val path = "$owner/$propertyId/$filename"
            val encoded = path.split("/").joinToString("/") { java.net.URLEncoder.encode(it, "UTF-8").replace("+", "%20") }
            connection = (URL("${SupabaseConfig.BASE_URL}/storage/v1/object/property-photos/$encoded").openConnection() as HttpURLConnection).apply {
                requestMethod = "POST"; connectTimeout = 20000; readTimeout = 30000; doOutput = true
                setRequestProperty("apikey", SupabaseConfig.PUBLISHABLE_KEY); setRequestProperty("Authorization", "Bearer $token")
                setRequestProperty("Content-Type", mime); setRequestProperty("x-upsert", "false")
            }
            connection.outputStream.use { it.write(bytes) }
            val code = connection.responseCode
            val response = (if (code in 200..299) connection.inputStream else connection.errorStream)?.bufferedReader()?.use { it.readText() }.orEmpty()
            if (code !in 200..299) return PhotoResult(false, errorMessage(response))
            uploadedPath = path
            val publicUrl = "${SupabaseConfig.BASE_URL}/storage/v1/object/public/property-photos/$encoded"
            val metadata = JSONObject().put("property_id", propertyId).put("storage_path", path)
                .put("caption", JSONObject.NULL).put("display_order", order)
            val inserted = request("/rest/v1/property_photos", "POST", metadata, token, "return=minimal")
            if (inserted.first !in 200..299) {
                // Best-effort cleanup prevents a successful upload being left without its metadata row.
                val deletePath = path.split("/").joinToString("/") { java.net.URLEncoder.encode(it, "UTF-8").replace("+", "%20") }
                val cleanup = (URL("${SupabaseConfig.BASE_URL}/storage/v1/object/property-photos/$deletePath").openConnection() as HttpURLConnection)
                try { cleanup.requestMethod = "DELETE"; cleanup.setRequestProperty("apikey", SupabaseConfig.PUBLISHABLE_KEY); cleanup.setRequestProperty("Authorization", "Bearer $token"); cleanup.responseCode } finally { cleanup.disconnect() }
                return PhotoResult(false, "Photo uploaded, but its listing record could not be saved: ${errorMessage(inserted.second)}")
            }
            PhotoResult(true, "Photo uploaded.", publicUrl)
        } catch (e: Exception) {
            PhotoResult(false, e.message ?: "Photo upload failed. Please try again.")
        } finally { connection?.disconnect() }
    }


    data class PropertyVideo(
        val id: String, val propertyId: String, val ownerId: String, val storagePath: String,
        val caption: String, val createdAt: String, val propertyTitle: String, val city: String,
        val purpose: String, val price: Double, val currency: String, val propertyType: String,
        val playbackUrl: String
    )
    data class PropertyVideosResult(val success: Boolean, val items: List<PropertyVideo>, val message: String)

    /** Reads approved public video metadata and creates short-lived signed URLs for private MP4 playback. */
    fun fetchPropertyVideos(): PropertyVideosResult {
        val path = "/rest/v1/property_videos?select=id,property_id,owner_id,storage_path,caption,created_at,properties(title,city,purpose,price,currency_code,property_type)&order=created_at.desc&limit=12"
        val (code, body) = request(path, "GET", JSONObject(), accessToken)
        if (code !in 200..299) return PropertyVideosResult(false, emptyList(), errorMessage(body))
        return try {
            val rows = org.json.JSONArray(body)
            val items = mutableListOf<PropertyVideo>()
            for (i in 0 until rows.length()) {
                val row = rows.optJSONObject(i) ?: continue
                val storagePath = row.optString("storage_path")
                if (storagePath.isBlank()) continue
                val encoded = storagePath.split("/").joinToString("/") {
                    java.net.URLEncoder.encode(it, "UTF-8").replace("+", "%20")
                }
                val sign = request("/storage/v1/object/sign/property-videos/$encoded", "POST",
                    JSONObject().put("expiresIn", 3600), accessToken)
                if (sign.first !in 200..299) continue
                val signedPath = parse(sign.second)?.optString("signedURL").orEmpty()
                if (signedPath.isBlank()) continue
                val playback = if (signedPath.startsWith("http")) signedPath else "${SupabaseConfig.BASE_URL}/storage/v1${if (signedPath.startsWith("/")) signedPath else "/$signedPath"}"
                val property = row.optJSONObject("properties") ?: JSONObject()
                items.add(PropertyVideo(
                    row.optString("id"), row.optString("property_id"), row.optString("owner_id"), storagePath,
                    row.optString("caption"), row.optString("created_at"), property.optString("title", "Property tour"),
                    property.optString("city"), property.optString("purpose"), property.optDouble("price", 0.0),
                    property.optString("currency_code", "KES"), property.optString("property_type", "property"), playback
                ))
            }
            PropertyVideosResult(true, items, "")
        } catch (e: Exception) {
            PropertyVideosResult(false, emptyList(), e.message ?: "Could not load property videos.")
        }
    }

    /** Uploads an MP4 directly from the selected document stream; private storage remains protected by RLS. */
    fun uploadPropertyVideo(context: Context, uri: android.net.Uri, propertyId: String, caption: String): Result {
        val token = accessToken ?: return Result(false, "Please sign in before uploading a property video.")
        val owner = userId ?: return Result(false, "Your account session is incomplete.")
        val mime = context.contentResolver.getType(uri)?.lowercase()
        if (mime != "video/mp4") return Result(false, "Choose an MP4 video. Other video formats are not supported yet.")
        var connection: HttpURLConnection? = null
        return try {
            val size = try { context.contentResolver.openAssetFileDescriptor(uri, "r")?.use { it.length } ?: -1L } catch (_: Exception) { -1L }
            if (size > 50L * 1024L * 1024L) return Result(false, "The video must be 50 MB or smaller.")
            val filename = java.util.UUID.randomUUID().toString() + ".mp4"
            val storagePath = "$owner/$propertyId/$filename"
            val encoded = storagePath.split("/").joinToString("/") { java.net.URLEncoder.encode(it, "UTF-8").replace("+", "%20") }
            val uploadConnection = (URL("${SupabaseConfig.BASE_URL}/storage/v1/object/property-videos/$encoded").openConnection() as HttpURLConnection).apply {
                requestMethod = "POST"; connectTimeout = 20000; readTimeout = 90000; doOutput = true
                setRequestProperty("apikey", SupabaseConfig.PUBLISHABLE_KEY); setRequestProperty("Authorization", "Bearer $token")
                setRequestProperty("Content-Type", "video/mp4"); setRequestProperty("x-upsert", "false")
            }
            connection = uploadConnection
            val input = context.contentResolver.openInputStream(uri) ?: return Result(false, "Could not read the selected video.")
            var total = 0L
            input.use { source -> uploadConnection.outputStream.use { target ->
                val buffer = ByteArray(32 * 1024)
                while (true) {
                    val count = source.read(buffer); if (count < 0) break
                    total += count
                    if (total > 50L * 1024L * 1024L) throw IllegalArgumentException("The video must be 50 MB or smaller.")
                    target.write(buffer, 0, count)
                }
            } }
            val responseCode = uploadConnection.responseCode
            val responseBody = (if (responseCode in 200..299) uploadConnection.inputStream else uploadConnection.errorStream)?.bufferedReader()?.use { it.readText() }.orEmpty()
            if (responseCode !in 200..299) return Result(false, errorMessage(responseBody))
            val metadata = JSONObject().put("property_id", propertyId).put("owner_id", owner)
                .put("storage_path", storagePath).put("caption", caption.trim().take(240))
            val inserted = request("/rest/v1/property_videos", "POST", metadata, token, "return=minimal")
            if (inserted.first !in 200..299) {
                request("/storage/v1/object/property-videos/$encoded", "DELETE", JSONObject(), token)
                return Result(false, "Video uploaded, but its property record could not be saved: ${errorMessage(inserted.second)}")
            }
            Result(true, "Property video uploaded. It appears in public discovery only after its property is published and approved.")
        } catch (e: Exception) {
            Result(false, e.message ?: "Video upload failed. Please try again.")
        } finally { connection?.disconnect() }
    }

    data class ModerationProperty(val id: String, val title: String, val city: String, val ownerId: String, val createdAt: String)
    data class PropertyReport(val id: String, val propertyId: String, val reason: String, val details: String, val status: String, val createdAt: String)
    data class VerificationDocument(val id: String, val propertyId: String, val documentType: String, val reviewStatus: String, val createdAt: String, val ownerId: String = "")
    data class QueueResult<T>(val success: Boolean, val items: List<T>, val message: String)

    fun submitPropertyReport(propertyId: String, reason: String, details: String): Result {
        val token = accessToken ?: return Result(false, "Please sign in before reporting a listing.")
        val reporter = userId ?: return Result(false, "Your account session is incomplete.")
        val cleanReason = reason.trim().take(80)
        val cleanDetails = details.trim().take(2000)
        if (cleanReason.isBlank()) return Result(false, "Choose a reason for the report.")
        val body = JSONObject().put("property_id", propertyId).put("reporter_id", reporter)
            .put("reason", cleanReason).put("details", if (cleanDetails.isBlank()) JSONObject.NULL else cleanDetails)
        val response = request("/rest/v1/property_reports", "POST", body, token, "return=minimal")
        return if (response.first in 200..299) Result(true, "Thank you. Your report has been submitted for review.")
        else Result(false, errorMessage(response.second))
    }

    /** Uploads evidence only to the private verification-documents bucket. */
    fun uploadVerificationDocument(context: Context, uri: android.net.Uri, propertyId: String, documentType: String): Result {
        val token = accessToken ?: return Result(false, "Please sign in before submitting verification.")
        val owner = userId ?: return Result(false, "Your account session is incomplete.")
        val allowedTypes = setOf("ownership_proof", "authorization_letter", "identity_document", "other")
        if (documentType !in allowedTypes) return Result(false, "Choose a valid document type.")
        var connection: HttpURLConnection? = null
        var uploadedPath: String? = null
        return try {
            val mime = context.contentResolver.getType(uri)?.lowercase() ?: return Result(false, "The selected file type could not be identified.")
            if (mime !in listOf("image/jpeg", "image/png", "application/pdf")) return Result(false, "Choose a JPEG, PNG or PDF document.")
            val bytes = context.contentResolver.openInputStream(uri)?.use { input ->
                val out = java.io.ByteArrayOutputStream(); val buffer = ByteArray(8192); var total = 0
                while (true) { val n = input.read(buffer); if (n < 0) break; total += n
                    if (total > 10 * 1024 * 1024) return Result(false, "The document must be 10 MB or smaller.")
                    out.write(buffer, 0, n) }
                out.toByteArray()
            } ?: return Result(false, "Could not read the selected document.")
            if (bytes.isEmpty()) return Result(false, "The selected document is empty.")
            val ext = when (mime) { "image/jpeg" -> "jpg"; "image/png" -> "png"; else -> "pdf" }
            val path = "$owner/$propertyId/${java.util.UUID.randomUUID()}.$ext"
            val encoded = path.split("/").joinToString("/") { java.net.URLEncoder.encode(it, "UTF-8").replace("+", "%20") }
            connection = (URL("${SupabaseConfig.BASE_URL}/storage/v1/object/verification-documents/$encoded").openConnection() as HttpURLConnection).apply {
                requestMethod = "POST"; connectTimeout = 20000; readTimeout = 30000; doOutput = true
                setRequestProperty("apikey", SupabaseConfig.PUBLISHABLE_KEY); setRequestProperty("Authorization", "Bearer $token")
                setRequestProperty("Content-Type", mime); setRequestProperty("x-upsert", "false")
            }
            connection.outputStream.use { it.write(bytes) }
            val code = connection.responseCode
            val responseBody = (if (code in 200..299) connection.inputStream else connection.errorStream)?.bufferedReader()?.use { it.readText() }.orEmpty()
            if (code !in 200..299) return Result(false, errorMessage(responseBody))
            uploadedPath = path
            val metadata = JSONObject().put("property_id", propertyId).put("owner_id", owner)
                .put("storage_path", path).put("document_type", documentType).put("review_status", "pending")
            val inserted = request("/rest/v1/property_verification_documents", "POST", metadata, token, "return=minimal")
            if (inserted.first !in 200..299) {
                val deletePath = path.split("/").joinToString("/") { java.net.URLEncoder.encode(it, "UTF-8").replace("+", "%20") }
                var cleanup: HttpURLConnection? = null
                try { cleanup = (URL("${SupabaseConfig.BASE_URL}/storage/v1/object/verification-documents/$deletePath").openConnection() as HttpURLConnection).apply {
                    requestMethod = "DELETE"; setRequestProperty("apikey", SupabaseConfig.PUBLISHABLE_KEY); setRequestProperty("Authorization", "Bearer $token")
                }; cleanup.responseCode } finally { cleanup?.disconnect() }
                return Result(false, "The file uploaded but its verification record could not be saved: ${errorMessage(inserted.second)}")
            }
            Result(true, "Verification document submitted privately. It is pending moderator review.")
        } catch (e: Exception) { Result(false, e.message ?: "Verification upload failed. Please try again.") }
        finally { connection?.disconnect() }
    }

    fun fetchMyVerificationDocuments(): QueueResult<VerificationDocument> {
        val token = accessToken ?: return QueueResult(false, emptyList(), "Please sign in to view verification status.")
        val owner = userId ?: return QueueResult(false, emptyList(), "Your account session is incomplete.")
        val response = request("/rest/v1/property_verification_documents?select=id,property_id,document_type,review_status,created_at&owner_id=eq.$owner&order=created_at.desc&limit=50", "GET", JSONObject(), token)
        if (response.first !in 200..299) return QueueResult(false, emptyList(), errorMessage(response.second))
        val rows = try { org.json.JSONArray(response.second) } catch (_: Exception) { org.json.JSONArray() }
        val items = (0 until rows.length()).mapNotNull { i -> rows.optJSONObject(i)?.let { VerificationDocument(it.optString("id"), it.optString("property_id"), it.optString("document_type"), it.optString("review_status", "pending"), it.optString("created_at")) } }
        return QueueResult(true, items, "")
    }

    fun isCurrentUserModerator(): Boolean {
        val token = accessToken ?: return false
        val owner = userId ?: return false
        val response = request("/rest/v1/profiles?select=account_type&id=eq.$owner&limit=1", "GET", JSONObject(), token)
        if (response.first !in 200..299) return false
        return try { org.json.JSONArray(response.second).optJSONObject(0)?.optString("account_type") == "admin" } catch (_: Exception) { false }
    }

    fun fetchModerationProperties(): QueueResult<ModerationProperty> {
        val token = accessToken ?: return QueueResult(false, emptyList(), "Please sign in with a moderator account.")
        val response = request("/rest/v1/properties?select=id,title,city,owner_id,created_at&review_status=eq.pending&listing_status=eq.draft&order=created_at.asc&limit=100", "GET", JSONObject(), token)
        if (response.first !in 200..299) return QueueResult(false, emptyList(), errorMessage(response.second))
        val rows = try { org.json.JSONArray(response.second) } catch (_: Exception) { org.json.JSONArray() }
        val items = (0 until rows.length()).mapNotNull { i -> rows.optJSONObject(i)?.let { ModerationProperty(it.optString("id"), it.optString("title"), it.optString("city"), it.optString("owner_id"), it.optString("created_at")) } }
        return QueueResult(true, items, "")
    }

    fun moderateProperty(propertyId: String, approve: Boolean): Result {
        val token = accessToken ?: return Result(false, "Please sign in with a moderator account.")
        val owner = userId ?: return Result(false, "Your account session is incomplete.")
        val status = if (approve) "approved" else "rejected"
        val listingStatus = if (approve) "published" else "draft"
        val body = JSONObject().put("review_status", status).put("listing_status", listingStatus)
            .put("reviewed_by", owner).put("reviewed_at", java.time.Instant.now().toString())
        val response = request("/rest/v1/properties?id=eq.$propertyId&review_status=eq.pending", "PATCH", body, token, "return=minimal")
        return if (response.first in 200..299) Result(true, if (approve) "Listing approved and published." else "Listing rejected and returned to the owner.")
        else Result(false, errorMessage(response.second))
    }

    fun fetchModerationReports(): QueueResult<PropertyReport> {
        val token = accessToken ?: return QueueResult(false, emptyList(), "Please sign in with a moderator account.")
        val response = request("/rest/v1/property_reports?select=id,property_id,reason,details,status,created_at&status=in.(open,reviewing)&order=created_at.asc&limit=100", "GET", JSONObject(), token)
        if (response.first !in 200..299) return QueueResult(false, emptyList(), errorMessage(response.second))
        val rows = try { org.json.JSONArray(response.second) } catch (_: Exception) { org.json.JSONArray() }
        val items = (0 until rows.length()).mapNotNull { i -> rows.optJSONObject(i)?.let { PropertyReport(it.optString("id"), it.optString("property_id"), it.optString("reason"), it.optString("details"), it.optString("status", "open"), it.optString("created_at")) } }
        return QueueResult(true, items, "")
    }

    fun fetchModerationVerificationDocuments(): QueueResult<VerificationDocument> {
        val token = accessToken ?: return QueueResult(false, emptyList(), "Please sign in with a moderator account.")
        val response = request("/rest/v1/property_verification_documents?select=id,property_id,owner_id,document_type,review_status,created_at&review_status=eq.pending&order=created_at.asc&limit=100", "GET", JSONObject(), token)
        if (response.first !in 200..299) return QueueResult(false, emptyList(), errorMessage(response.second))
        val rows = try { org.json.JSONArray(response.second) } catch (_: Exception) { org.json.JSONArray() }
        val items = (0 until rows.length()).mapNotNull { i -> rows.optJSONObject(i)?.let { VerificationDocument(it.optString("id"), it.optString("property_id"), it.optString("document_type"), it.optString("review_status", "pending"), it.optString("created_at"), it.optString("owner_id")) } }
        return QueueResult(true, items, "")
    }

    fun moderateVerificationDocument(documentId: String, approve: Boolean): Result {
        val token = accessToken ?: return Result(false, "Please sign in with a moderator account.")
        val status = if (approve) "approved" else "rejected"
        val response = request("/rest/v1/property_verification_documents?id=eq.$documentId&review_status=eq.pending", "PATCH", JSONObject().put("review_status", status), token, "return=minimal")
        return if (response.first in 200..299) Result(true, "Verification evidence marked $status.") else Result(false, errorMessage(response.second))
    }

    fun updateReportStatus(reportId: String, status: String): Result {
        if (status !in setOf("reviewing", "resolved", "dismissed")) return Result(false, "Invalid report status.")
        val token = accessToken ?: return Result(false, "Please sign in with a moderator account.")
        val response = request("/rest/v1/property_reports?id=eq.$reportId", "PATCH", JSONObject().put("status", status), token, "return=minimal")
        return if (response.first in 200..299) Result(true, "Report status updated to $status.") else Result(false, errorMessage(response.second))
    }

    fun signOut() {
        val token = accessToken
        if (!token.isNullOrBlank()) {
            Thread { request("/auth/v1/logout", "POST", JSONObject(), token) }.start()
        }
        clearSession()
    }

    private fun acceptSession(json: JSONObject, fallbackEmail: String?) {
        accessToken = json.optString("access_token").takeIf { it.isNotBlank() }
        refreshToken = json.optString("refresh_token").takeIf { it.isNotBlank() }
        val user = json.optJSONObject("user")
        signedInEmail = user?.optString("email")?.takeIf { it.isNotBlank() } ?: fallbackEmail
        userId = user?.optString("id")?.takeIf { it.isNotBlank() } ?: userId
        saveStoredSession()
    }

    private fun clearSession() {
        accessToken = null; refreshToken = null; signedInEmail = null; userId = null
        appContext?.getSharedPreferences(PREFS, Context.MODE_PRIVATE)?.edit()?.remove(SESSION_KEY)?.apply()
    }

    private fun loadStoredSession() {
        try {
            val prefs = appContext?.getSharedPreferences(PREFS, Context.MODE_PRIVATE) ?: return
            val blob = prefs.getString(SESSION_KEY, null) ?: return
            val bytes = Base64.decode(blob, Base64.NO_WRAP)
            val iv = bytes.copyOfRange(0, 12)
            val encrypted = bytes.copyOfRange(12, bytes.size)
            val cipher = Cipher.getInstance("AES/GCM/NoPadding")
            cipher.init(Cipher.DECRYPT_MODE, getOrCreateKey(), GCMParameterSpec(128, iv))
            val json = JSONObject(String(cipher.doFinal(encrypted), Charsets.UTF_8))
            accessToken = json.optString("access_token").takeIf { it.isNotBlank() }
            refreshToken = json.optString("refresh_token").takeIf { it.isNotBlank() }
            signedInEmail = json.optString("email").takeIf { it.isNotBlank() }
            userId = json.optString("user_id").takeIf { it.isNotBlank() }
        } catch (_: Exception) { clearSession() }
    }

    private fun saveStoredSession() {
        try {
            val context = appContext ?: return
            val json = JSONObject().put("access_token", accessToken ?: "")
                .put("refresh_token", refreshToken ?: "").put("email", signedInEmail ?: "")
                .put("user_id", userId ?: "")
            val cipher = Cipher.getInstance("AES/GCM/NoPadding")
            cipher.init(Cipher.ENCRYPT_MODE, getOrCreateKey())
            val encrypted = cipher.doFinal(json.toString().toByteArray(Charsets.UTF_8))
            val combined = cipher.iv + encrypted
            context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
                .putString(SESSION_KEY, Base64.encodeToString(combined, Base64.NO_WRAP)).apply()
        } catch (_: Exception) { /* Do not crash sign-in if secure storage is unavailable. */ }
    }

    private fun getOrCreateKey(): SecretKey {
        val store = KeyStore.getInstance("AndroidKeyStore").apply { load(null) }
        val existing = store.getKey(KEY_ALIAS, null) as? SecretKey
        if (existing != null) return existing
        val generator = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore")
        generator.init(KeyGenParameterSpec.Builder(KEY_ALIAS,
            KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT)
            .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
            .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
            .setRandomizedEncryptionRequired(true).build())
        return generator.generateKey()
    }

    private fun request(path: String, method: String, body: JSONObject, bearer: String? = accessToken,
                        prefer: String? = null): Pair<Int, String> =
        SupabaseHttpClient.execute(
            baseUrl = SupabaseConfig.BASE_URL,
            publishableKey = SupabaseConfig.PUBLISHABLE_KEY,
            path = path,
            method = method,
            body = body,
            bearer = bearer,
            prefer = prefer
        )

    private fun parse(text: String): JSONObject? = try { JSONObject(text) } catch (_: Exception) { null }
    private fun errorMessage(body: String): String {
        val json = parse(body)
        return json?.optString("msg")?.takeIf { it.isNotBlank() }
            ?: json?.optString("message")?.takeIf { it.isNotBlank() }
            ?: json?.optString("error_description")?.takeIf { it.isNotBlank() }
            ?: body.take(240).ifBlank { "Request failed. Please try again." }
    }
}
