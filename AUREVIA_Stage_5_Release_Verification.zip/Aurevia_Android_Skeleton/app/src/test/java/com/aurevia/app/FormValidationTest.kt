package com.aurevia.app

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Test

class FormValidationTest {
    @Test fun propertyAcceptsValidDetailsAndCoordinates() {
        assertNull(FormValidation.validatePropertyLocation(
            "Sunny two-bedroom flat", "Kenya", "KE", "Kisumu", "-0.0917", "34.7680"
        ))
    }

    @Test fun propertyAllowsBothCoordinatesToBeBlank() {
        assertNull(FormValidation.validatePropertyLocation(
            "Sunny two-bedroom flat", "Kenya", "ke", "Kisumu", "", ""
        ))
    }

    @Test fun propertyRejectsShortTitleAndBadCountryCode() {
        assertEquals(
            "Enter a title (5–120 characters), country, 2-letter country code and city.",
            FormValidation.validatePropertyLocation("Flat", "Kenya", "KEN", "Kisumu", "", "")
        )
    }

    @Test fun propertyRejectsPartialOrOutOfRangeCoordinates() {
        assertEquals(
            "Enter both valid coordinates (latitude −90 to 90, longitude −180 to 180), or leave both blank.",
            FormValidation.validatePropertyLocation("Sunny two-bedroom flat", "Kenya", "KE", "Kisumu", "91", "34.7")
        )
        assertEquals(
            "Enter both valid coordinates (latitude −90 to 90, longitude −180 to 180), or leave both blank.",
            FormValidation.validatePropertyLocation("Sunny two-bedroom flat", "Kenya", "KE", "Kisumu", "-0.1", "")
        )
    }

    @Test fun priceRequiresPositiveFiniteAmountAndThreeLetterCurrency() {
        assertNull(FormValidation.validatePrice("12500.50", "KES"))
        assertEquals("Enter a valid price and 3-letter currency code.", FormValidation.validatePrice("0", "KES"))
        assertEquals("Enter a valid price and 3-letter currency code.", FormValidation.validatePrice("NaN", "KES"))
        assertEquals("Enter a valid price and 3-letter currency code.", FormValidation.validatePrice("120", "KE"))
    }

    @Test fun tenantAcceptsValidLeaseDates() {
        assertNull(FormValidation.validateTenant("Amina Otieno", "+254700000000", "15000", "2026-01-15", "2026-12-31"))
        assertNull(FormValidation.validateTenant("Amina Otieno", "+254700000000", "0", "2026-01-15", ""))
    }

    @Test fun tenantRejectsImpossibleDatesAndEndBeforeStart() {
        assertEquals(
            "Enter name, phone, valid rent, and dates in YYYY-MM-DD format.",
            FormValidation.validateTenant("Amina", "0700000000", "1000", "2026-02-30", "")
        )
        assertEquals(
            "Lease end must not be before start.",
            FormValidation.validateTenant("Amina", "0700000000", "1000", "2026-10-01", "2026-09-30")
        )
    }
}
