plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.aurevia.app"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.aurevia.app"
        minSdk = 23
        targetSdk = 35
        versionCode = 27
        versionName = "1.0.1"
    }

    buildTypes {
        getByName("release") {
            // Keep shrinking disabled until a signed release build and full regression suite pass.
            isMinifyEnabled = false
        }
    }
}


dependencies {
    testImplementation("junit:junit:4.13.2")
}
