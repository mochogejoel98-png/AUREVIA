#!/usr/bin/env python3
"""Fail-fast repository structure and client-secret checks for AUREVIA.

This is a static preflight only. It does not compile Android code, execute SQL,
prove Supabase RLS behavior, or replace physical-device regression testing.
"""
from pathlib import Path
import re
import sys

ROOT = Path(__file__).resolve().parents[1]
REQUIRED_FILES = [
    "settings.gradle.kts",
    "build.gradle.kts",
    "gradle.properties",
    "app/build.gradle.kts",
    "app/src/main/AndroidManifest.xml",
    "app/src/main/java/com/aurevia/app/MainActivity.kt",
    "app/src/main/java/com/aurevia/app/SupabaseAuth.kt",
    "app/src/main/java/com/aurevia/app/SupabaseConfig.kt",
    "app/src/main/java/com/aurevia/app/FormValidation.kt",
    "app/src/test/java/com/aurevia/app/FormValidationTest.kt",
    ".github/workflows/android-ci.yml",
    "scripts/check_supabase_schema.py",
]
errors = []
for relative in REQUIRED_FILES:
    if not (ROOT / relative).is_file():
        errors.append(f"Required project file is missing: {relative}")

app_gradle_path = ROOT / "app/build.gradle.kts"
if app_gradle_path.is_file():
    app_gradle = app_gradle_path.read_text(encoding="utf-8")
    for token in ('namespace = "com.aurevia.app"', 'applicationId = "com.aurevia.app"', 'targetSdk = 35'):
        if token not in app_gradle:
            errors.append(f"Android Gradle configuration is missing expected setting: {token}")
    if not re.search(r'versionCode\s*=\s*\d+', app_gradle):
        errors.append("Android versionCode is missing or malformed.")
    if not re.search(r'versionName\s*=\s*"[^"\n]+"', app_gradle):
        errors.append("Android versionName is missing or malformed.")

# Search executable application/configuration sources, not documentation, for
# a literal Supabase secret key. Publishable/anon keys are allowed client-side.
source_files = [
    p for p in (ROOT / "app/src").rglob("*")
    if p.is_file() and p.suffix in {".kt", ".java", ".xml", ".properties", ".kts"}
]
source_files.extend(p for p in ROOT.rglob("*.gradle.kts") if p.is_file())
source_files = sorted(set(source_files))
secret_pattern = re.compile(r"sb_secret_[A-Za-z0-9_-]{12,}|service_role\s*[:=]\s*['\"]?[A-Za-z0-9._-]{20,}", re.IGNORECASE)
for path in source_files:
    try:
        content = path.read_text(encoding="utf-8")
    except UnicodeDecodeError:
        continue
    if secret_pattern.search(content):
        errors.append(f"Potential Supabase secret credential found in application/config source: {path.relative_to(ROOT)}")

if errors:
    print("AUREVIA release preflight FAILED:")
    for error in errors:
        print(f" - {error}")
    sys.exit(1)

print(f"AUREVIA release preflight passed: {len(REQUIRED_FILES)} required files and Android configuration checks are present.")
print(f"Scanned {len(source_files)} application/config source files for common Supabase secret-key patterns.")
print("Limit: static checks only; full Gradle build, runtime behavior, live RLS tests, and device regression remain separate gates.")
