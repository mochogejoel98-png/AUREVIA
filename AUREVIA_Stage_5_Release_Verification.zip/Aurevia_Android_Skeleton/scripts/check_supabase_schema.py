#!/usr/bin/env python3
"""Static guardrails for AUREVIA SQL files; not a substitute for live PostgreSQL/RLS tests."""
from pathlib import Path
import re
import sys

ROOT = Path(__file__).resolve().parents[1]
SQL_ROOT = ROOT / "supabase"
SQL_FILES = [SQL_ROOT / "schema.sql", *sorted((SQL_ROOT / "migrations").glob("*.sql"))]

if not SQL_FILES[0].is_file():
    print("ERROR: supabase/schema.sql is missing")
    sys.exit(1)

sql = "\n".join(path.read_text(encoding="utf-8") for path in SQL_FILES if path.is_file())
normalized = re.sub(r"--[^\n]*", " ", sql.lower())
created = set(re.findall(r"create\s+table\s+(?:if\s+not\s+exists\s+)?(public\.[a-z_][a-z0-9_]*)", normalized))
enabled = set(re.findall(r"alter\s+table\s+(?:if\s+exists\s+)?(public\.[a-z_][a-z0-9_]*)\s+enable\s+row\s+level\s+security", normalized))
errors = []

if not created:
    errors.append("No public tables were discovered in schema.sql/migrations.")
for table in sorted(created - enabled):
    errors.append(f"RLS enable statement missing for created table: {table}")

# Guard the two most important public property-read invariants against accidental deletion.
if not re.search(r"create\s+policy\s+[\"']properties public or owner read[\"']\s+on\s+public\.properties", normalized):
    errors.append("Expected properties public/owner read policy was not found.")
if not re.search(r"listing_status\s*=\s*'published'\s+and\s+review_status\s*=\s*'approved'", normalized):
    errors.append("Published + approved listing restriction was not found in SQL policies.")

if errors:
    print("AUREVIA Supabase static security checks FAILED:")
    for error in errors:
        print(f" - {error}")
    sys.exit(1)

print(f"AUREVIA Supabase static security checks passed: {len(created)} public tables have RLS enable statements.")
print("Note: this is a static guardrail, not proof that RLS policies are semantically correct.")
