# AUREVIA v0.14.0 — Financial Records

## Implemented in source
- Added a property-specific financial ledger for recording income and expenses.
- Each entry stores type, category, amount, three-letter currency code, transaction date, optional description and optional receipt/payment reference.
- The finance screen summarizes recorded income, expenses and net amount, then lists entries newest transaction date first.
- The landlord dashboard property cards and room management screen link to Financial records.
- Financial entries are insert-only from the app in this release to preserve an audit trail; there is no edit/delete UI.
- The app explicitly explains that this ledger is recordkeeping, not payment processing or proof of bank settlement.

## Backend and access control
- Migration: `supabase/migrations/20261101_property_financial_records.sql`.
- Applied to the connected Supabase project `muilsyuudpscpvandgnf`.
- Row-level security is enabled. Authenticated users can read and insert records only when they own the linked property; inserted records must identify the current authenticated user as creator.
- No public/anonymous policies or client-side service-role key are used.

## Validation report
- Live database table columns and the two authenticated RLS policies were verified after migration.
- ZIP integrity and XML parsing were checked when packaging.
- Android Gradle build and on-device tests have not been run in this environment. Please build and test in CodeAssist before treating the APK as release-ready.
