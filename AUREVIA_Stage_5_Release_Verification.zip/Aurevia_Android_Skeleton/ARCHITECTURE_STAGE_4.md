# AUREVIA architecture notes — Stage 4

## Current responsibilities

- `MainActivity.kt`: Android screens, navigation, view state, and UI event handling.
- `PropertyListing.kt`: catalogue listing data model, extracted from the Activity.
- `FormValidation.kt`: pure input validation shared by UI and JVM tests.
- `SupabaseAuth.kt`: account/session state, domain operations, response parsing, and secure session persistence.
- `SupabaseHttpClient.kt`: shared JSON REST request transport for the common request path.
- `SupabaseConfig.kt`: public Supabase endpoint and publishable client key.
- `supabase/schema.sql` and `supabase/migrations/`: database schema, policies, triggers, and incremental features.

## Refactor boundary

Stage 4 extracts the catalogue model and common JSON HTTP transport without changing the public `SupabaseAuth` operations called by the UI. Some upload and specialized read methods still use direct `HttpURLConnection` code inside `SupabaseAuth`; those are candidates for a later focused refactor with regression tests.

## Verification boundary

The CI static SQL guard checks that every table declared in the supplied schema/migration files has an RLS enable statement and that the published/approved property policy remains present. This is not equivalent to executing the SQL or proving policy semantics.
