# Stage 4 — Architecture and database quality guardrails

- Extracted the public property-card model from `MainActivity.kt` into `PropertyListing.kt`.
- Extracted Supabase endpoint/publishable-key configuration into `SupabaseConfig.kt`.
- Extracted the common JSON REST request transport into `SupabaseHttpClient.kt`; existing `SupabaseAuth` operation signatures remain unchanged.
- Added a static SQL security guard that checks RLS enable statements for tables declared in the schema/migrations and protects key published/approved property policy text.
- Added Supabase security review guidance and architecture notes.
- Updated GitHub Actions to run the static SQL guard before Android verification.

## Verification status

Static script and archive checks are run for this package. Full Android Gradle build, JUnit suite, PostgreSQL migration execution, and live RLS role testing still need to run in CI/staging.
