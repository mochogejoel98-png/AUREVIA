# Stage 1 — Restore a clean-checkout build path

- Restored/retained root Gradle settings and plugin declarations, Android app module Gradle configuration, and Gradle properties in the project root.
- Added `.gitignore` entries for generated build output, machine-local SDK paths, IDE files, and signing/secrets material.
- Added GitHub Actions CI to provision JDK 17, Android SDK Platform 35 / Build Tools 35.0.0, and Gradle 8.7, then run `assembleDebug`, `lintDebug`, and `testDebugUnitTest`.
- Added `BUILDING.md` with fresh-checkout requirements, commands, artifact location, security notes, and honest verification status.

## Not yet verified

The full Android Gradle build has not been run in the packaging environment because Gradle, Android SDK tooling, and network access to provision them were unavailable. A successful CI run is still required. No claim is made that this stage has already passed compilation.
