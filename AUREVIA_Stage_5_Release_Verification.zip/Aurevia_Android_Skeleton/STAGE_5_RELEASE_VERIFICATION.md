# AUREVIA Stage 5 — Release Verification Gate

## Purpose

Stage 5 adds a repeatable static preflight before Android CI. It checks the expected project structure, essential Android Gradle identity/SDK settings, presence of the shared validation tests, and common literal Supabase secret-key patterns in application/configuration source.

## Run locally

From the repository root:

```bash
python3 scripts/verify_release.py
python3 scripts/check_supabase_schema.py
gradle --no-daemon assembleDebug lintDebug testDebugUnitTest
```

The first two commands are static checks. The Gradle command must run in an environment with JDK 17, Gradle 8.7, Android SDK Platform 35, and Build Tools 35.0.0.

## Release gate checklist

- [ ] `scripts/verify_release.py` passes.
- [ ] `scripts/check_supabase_schema.py` passes.
- [ ] GitHub Actions reports successful `assembleDebug`, `lintDebug`, and `testDebugUnitTest` tasks.
- [ ] Install the generated APK on a physical Android device and launch it successfully.
- [ ] Test sign-in, session restoration, property discovery, property creation, tenant management, messaging, media upload, and other existing features that apply to the release.
- [ ] Test access rules with multiple test accounts in a non-production Supabase project.
- [ ] Review migration order and take a backup before any production database change.
- [ ] Confirm no service-role key, signing key, password, or private token is present in Git history or the APK.
- [ ] Prepare and test a signed release build separately; CI's debug APK is not a Play Store release artifact.

## Limitations

The secret scanner is a conservative static guardrail, not a full secret scanner and not proof that Git history or binary artifacts are free of secrets. The schema check does not execute PostgreSQL or prove RLS policies are correct. CI success does not replace device testing, backend integration tests, privacy review, accessibility review, or release signing.

## Current status

The static preflight and schema guard can be run in this source package. A complete Android Gradle build, real GitHub Actions run, live database/RLS test, and physical-device regression run have not been verified by preparing this ZIP alone.
