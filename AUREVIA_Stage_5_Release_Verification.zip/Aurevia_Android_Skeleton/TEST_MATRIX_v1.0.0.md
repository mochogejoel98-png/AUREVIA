# AUREVIA v1.0.0 Manual Regression Matrix

Record **Pass / Fail / Not tested**, device/Android version, test account role, and notes for every row. Use non-production test accounts and test listings.

| Area | Test | Expected result | Status / notes |
|---|---|---|---|
| Startup | Cold launch with network | Home opens; session restore does not freeze UI | Not tested |
| Startup | Cold launch offline | App remains usable where possible and reports retryable network errors | Not tested |
| Auth | Register/sign in/sign out | Correct success/error states; sign out clears local session | Not tested |
| Public listings | Explore/search/filter/details | Only published and approved records appear publicly | Not tested |
| Favorites | Add/remove favorite | Change persists for signed-in account only | Not tested |
| Property drafts | Create draft and attach photos | Draft is owner-visible, not publicly published | Not tested |
| Portfolio | Search/filter/sort/counts | Results and counts match the owner's returned property records | Not tested |
| Appointments | Request/respond/cancel | Only valid participant transitions succeed | Not tested |
| Tenants/units | Read/create permitted records | Owner-scoped access enforced | Not tested |
| Facilities/maps | Save/show facility or coordinates | Data corresponds to selected property; no unrelated data leaks | Not tested |
| Finance | Add/read income or expense | Only authorized owner can access property ledger | Not tested |
| Messaging | Send/read conversation | Only requester and property owner can read the conversation | Not tested |
| Verification | Upload private evidence | File is private and visible only to authorized owner/moderator | Not tested |
| Moderation | Review listing/report/evidence | Non-admin users cannot perform moderator actions | Not tested |
| Video | Upload/play/pause | MP4 limits enforced; signed playback works and expires | Not tested |
| Upgrade | Install over previous build | App launches; account data remains server-side; session behavior is safe | Not tested |
| Release | Signed release artifact | Installs and passes the same regression suite | Not tested |
