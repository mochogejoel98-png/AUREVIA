# AUREVIA Privacy Policy — Completion Template

**Do not publish this template unchanged.** Replace every bracketed field, verify each statement against the shipped app and live backend, and obtain appropriate legal/privacy review for the markets served.

- **Effective date:** [DATE]
- **Service operator:** [LEGAL PERSON OR BUSINESS NAME]
- **Contact:** [MONITORED SUPPORT/PRIVACY EMAIL OR ADDRESS]
- **Public policy URL:** [HOSTED HTTPS URL]

## Information the service may process
Depending on the features you use, AUREVIA may process account identifiers and email address; property listing details and photos; city/area and optional property coordinates; saved listings; viewing requests; tenant/unit information entered by property managers; financial records entered for a property; messages; reports and verification documents; video files and captions; and technical request/session data needed to operate the service. Confirm this list against the production configuration before publication.

## How information is used
Information may be used to authenticate accounts, display approved listings, save preferences, coordinate viewing requests, enable property-owner tools and messaging, review reports and verification submissions, secure the service, and troubleshoot errors. State any additional purposes here: [PURPOSES].

## Storage and service providers
The current project uses Supabase services for backend authentication, database access and private file storage. Add all other actual providers and their roles here: [PROVIDERS]. State applicable processing locations and transfer safeguards only after verifying them: [LOCATIONS / SAFEGUARDS].

## Sharing and visibility
Some approved listing information may be public. Private account records, messages, tenant/financial information and verification documents should be accessible only as configured by the service's authorization rules. Describe any human moderation access and any other sharing: [DETAILS]. Do not promise absolute confidentiality or security.

## Retention and deletion
Explain how long each category is retained, how users can request account/data deletion, what is deleted or retained for legal/security reasons, and the expected completion time: [RETENTION AND DELETION PROCESS]. Do not claim in-app account deletion unless it is implemented and verified.

## Security
Describe safeguards accurately, including access controls and encrypted network transport. No online service can guarantee absolute security.

## Children
State the intended audience and whether the service is directed to children, based on the actual product and applicable law: [CHILDREN POLICY].

## User choices and rights
Explain how users can access, correct, export or request deletion of information and how to contact the operator or relevant regulator: [RIGHTS AND PROCESS]. Requirements depend on location and applicable law.

## Policy changes
Explain how material changes will be announced and update the effective date when needed: [NOTICE PROCESS].

## Contact
Privacy requests and questions: [MONITORED CONTACT].
