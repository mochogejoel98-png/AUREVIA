# AUREVIA Android Marketplace — Kotlin + XML

AUREVIA v1.0.0 release-preparation source package. It integrates the existing property marketplace, owner dashboard and portfolio, tenant/unit management, facilities/maps, financial records, appointments, messaging, verification/moderation and vertical video discovery. The version number marks the release-preparation milestone; it does **not** mean the app has passed store review or production end-to-end testing.

See `RELEASE_CHECKLIST.md`, `TEST_MATRIX_v1.0.0.md`, `PLAY_STORE_LISTING_DRAFT.md` and `PRIVACY_POLICY_TEMPLATE.md` before publishing.

## Included
- Black, champagne-gold and ivory design tokens
- Single-activity starter shell
- Home, Explore, Saved, Add Property, Inbox and Profile navigation
- Search field and Rent/Buy entry controls
- No third-party Android libraries required by the starter code

## Important status
The app is connected to the configured Supabase project for authentication and the features described in the version changelogs. The public catalogue displays only published and approved property records; private drafts, messages, reports and verification evidence are subject to Row Level Security. Some workflows still require full Gradle/device end-to-end testing before release. This is not yet a production-certified marketplace.

## Import
Open the project folder in Android Studio or a compatible Android IDE and allow Gradle sync. This project uses Android Gradle Plugin 8.6.1, Kotlin 2.0.21, compile SDK 35 and minimum SDK 23. The installed IDE must support these versions and have the Android SDK 35 platform available.

## Build from a fresh checkout
See [`BUILDING.md`](BUILDING.md) for JDK/Gradle/Android SDK requirements and exact build commands. The GitHub Actions workflow in `.github/workflows/android-ci.yml` runs assemble, lint, and unit-test tasks. The full Gradle build has not yet been verified in this packaging environment; check the first CI run before treating the source as build-verified.

## Stage 4 architecture and database guardrails
See [`ARCHITECTURE_STAGE_4.md`](ARCHITECTURE_STAGE_4.md) for the current responsibility boundaries and [`supabase/SECURITY_REVIEW.md`](supabase/SECURITY_REVIEW.md) for the database review checklist. CI runs `python3 scripts/check_supabase_schema.py` to detect missing RLS enable statements for declared public tables and preserve the published/approved property-read policy. This is a static guardrail, not a substitute for PostgreSQL migration execution and role-based RLS testing.

## Package
`com.aurevia.app`


## Version 0.2 — interactive UI prototype
- Expanded Home, Explore, Saved, Add Property, Inbox and Profile screens.
- Added local-only search filter inputs and a three-step property draft form.
- Added a device-local draft save action; it does not publish a listing.
- Added basic empty states and safety messaging.
- No authentication, server search, real property records, image uploads, messaging, appointments, maps, verification or moderation backend is connected.
- Sample content is explanatory placeholder content, not real property inventory.
- Android compilation has not been independently verified in this environment. Import and test in your CodeAssist setup.


## Version 0.3 — interactive discovery prototype
- Added five fictional demo listings, clearly labeled as demonstration content.
- Added functional Rent/Buy, location, maximum-price, property-type and bedroom filters.
- Added property detail views.
- Added save/remove actions and local saved-property persistence using SharedPreferences.
- Demo listing locations and prices are illustrative only; no real inventory or live availability is represented.
- Search and saved items are not connected to a user account or remote backend.
- Android compilation has not been independently verified in this environment. Import and test in CodeAssist.


## Version 0.4 — Supabase backend preparation
- Added `supabase/schema.sql` for the initial marketplace database and Row Level Security policies.
- Added `supabase/SETUP.md` with project setup and security instructions.
- The Android app has not yet been connected to Supabase.
- No Supabase URL, key, or credentials are embedded in the project.
- The schema has not been executed against a live Supabase project and requires RLS/security testing before launch.


## Version 0.5 — Supabase authentication connection
- Added Supabase Auth REST integration using the project's HTTPS endpoint and client-safe publishable key.
- Added email/password account creation and sign-in UI on the Profile screen.
- Added basic email/password validation, background-thread network requests and user-facing error messages.
- Added Android INTERNET permission.
- The first integration keeps the access token in memory only; closing the app signs the user out. Persistent encrypted session storage is intentionally not included yet.
- Email confirmation behavior depends on the Supabase Auth settings. If confirmation is enabled, users must confirm their email before signing in.
- Property browsing, favorites, listing creation, image uploads, messaging and appointments are still not connected to the live backend.
- The publishable key is intended for client apps; no secret/service-role key is included. Database access relies on the configured RLS policies.
- Android build has NOT been run in this environment because Gradle/Android SDK tooling is unavailable here. Import into CodeAssist, sync and test registration/sign-in before using this version.


## v0.6.0 update (session persistence and property drafts)

- Supabase access and refresh tokens are encrypted at rest using Android Keystore-backed AES-GCM and stored in app-private preferences.
- The app attempts to restore/refresh the session when it starts; Supabase refresh-token rotation is saved back to encrypted storage.
- Sign out clears the locally stored session and calls the Supabase logout endpoint.
- The Add Property wizard now collects the required listing title, country, country code, city, area, price, currency, purpose, property type and optional details.
- Save Property Draft submits to the live `public.properties` REST endpoint with the signed-in user's ID, `listing_status=draft`, and `review_status=pending`. It does not publish or bypass moderation.
- The project database was checked: `authenticated` has INSERT/SELECT/UPDATE/DELETE privileges on `public.properties`, and the existing RLS insert policy restricts inserts to the signed-in owner and draft/pending status.
- Photo uploads, verification evidence, live public search, and listing moderation are not implemented in this update.
- Build status: source and XML/manifest checks only. Android Gradle build and on-device sign-in/session restoration/property submission have not yet been verified because this environment has no Gradle installation or Android SDK.


## v0.6.1 hotfix — Add Property Continue crash

- Fixed a confirmed Android view-parent crash in step 2 of the Add Property wizard. The `field()` helper already attaches EditText controls to the page; the old code attempted to attach those same controls a second time.
- Reordered the price-period spinner so it appears between currency and bedroom fields.
- No database schema, authentication, RLS policy or API behavior was changed.
- ZIP and XML/manifest structure checks can be performed on this package, but an Android Gradle build and device workflow test have NOT been run in this environment. Please build and test in CodeAssist.


## v0.7.0 — Live property discovery

- Replaced the five fictional demonstration properties with live reads from the Supabase `properties` table.
- Public catalogue requests explicitly filter to `listing_status=published` and `review_status=approved`, ordered newest first and limited to 100 records.
- The public request selects only display-safe property fields and deliberately excludes `address_private`, owner IDs, review metadata and verification documents.
- Added Rent/Buy, location/title, maximum-price, property-type and minimum-bedroom filters over the retrieved live catalogue.
- Added loading, empty, retry and refresh states. An empty catalogue is explained as having no publicly approved listings; private drafts are not presented as public properties.
- Property detail pages include a safety note explaining that publication approval is not proof of ownership, condition or current availability.
- Saved listings continue to be stored locally on the device; cross-device favorites, photos, owner contact, maps and messaging are not included.
- Supabase project schema was inspected: the `properties` table has RLS enabled and its public/owner SELECT policy permits published+approved rows to anonymous visitors while owners can also read their own rows. The app still applies the explicit public status filters.
- At the time this build was prepared, the database contained one `draft/pending` property and zero published/approved listings. Therefore the live Explore screen is expected to show the honest empty state until a property is approved and published.
- Build status: ZIP, Kotlin source structure and XML/manifest checks only. A full Android Gradle build and on-device live REST test have NOT been run in this environment. Please import into CodeAssist and test before replacing the installed app.


## v0.8.0 – Property photo uploads
- Add Property now allows selection of up to 12 images through Android's system document picker.
- JPEG, PNG and WebP are accepted; each image is limited to 10 MB, matching the configured Supabase `property-photos` bucket.
- Photos upload under `<owner_id>/<property_id>/<generated_filename>` using the signed-in user's access token. The app then inserts the matching `property_photos` metadata row.
- If metadata insertion fails, the app makes a best-effort delete of the uploaded object. A saved property draft is retained even if one or more photo uploads fail.
- Photo selection is optional. The listing remains a private draft until approved and published.
- The app does not upload identity/ownership documents to the public photo bucket.

### v0.8 verification status
- Source ZIP integrity and Android XML parsing should be checked for this release.
- Full Android Gradle build, real-device picker behavior, live Storage upload, metadata insertion, and public image rendering require device testing and are not claimed as verified by static packaging checks.


## Version 0.8.1 — photo previews and My Drafts access
- Added an on-screen horizontal preview strip for selected property photos before submission, plus a clear-selection action.
- Added Profile → My property drafts and listings, which retrieves only the signed-in owner's properties through the Supabase REST API. Existing RLS remains the security boundary.
- Added loading, empty, error and refresh states for the owner's property list.
- Drafts remain private database records; they are not stored in the phone Gallery or Downloads.
- This update does not change listing approval or publication status.
- ZIP/XML checks are documented separately; a full Android Gradle build and live-device image test still require CodeAssist/device verification.


## v0.8.2 build correction
Restored `app/build.gradle.kts` to a valid Android application module Gradle file. In v0.8.1 this file was accidentally overwritten with Kotlin activity source code. That prevented Android resource generation and caused `Unresolved reference: R` errors. No layout IDs or app source features were removed. Module version is 0.8.2 (versionCode 10).


## v0.9.0 — Live Favorites

- Saved properties now require a signed-in AUREVIA account.
- Favorites are inserted, fetched, and removed through the Supabase REST Data API.
- The `favorites` table's existing Row Level Security policy restricts each account to its own rows.
- Saved properties sync by account across devices after signing in.
- The public property catalogue is still used for property details; if a saved listing is no longer publicly visible, its ID remains in the account but the listing card may not appear in the current public catalogue.
- No database schema migration is required; the existing `public.favorites` table, grants, and RLS policy are used.

Verification status:
- ZIP structure and Android XML/Gradle configuration are checked.
- Kotlin source was reviewed for balanced structure and expected method wiring.
- A full Android Gradle build, device test, and live favorite insert/read/delete test have NOT been run in this environment.


## v0.10.0 — Viewing appointments

- Added a property-details action to request a viewing for a live published and approved listing.
- Customers choose a future local date and time; the app converts the selected instant to UTC before saving it as `requested_at`.
- Requests are created as `pending`. The app clearly explains that sending a request is not an accepted/confirmed appointment.
- Added Profile → Viewing appointments, with separate sections for the signed-in user's requests and incoming requests for properties owned by the signed-in account.
- Owners can accept or decline pending requests and mark accepted viewings completed. Requesters can cancel pending or accepted requests.
- Viewing requests use the existing `public.viewing_requests` table and its existing participant-based SELECT/UPDATE policies.
- Added a database trigger that validates future dates, public/approved property status, requester identity, immutable request details, and allowed status transitions.
- Added a SECURITY INVOKER RPC for status changes so the Android client uses POST rather than relying on HttpURLConnection PATCH support. The function is executable only by authenticated users and remains subject to RLS.
- No fake appointments or sample property records are inserted. A property must already be published and approved before a viewing request can be submitted.

### v0.10 database update

The connected Supabase project has been updated with the viewing-request guard trigger, stricter pending-only insert policy, and `respond_to_viewing_request(uuid, text)` RPC. The repeatable SQL is included at `supabase/migrations/20261031_viewing_appointments.sql`; the complete baseline `supabase/schema.sql` also includes these rules.

### v0.10 verification status

- Source ZIP integrity and Android XML/Gradle configuration are checked.
- Supabase trigger, policies and RPC were created and queried back from the connected project. The RPC is SECURITY INVOKER, unavailable to `anon`, and available to `authenticated`.
- The Supabase security advisor reported one existing warning: leaked-password protection is disabled. No new viewing-request security finding was reported.
- No authenticated test appointment was inserted because there is no approved public listing and no user-authorized test booking to use.
- Full Android Gradle build, device workflow, date/time picker behavior and live appointment create/respond/cancel flows have NOT been verified in this environment. Please import into CodeAssist and test on your phone.


## v0.10.1 — Landlord DASH dashboard update

- Added a dedicated landlord DASH screen, accessible from Profile and the Home owner entry.
- Added account-scoped property summary cards using the owner's fetched property records.
- Added incoming viewing-request counts and a prominent route to manage appointments.
- Added shortcuts to My Properties and Add Property.
- Kept renter discovery and existing appointment workflows intact.
- No revenue or payment totals are shown because verified financial records are not yet implemented.
- Version: 0.10.1 (versionCode 13).

## Version 0.10.3 — landlord DASH loading recovery
- Waits for the saved Supabase session restore attempt before requesting private owner data.
- Refresh dashboard retries session restoration and then reloads properties and viewing requests.
- If the session cannot be restored, the dashboard can direct the owner to sign in again instead of remaining in a loading state.
- Android compilation and live-device testing must still be completed in CodeAssist.


## Historical milestone note
Version 0.12.0 added tenant management. Apply `supabase/migrations/20261101_property_tenants.sql` after the room migration before using it. See `CHANGELOG_v0.12.0.md` for validation status and required owner actions.


## Historical milestone note
AUREVIA Android source version at that milestone: **0.13.0** (Facilities and Maps). See `CHANGELOG_v0.13.0.md` and apply the migration in `supabase/migrations/20261101_property_facilities_and_map_coordinates.sql` only when setting up a different Supabase project. The connected AUREVIA project already has this migration applied.

## Version 0.14.0 — Financial Records
Landlords can open **Financial records** from a property card or the room management screen to record property income and expenses. The ledger is owner-only and insert-only in this version. Apply `supabase/migrations/20261101_property_financial_records.sql` to any separate Supabase environment before using this feature there.


## Version 0.15.0 — Private property messaging
- Public approved listing details now include a **Message property owner** action for signed-in users.
- Inbox lists the conversations in which the signed-in account is a requester or property owner.
- Conversation view loads messages in chronological order and supports sending text messages.
- The database enforces participant-only reads and sender identity; only requesters can start a conversation, and only for published, approved listings.
- Messaging rows are insert-only from the Android client in this release; anonymous access and client-side edit/delete permissions are removed.
- Apply `supabase/migrations/20261101_property_messaging.sql` to a separate Supabase project before using messaging there. The connected project has the migration applied.
- Verification: migration and policies were queried against the connected database; source ZIP, XML, and Kotlin structural checks are performed for this package. A full Android Gradle build and device messaging test still need to be run in CodeAssist.


## Version 0.16.0 — Verification & Moderation
- Added published-listing safety reports, private verification document submission, owner verification status, and moderator queues for pending listings, evidence, and reports.
- Verification evidence is stored in the private `verification-documents` bucket; do not move it to public property-photo storage.
- The v0.16 migration hardens insert/review rules and adds moderator audit fields. Apply `supabase/migrations/20261101_verification_moderation.sql` and `supabase/migrations/20261101_verification_moderation_privileges.sql` to an existing database if not already applied.
- Moderator access requires a trusted account manually promoted to `admin` in Supabase. Never expose service-role credentials in the Android client.
- ZIP/XML/Kotlin source checks are not a substitute for a full Gradle build and real-device end-to-end testing.


## v0.17.0 — Vertical Video Property Discovery
See `CHANGELOG_v0.17.0.md` for the private MP4 upload, signed playback URLs, and video discovery feed. Apply `supabase/migrations/20261101_property_video_discovery.sql` to set up the database and storage policies.


## v0.17.0 — Vertical Video Property Discovery
- Browse vertical-format property video tours from Home or Explore.
- Owners can upload an MP4 tour (up to 50 MB) with an optional caption from My property drafts and listings.
- Video cards include explicit play/pause and property-detail actions; the feed does not autoplay every video.
- MP4s are stored in a private Supabase bucket. The app requests short-lived signed playback URLs, and public feed access is limited by RLS to published, approved properties.
- Apply `supabase/migrations/20261101_property_video_discovery.sql` to an existing project if the migration has not already been applied.
- Full Gradle/device upload and playback testing is still required.


## v0.18.0 — Multi-property management
- Added an owner portfolio workspace with total, published, draft and pending-review metrics.
- Added title/city search, listing-status filters and sort order controls.
- Added per-property shortcuts to rooms/units, tenants, facilities/map, financial records, verification and vertical video upload.
- Reuses existing owner-scoped property queries and RLS policies; no schema migration required.
- Android Gradle/device testing has not been run in this environment; import and test in CodeAssist.


## v1.0.0 — Integration & release preparation
- Version code 26 and version name 1.0.0.
- Android app-data backup is disabled; cleartext HTTP traffic is explicitly disallowed.
- See `CHANGELOG_v1.0.0.md` and the release checklist for required verification.
- A signed release artifact, a successful full Gradle build, real-device regression testing, a completed/hosted privacy policy and Play Console review are still outstanding.
## Continuous integration

GitHub Actions is configured in `.github/workflows/android-ci.yml` to run the debug build, Android lint, and JVM unit tests on pushes and pull requests. Successful runs publish a debug APK artifact; reports are uploaded to help diagnose failures. The workflow has not been confirmed green until it runs in GitHub Actions. See `BUILDING.md` and `CHANGELOG_STAGE_3.md` for details.
