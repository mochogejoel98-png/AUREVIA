-- AUREVIA v0.15.0: private, participant-only property conversations and messages.
create table if not exists public.property_conversations (
  id uuid primary key default gen_random_uuid(),
  property_id uuid not null references public.properties(id) on delete cascade,
  requester_id uuid not null references auth.users(id) on delete cascade,
  owner_id uuid not null references auth.users(id) on delete cascade,
  created_at timestamptz not null default now(),
  constraint property_conversations_not_self check (requester_id <> owner_id),
  constraint property_conversations_one_requester_per_property unique (property_id, requester_id)
);

create index if not exists property_conversations_requester_created_idx
  on public.property_conversations (requester_id, created_at desc);
create index if not exists property_conversations_owner_created_idx
  on public.property_conversations (owner_id, created_at desc);

create table if not exists public.property_messages (
  id uuid primary key default gen_random_uuid(),
  conversation_id uuid not null references public.property_conversations(id) on delete cascade,
  sender_id uuid not null references auth.users(id) on delete cascade,
  body text not null check (char_length(trim(body)) between 1 and 4000),
  created_at timestamptz not null default now()
);

create index if not exists property_messages_conversation_created_idx
  on public.property_messages (conversation_id, created_at asc);

alter table public.property_conversations enable row level security;
alter table public.property_messages enable row level security;

drop policy if exists "Participants can read property conversations" on public.property_conversations;
create policy "Participants can read property conversations"
  on public.property_conversations for select to authenticated
  using ((select auth.uid()) = requester_id or (select auth.uid()) = owner_id);

drop policy if exists "Requesters can start conversations for live listings" on public.property_conversations;
create policy "Requesters can start conversations for live listings"
  on public.property_conversations for insert to authenticated
  with check (
    requester_id = (select auth.uid())
    and exists (
      select 1 from public.properties p
      where p.id = property_conversations.property_id
        and p.owner_id = property_conversations.owner_id
        and p.owner_id <> (select auth.uid())
        and p.listing_status = 'published'
        and p.review_status = 'approved'
    )
  );

drop policy if exists "Participants can read messages" on public.property_messages;
create policy "Participants can read messages"
  on public.property_messages for select to authenticated
  using (exists (
    select 1 from public.property_conversations c
    where c.id = property_messages.conversation_id
      and ((select auth.uid()) = c.requester_id or (select auth.uid()) = c.owner_id)
  ));

drop policy if exists "Participants can send messages as themselves" on public.property_messages;
create policy "Participants can send messages as themselves"
  on public.property_messages for insert to authenticated
  with check (
    sender_id = (select auth.uid())
    and exists (
      select 1 from public.property_conversations c
      where c.id = property_messages.conversation_id
        and ((select auth.uid()) = c.requester_id or (select auth.uid()) = c.owner_id)
    )
  );

revoke all on table public.property_conversations from anon;
revoke all on table public.property_messages from anon;
revoke update, delete, truncate, references, trigger on table public.property_conversations from authenticated;
revoke update, delete, truncate, references, trigger on table public.property_messages from authenticated;
grant select, insert on table public.property_conversations to authenticated;
grant select, insert on table public.property_messages to authenticated;
