-- AUREVIA v0.17.0: private property-video storage with signed playback URLs.
create table if not exists public.property_videos (
  id uuid primary key default gen_random_uuid(),
  property_id uuid not null references public.properties(id) on delete cascade,
  owner_id uuid not null references public.profiles(id) on delete cascade,
  storage_path text not null unique,
  caption text not null default '' check (char_length(caption) <= 240),
  created_at timestamptz not null default now()
);
create index if not exists property_videos_property_created_idx on public.property_videos(property_id, created_at desc);
create index if not exists property_videos_owner_created_idx on public.property_videos(owner_id, created_at desc);
alter table public.property_videos enable row level security;
revoke all on public.property_videos from anon, authenticated;
grant select on public.property_videos to anon, authenticated;
grant insert, delete on public.property_videos to authenticated;
drop policy if exists "property videos public or owner read" on public.property_videos;
create policy "property videos public or owner read" on public.property_videos for select to anon, authenticated using (
  owner_id = (select auth.uid()) or exists (select 1 from public.properties p where p.id = property_id and p.listing_status = 'published' and p.review_status = 'approved') or (select public.is_aurevia_admin())
);
drop policy if exists "property video owner insert" on public.property_videos;
create policy "property video owner insert" on public.property_videos for insert to authenticated with check (
  owner_id = (select auth.uid()) and split_part(storage_path, '/', 1) = (select auth.uid())::text and exists (select 1 from public.properties p where p.id = property_id and p.owner_id = (select auth.uid()))
);
drop policy if exists "property video owner delete" on public.property_videos;
create policy "property video owner delete" on public.property_videos for delete to authenticated using (owner_id = (select auth.uid()) or (select public.is_aurevia_admin()));
insert into storage.buckets (id, name, public, file_size_limit, allowed_mime_types) values ('property-videos', 'property-videos', false, 52428800, array['video/mp4']) on conflict (id) do update set public = false, file_size_limit = 52428800, allowed_mime_types = array['video/mp4'];
drop policy if exists "property video upload own folder" on storage.objects;
create policy "property video upload own folder" on storage.objects for insert to authenticated with check (bucket_id = 'property-videos' and (storage.foldername(name))[1] = (select auth.uid())::text);
drop policy if exists "property video read owner or published listing" on storage.objects;
create policy "property video read owner or published listing" on storage.objects for select to anon, authenticated using (
  bucket_id = 'property-videos' and ((storage.foldername(name))[1] = (select auth.uid())::text or exists (select 1 from public.property_videos v join public.properties p on p.id = v.property_id where v.storage_path = name and p.listing_status = 'published' and p.review_status = 'approved') or (select public.is_aurevia_admin()))
);
drop policy if exists "property video delete own folder" on storage.objects;
create policy "property video delete own folder" on storage.objects for delete to authenticated using (bucket_id = 'property-videos' and ((storage.foldername(name))[1] = (select auth.uid())::text or (select public.is_aurevia_admin())));
