-- AUREVIA v0.14.0: owner-only property income/expense ledger.
-- Entries are intentionally insert-only from the client to preserve an audit trail.
create table if not exists public.property_financial_records (
  id uuid primary key default gen_random_uuid(),
  property_id uuid not null references public.properties(id) on delete cascade,
  record_type text not null check (record_type in ('income','expense')),
  category text not null check (char_length(trim(category)) between 2 and 80),
  amount numeric(14,2) not null check (amount > 0),
  currency_code text not null default 'KES' check (currency_code ~ '^[A-Z]{3}$'),
  transaction_date date not null default current_date,
  description text not null default '' check (char_length(description) <= 1000),
  payment_reference text not null default '' check (char_length(payment_reference) <= 120),
  created_by uuid not null default auth.uid() references auth.users(id),
  created_at timestamptz not null default now()
);

create index if not exists property_financial_records_property_date_idx
  on public.property_financial_records (property_id, transaction_date desc, created_at desc);

alter table public.property_financial_records enable row level security;

drop policy if exists "Owners can read their property financial records" on public.property_financial_records;
create policy "Owners can read their property financial records"
  on public.property_financial_records for select to authenticated
  using (exists (
    select 1 from public.properties p
    where p.id = property_financial_records.property_id
      and p.owner_id = (select auth.uid())
  ));

drop policy if exists "Owners can add their property financial records" on public.property_financial_records;
create policy "Owners can add their property financial records"
  on public.property_financial_records for insert to authenticated
  with check (
    created_by = (select auth.uid())
    and exists (
      select 1 from public.properties p
      where p.id = property_financial_records.property_id
        and p.owner_id = (select auth.uid())
    )
  );

-- Restrict the table to read/insert for signed-in users; no public access or mutation grants.
revoke all on table public.property_financial_records from anon;
revoke update, delete, truncate, references, trigger on table public.property_financial_records from authenticated;
grant select, insert on public.property_financial_records to authenticated;
