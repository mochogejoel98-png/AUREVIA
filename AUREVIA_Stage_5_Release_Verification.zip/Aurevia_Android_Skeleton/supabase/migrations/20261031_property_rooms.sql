-- AUREVIA v0.11.0: per-property room inventory.
-- Apply this migration in the Supabase SQL Editor before using Room Management.
create table if not exists public.property_rooms (
  id uuid primary key default gen_random_uuid(),
  property_id uuid not null references public.properties(id) on delete cascade,
  owner_id uuid not null references auth.users(id) on delete cascade,
  room_number text not null check (length(trim(room_number)) between 1 and 80),
  category text not null check (length(trim(category)) between 1 and 80),
  rent_amount numeric(12,2) not null default 0 check (rent_amount >= 0),
  currency_code text not null default 'KES' check (currency_code ~ '^[A-Z]{3}$'),
  status text not null default 'available' check (status in ('available','reserved','occupied','maintenance')),
  description text not null default '',
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  unique (property_id, room_number)
);

create index if not exists property_rooms_property_status_idx
  on public.property_rooms(property_id, status);

alter table public.property_rooms enable row level security;
revoke all on table public.property_rooms from anon, authenticated;
grant select, insert, update, delete on table public.property_rooms to authenticated;

drop policy if exists "Owners read rooms for their properties" on public.property_rooms;
create policy "Owners read rooms for their properties"
  on public.property_rooms for select to authenticated
  using (exists (
    select 1 from public.properties p
    where p.id = property_rooms.property_id and p.owner_id = (select auth.uid())
  ));

drop policy if exists "Owners add rooms to their properties" on public.property_rooms;
create policy "Owners add rooms to their properties"
  on public.property_rooms for insert to authenticated
  with check (
    owner_id = (select auth.uid()) and exists (
      select 1 from public.properties p
      where p.id = property_rooms.property_id and p.owner_id = (select auth.uid())
    )
  );

drop policy if exists "Owners update rooms for their properties" on public.property_rooms;
create policy "Owners update rooms for their properties"
  on public.property_rooms for update to authenticated
  using (exists (
    select 1 from public.properties p
    where p.id = property_rooms.property_id and p.owner_id = (select auth.uid())
  ))
  with check (
    owner_id = (select auth.uid()) and exists (
      select 1 from public.properties p
      where p.id = property_rooms.property_id and p.owner_id = (select auth.uid())
    )
  );

drop policy if exists "Owners delete rooms for their properties" on public.property_rooms;
create policy "Owners delete rooms for their properties"
  on public.property_rooms for delete to authenticated
  using (exists (
    select 1 from public.properties p
    where p.id = property_rooms.property_id and p.owner_id = (select auth.uid())
  ));

create or replace function public.set_property_room_status(p_room_id uuid, p_status text)
returns void
language plpgsql
security invoker
set search_path = pg_catalog, public
as $$
declare
  v_updated integer;
begin
  if p_status not in ('available','reserved','occupied','maintenance') then
    raise exception 'Unsupported room status';
  end if;
  update public.property_rooms set status = p_status, updated_at = now()
   where id = p_room_id;
  get diagnostics v_updated = row_count;
  if v_updated = 0 then
    raise exception 'Room not found or you are not authorized to update it';
  end if;
end;
$$;
revoke execute on function public.set_property_room_status(uuid,text) from public, anon;
grant execute on function public.set_property_room_status(uuid,text) to authenticated;
