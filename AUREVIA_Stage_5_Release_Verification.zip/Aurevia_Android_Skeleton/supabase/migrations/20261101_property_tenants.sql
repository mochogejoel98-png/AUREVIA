-- AUREVIA v0.12.0 tenant management. Apply after 20261031_property_rooms.sql.
create table if not exists public.property_tenants (
  id uuid primary key default gen_random_uuid(),
  property_id uuid not null references public.properties(id) on delete cascade,
  room_id uuid references public.property_rooms(id) on delete set null,
  owner_id uuid not null references auth.users(id) on delete cascade,
  full_name text not null check (length(trim(full_name)) between 1 and 160),
  phone text not null check (length(trim(phone)) between 3 and 40),
  email text,
  rent_amount numeric(12,2) not null check (rent_amount >= 0),
  currency_code text not null default 'KES' check (currency_code ~ '^[A-Z]{3}$'),
  lease_start date not null,
  lease_end date,
  notes text not null default '',
  status text not null default 'active' check (status in ('active','ended')),
  tenancy_ended_at timestamptz,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  check (lease_end is null or lease_end >= lease_start)
);
create index if not exists property_tenants_property_status_idx on public.property_tenants(property_id, status, created_at desc);
create index if not exists property_tenants_room_idx on public.property_tenants(room_id) where status = 'active';
create unique index if not exists property_tenants_one_active_per_room_idx
  on public.property_tenants(room_id) where status = 'active' and room_id is not null;

alter table public.property_tenants enable row level security;
revoke all on public.property_tenants from anon, authenticated;
grant select on public.property_tenants to authenticated;
drop policy if exists "Owners read tenants for their properties" on public.property_tenants;
create policy "Owners read tenants for their properties" on public.property_tenants
for select to authenticated using (
  owner_id = (select auth.uid()) and exists (
    select 1 from public.properties p where p.id = property_tenants.property_id and p.owner_id = (select auth.uid())
  )
);

create or replace function public.create_property_tenant(
  p_property_id uuid, p_room_id uuid, p_full_name text, p_phone text, p_email text,
  p_rent_amount numeric, p_lease_start date, p_lease_end date, p_notes text
) returns uuid
language plpgsql security definer set search_path = pg_catalog, public
as $$
declare v_owner uuid; v_room public.property_rooms%rowtype; v_tenant_id uuid;
begin
  if auth.uid() is null then raise exception 'Sign in is required'; end if;
  if length(trim(coalesce(p_full_name,''))) = 0 or length(trim(coalesce(p_phone,''))) = 0 then raise exception 'Tenant name and phone are required'; end if;
  if p_rent_amount is null or p_rent_amount < 0 then raise exception 'Rent amount must be zero or greater'; end if;
  if p_lease_start is null or (p_lease_end is not null and p_lease_end < p_lease_start) then raise exception 'Invalid lease dates'; end if;
  select owner_id into v_owner from public.properties where id = p_property_id;
  if v_owner is null or v_owner <> auth.uid() then raise exception 'Property not found or you are not authorized'; end if;
  select * into v_room from public.property_rooms where id = p_room_id and property_id = p_property_id for update;
  if not found then raise exception 'Room does not belong to this property'; end if;
  if v_room.status <> 'available' then raise exception 'This room is not available'; end if;
  insert into public.property_tenants(property_id, room_id, owner_id, full_name, phone, email, rent_amount, currency_code, lease_start, lease_end, notes, status)
  values (p_property_id, p_room_id, auth.uid(), trim(p_full_name), trim(p_phone), nullif(trim(coalesce(p_email,'')),''), p_rent_amount,
    v_room.currency_code, p_lease_start, p_lease_end, coalesce(p_notes,''), 'active') returning id into v_tenant_id;
  update public.property_rooms set status = 'occupied', updated_at = now() where id = p_room_id;
  return v_tenant_id;
end;
$$;
revoke execute on function public.create_property_tenant(uuid,uuid,text,text,text,numeric,date,date,text) from public, anon;
grant execute on function public.create_property_tenant(uuid,uuid,text,text,text,numeric,date,date,text) to authenticated;

create or replace function public.end_property_tenancy(p_tenant_id uuid) returns void
language plpgsql security definer set search_path = pg_catalog, public
as $$
declare v_tenant public.property_tenants%rowtype;
begin
  if auth.uid() is null then raise exception 'Sign in is required'; end if;
  select * into v_tenant from public.property_tenants where id = p_tenant_id for update;
  if not found or v_tenant.owner_id <> auth.uid() or not exists (
    select 1 from public.properties p where p.id = v_tenant.property_id and p.owner_id = auth.uid()
  ) then raise exception 'Tenant not found or you are not authorized'; end if;
  if v_tenant.status <> 'active' then raise exception 'This tenancy has already ended'; end if;
  update public.property_tenants set status = 'ended', tenancy_ended_at = now(), updated_at = now() where id = p_tenant_id;
  if v_tenant.room_id is not null then
    update public.property_rooms set status = 'available', updated_at = now()
      where id = v_tenant.room_id and property_id = v_tenant.property_id and status = 'occupied';
  end if;
end;
$$;
revoke execute on function public.end_property_tenancy(uuid) from public, anon;
grant execute on function public.end_property_tenancy(uuid) to authenticated;


-- Keep room status aligned with active tenant records, including direct table updates.
create or replace function public.guard_room_tenancy_status()
returns trigger language plpgsql security invoker set search_path = pg_catalog, public
as $$
declare v_has_active_tenant boolean;
begin
  if tg_op = 'DELETE' then
    if exists (select 1 from public.property_tenants t where t.room_id = old.id and t.status = 'active') then
      raise exception 'End the active tenancy before deleting this room';
    end if;
    return old;
  end if;
  if new.status is distinct from old.status then
    select exists (select 1 from public.property_tenants t where t.room_id = new.id and t.status = 'active') into v_has_active_tenant;
    if v_has_active_tenant and new.status <> 'occupied' then
      raise exception 'A room with an active tenant must remain occupied';
    end if;
    if new.status = 'occupied' and not v_has_active_tenant then
      raise exception 'Assign a tenant through Tenant Management before marking a room occupied';
    end if;
  end if;
  return new;
end;
$$;
drop trigger if exists guard_room_tenancy_status_trigger on public.property_rooms;
create trigger guard_room_tenancy_status_trigger before update of status or delete on public.property_rooms
for each row execute function public.guard_room_tenancy_status();
revoke execute on function public.guard_room_tenancy_status() from public, anon, authenticated;
