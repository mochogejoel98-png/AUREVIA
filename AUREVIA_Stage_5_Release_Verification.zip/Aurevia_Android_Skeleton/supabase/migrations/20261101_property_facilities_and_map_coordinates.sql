-- AUREVIA v0.13.0: public listing facilities and optional map coordinates.
alter table public.properties
  add column if not exists latitude double precision,
  add column if not exists longitude double precision;

do $$
begin
  if not exists (select 1 from pg_constraint where conname = 'properties_latitude_range_check') then
    alter table public.properties add constraint properties_latitude_range_check
      check (latitude is null or latitude between -90 and 90);
  end if;
  if not exists (select 1 from pg_constraint where conname = 'properties_longitude_range_check') then
    alter table public.properties add constraint properties_longitude_range_check
      check (longitude is null or longitude between -180 and 180);
  end if;
  if not exists (select 1 from pg_constraint where conname = 'properties_coordinates_pair_check') then
    alter table public.properties add constraint properties_coordinates_pair_check
      check ((latitude is null and longitude is null) or (latitude is not null and longitude is not null));
  end if;
end $$;

create index if not exists properties_coordinates_idx
  on public.properties(latitude, longitude)
  where latitude is not null and longitude is not null;

create table if not exists public.property_facilities (
  id uuid primary key default gen_random_uuid(),
  property_id uuid not null references public.properties(id) on delete cascade,
  facility_name text not null check (length(trim(facility_name)) between 2 and 100),
  category text not null default 'other'
    check (category in ('utilities','security','parking','recreation','connectivity','nearby','accessibility','other')),
  notes text not null default '',
  created_at timestamptz not null default now(),
  unique (property_id, facility_name)
);

create index if not exists property_facilities_property_idx
  on public.property_facilities(property_id, category, facility_name);

alter table public.property_facilities enable row level security;
revoke all on public.property_facilities from anon, authenticated;
grant select on public.property_facilities to anon, authenticated;
grant insert, update, delete on public.property_facilities to authenticated;

drop policy if exists "Public read facilities for live listings" on public.property_facilities;
drop policy if exists "Owners read facilities for their properties" on public.property_facilities;
drop policy if exists "Facilities visible to owner or public live listing" on public.property_facilities;
create policy "Facilities visible to owner or public live listing"
  on public.property_facilities for select to anon, authenticated
  using (
    exists (
      select 1 from public.properties p
      where p.id = property_facilities.property_id
        and p.listing_status = 'published'
        and p.review_status = 'approved'
    )
    or exists (
      select 1 from public.properties p
      where p.id = property_facilities.property_id
        and p.owner_id = (select auth.uid())
    )
  );

drop policy if exists "Owners add facilities to their properties" on public.property_facilities;
create policy "Owners add facilities to their properties"
  on public.property_facilities for insert to authenticated
  with check (exists (
    select 1 from public.properties p
    where p.id = property_facilities.property_id
      and p.owner_id = (select auth.uid())
  ));

drop policy if exists "Owners update facilities for their properties" on public.property_facilities;
create policy "Owners update facilities for their properties"
  on public.property_facilities for update to authenticated
  using (exists (
    select 1 from public.properties p
    where p.id = property_facilities.property_id
      and p.owner_id = (select auth.uid())
  ))
  with check (exists (
    select 1 from public.properties p
    where p.id = property_facilities.property_id
      and p.owner_id = (select auth.uid())
  ));

drop policy if exists "Owners delete facilities from their properties" on public.property_facilities;
create policy "Owners delete facilities from their properties"
  on public.property_facilities for delete to authenticated
  using (exists (
    select 1 from public.properties p
    where p.id = property_facilities.property_id
      and p.owner_id = (select auth.uid())
  ));
