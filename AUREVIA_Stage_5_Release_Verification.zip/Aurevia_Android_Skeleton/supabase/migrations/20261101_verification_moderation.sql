-- AUREVIA v0.16.0: harden reports and private verification evidence; add moderator audit fields.
alter table public.property_verification_documents
  add column if not exists reviewed_by uuid references public.profiles(id),
  add column if not exists reviewed_at timestamptz;

create index if not exists property_reports_status_created_idx
  on public.property_reports (status, created_at asc);
create index if not exists property_verification_owner_created_idx
  on public.property_verification_documents (owner_id, created_at desc);
create index if not exists property_verification_status_created_idx
  on public.property_verification_documents (review_status, created_at asc);

create or replace function public.guard_aurevia_report_insert()
returns trigger
language plpgsql
security invoker
set search_path = pg_catalog, public
as $$
begin
  if new.reporter_id is distinct from (select auth.uid()) then
    raise exception 'A report must belong to the signed-in reporter';
  end if;
  if new.status is distinct from 'open' then
    raise exception 'New reports must begin in open status';
  end if;
  if not exists (
    select 1 from public.properties p
    where p.id = new.property_id
      and p.listing_status = 'published'
      and p.review_status = 'approved'
      and p.owner_id <> (select auth.uid())
  ) then
    raise exception 'Only another users published property can be reported';
  end if;
  new.reason := left(trim(new.reason), 80);
  if char_length(new.reason) < 3 then
    raise exception 'A report reason is required';
  end if;
  new.details := nullif(left(trim(coalesce(new.details, '')), 2000), '');
  return new;
end;
$$;

drop trigger if exists guard_aurevia_report_insert_trigger on public.property_reports;
create trigger guard_aurevia_report_insert_trigger
before insert on public.property_reports
for each row execute function public.guard_aurevia_report_insert();

create or replace function public.guard_verification_document_changes()
returns trigger
language plpgsql
security invoker
set search_path = pg_catalog, public
as $$
begin
  if tg_op = 'INSERT' then
    if new.owner_id is distinct from (select auth.uid()) then
      raise exception 'Verification records must belong to the signed-in owner';
    end if;
    if new.review_status is distinct from 'pending' or new.reviewed_by is not null or new.reviewed_at is not null then
      raise exception 'New verification records must be pending and unreviewed';
    end if;
    if new.document_type not in ('ownership_proof', 'authorization_letter', 'identity_document', 'other') then
      raise exception 'Unsupported verification document type';
    end if;
    if split_part(new.storage_path, '/', 1) <> (select auth.uid())::text then
      raise exception 'Verification storage path must be inside the owners private folder';
    end if;
    if not exists (select 1 from public.properties p where p.id = new.property_id and p.owner_id = (select auth.uid())) then
      raise exception 'Verification evidence must refer to a property owned by this account';
    end if;
    return new;
  end if;

  if not (select public.is_aurevia_admin()) then
    raise exception 'Only moderators can review verification evidence';
  end if;
  if new.owner_id is distinct from old.owner_id
     or new.property_id is distinct from old.property_id
     or new.storage_path is distinct from old.storage_path
     or new.document_type is distinct from old.document_type
     or new.created_at is distinct from old.created_at then
    raise exception 'Verification evidence details are immutable after submission';
  end if;
  if new.review_status not in ('approved', 'rejected', 'pending') then
    raise exception 'Invalid verification review status';
  end if;
  new.reviewed_by := (select auth.uid());
  new.reviewed_at := now();
  return new;
end;
$$;

drop trigger if exists guard_verification_document_changes_trigger on public.property_verification_documents;
create trigger guard_verification_document_changes_trigger
before insert or update on public.property_verification_documents
for each row execute function public.guard_verification_document_changes();

drop policy if exists "verification docs admin update" on public.property_verification_documents;
create policy "verification docs admin update" on public.property_verification_documents
for update to authenticated
using ((select public.is_aurevia_admin()))
with check ((select public.is_aurevia_admin()));

-- Owners may submit and read their own evidence; only admins may change review status.
-- Keep this bucket private; no anonymous read access is added.
revoke all on public.property_reports, public.property_verification_documents from anon;
revoke delete, truncate, references, trigger on public.property_reports from authenticated;
revoke delete, truncate, references, trigger on public.property_verification_documents from authenticated;
grant select, insert, update on public.property_reports to authenticated;
grant select, insert, update on public.property_verification_documents to authenticated;
