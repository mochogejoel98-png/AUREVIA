-- Least-privilege follow-up for v0.16.0 moderation tables.
revoke delete, truncate, references, trigger on public.property_reports from authenticated;
revoke delete, truncate, references, trigger on public.property_verification_documents from authenticated;
revoke all on public.property_reports, public.property_verification_documents from anon;
grant select, insert, update on public.property_reports to authenticated;
grant select, insert, update on public.property_verification_documents to authenticated;
