-- Keep creation pending-only and tied to the signed-in requester.
drop policy if exists "viewing request requester create" on public.viewing_requests;
create policy "viewing request requester create" on public.viewing_requests
for insert to authenticated
with check (requester_id = (select auth.uid()) and status = 'pending');

-- v0.10 viewing appointment integrity rules.
-- A requester can only create pending requests for public, approved properties.
-- Requesters can cancel their own pending/accepted requests; property owners can
-- accept/decline pending requests or mark accepted viewings completed.
create or replace function public.guard_viewing_request_changes()
returns trigger
language plpgsql
security invoker
set search_path = pg_catalog, public
as $$
declare
  v_owner_id uuid;
begin
  if tg_op = 'INSERT' then
    if new.requester_id is distinct from (select auth.uid()) then
      raise exception 'A viewing request must belong to the signed-in requester';
    end if;
    if new.status <> 'pending' then
      raise exception 'New viewing requests must start as pending';
    end if;
    if new.requested_at <= now() then
      raise exception 'Choose a future viewing date and time';
    end if;
    select p.owner_id into v_owner_id
      from public.properties p
      where p.id = new.property_id
        and p.listing_status = 'published'
        and p.review_status = 'approved';
    if v_owner_id is null then
      raise exception 'This property is not currently available for viewing requests';
    end if;
    if v_owner_id = (select auth.uid()) then
      raise exception 'You cannot request a viewing for your own property';
    end if;
    return new;
  end if;

  if new.property_id is distinct from old.property_id
     or new.requester_id is distinct from old.requester_id
     or new.requested_at is distinct from old.requested_at
     or new.message is distinct from old.message
     or new.created_at is distinct from old.created_at then
    raise exception 'Viewing request details cannot be changed after submission';
  end if;

  if (select auth.uid()) = old.requester_id then
    if old.status not in ('pending', 'accepted') or new.status <> 'cancelled' then
      raise exception 'Requesters may only cancel pending or accepted viewing requests';
    end if;
    return new;
  end if;

  select p.owner_id into v_owner_id
    from public.properties p where p.id = old.property_id;

  if (select auth.uid()) = v_owner_id then
    if not (
      (old.status = 'pending' and new.status in ('accepted', 'declined'))
      or (old.status = 'accepted' and new.status = 'completed')
    ) then
      raise exception 'Owners may accept or decline pending requests, or complete accepted viewings';
    end if;
  else
    raise exception 'You are not authorized to change this viewing request';
  end if;

  return new;
end;
$$;

revoke execute on function public.guard_viewing_request_changes() from public, anon, authenticated;
drop trigger if exists guard_viewing_request_update_trigger on public.viewing_requests;
drop function if exists public.guard_viewing_request_update();
drop trigger if exists guard_viewing_request_changes_trigger on public.viewing_requests;
create trigger guard_viewing_request_changes_trigger
before insert or update on public.viewing_requests
for each row execute function public.guard_viewing_request_changes();

-- SECURITY INVOKER keeps the caller's grants and RLS policies in force.
-- POST is used by the Android client because HttpURLConnection PATCH support is inconsistent.
create or replace function public.respond_to_viewing_request(p_request_id uuid, p_status text)
returns void
language plpgsql
security invoker
set search_path = pg_catalog, public
as $$
declare
  v_updated integer;
begin
  if p_status not in ('accepted', 'declined', 'cancelled', 'completed') then
    raise exception 'Unsupported viewing request status';
  end if;

  update public.viewing_requests
     set status = p_status
   where id = p_request_id;

  get diagnostics v_updated = row_count;
  if v_updated = 0 then
    raise exception 'Viewing request not found or you are not authorized to update it';
  end if;
end;
$$;

revoke execute on function public.respond_to_viewing_request(uuid, text) from public, anon;
grant execute on function public.respond_to_viewing_request(uuid, text) to authenticated;
