-- AUREVIA initial Supabase schema
-- Run once in Supabase Dashboard > SQL Editor.
-- This script creates the first marketplace tables and baseline Row Level Security.
-- It does NOT create an admin account or publish any properties.

create extension if not exists pgcrypto;

create table if not exists public.profiles (
    id uuid primary key references auth.users(id) on delete cascade,
    display_name text,
    avatar_path text,
    account_type text not null default 'customer'
        check (account_type in ('customer', 'landlord', 'agent', 'admin')),
    country_code char(2),
    preferred_currency char(3),
    created_at timestamptz not null default now(),
    updated_at timestamptz not null default now()
);

create or replace function public.is_aurevia_admin()
returns boolean
language sql
stable
security definer
set search_path = public
as $$
    select exists (
        select 1 from public.profiles
        where id = auth.uid() and account_type = 'admin'
    );
$$;

create or replace function public.protect_profile_role()
returns trigger
language plpgsql
security definer
set search_path = public
as $$
begin
    if auth.uid() is not null
       and not public.is_aurevia_admin()
       and new.account_type is distinct from old.account_type then
        raise exception 'Account type cannot be changed by the account holder';
    end if;
    new.updated_at := now();
    return new;
end;
$$;

drop trigger if exists protect_profile_role_trigger on public.profiles;
create trigger protect_profile_role_trigger
before update on public.profiles
for each row execute function public.protect_profile_role();

create or replace function public.create_profile_for_new_user()
returns trigger
language plpgsql
security definer
set search_path = public
as $$
begin
    insert into public.profiles (id, display_name)
    values (
        new.id,
        coalesce(new.raw_user_meta_data ->> 'display_name', '')
    )
    on conflict (id) do nothing;
    return new;
end;
$$;

drop trigger if exists on_auth_user_created_aurevia on auth.users;
create trigger on_auth_user_created_aurevia
after insert on auth.users
for each row execute function public.create_profile_for_new_user();

create table if not exists public.properties (
    id uuid primary key default gen_random_uuid(),
    owner_id uuid not null references public.profiles(id) on delete restrict,
    purpose text not null check (purpose in ('rent', 'sale')),
    property_type text not null
        check (property_type in ('apartment', 'house', 'studio', 'townhouse', 'land', 'commercial', 'other')),
    title text not null check (char_length(title) between 5 and 120),
    description text not null default '',
    country_code char(2) not null,
    country_name text not null,
    region text,
    city text not null,
    neighbourhood text,
    address_private text,
    currency_code char(3) not null,
    price numeric(14,2) not null check (price >= 0),
    rent_period text check (rent_period in ('day', 'week', 'month', 'year')),
    bedrooms smallint check (bedrooms >= 0),
    bathrooms numeric(3,1) check (bathrooms >= 0),
    floor_area numeric(12,2) check (floor_area >= 0),
    floor_area_unit text check (floor_area_unit in ('m2', 'sqft')),
    listing_status text not null default 'draft'
        check (listing_status in ('draft', 'published', 'paused', 'rented', 'sold', 'expired')),
    review_status text not null default 'pending'
        check (review_status in ('pending', 'approved', 'rejected')),
    reviewed_by uuid references public.profiles(id),
    reviewed_at timestamptz,
    last_confirmed_available_at timestamptz,
    created_at timestamptz not null default now(),
    updated_at timestamptz not null default now()
);

create index if not exists properties_public_search_idx
on public.properties (country_code, city, purpose, property_type, price)
where listing_status = 'published' and review_status = 'approved';

create index if not exists properties_owner_idx
on public.properties (owner_id, created_at desc);

create or replace function public.guard_property_moderation()
returns trigger
language plpgsql
security definer
set search_path = public
as $$
begin
    if auth.uid() is not null and not public.is_aurevia_admin() then
        if new.review_status is distinct from old.review_status
           and new.review_status <> 'pending' then
            raise exception 'Only moderators can approve or reject a listing';
        end if;
        if new.reviewed_by is distinct from old.reviewed_by
           or new.reviewed_at is distinct from old.reviewed_at then
            raise exception 'Moderation fields are restricted';
        end if;
    end if;

    if new.listing_status = 'published' and new.review_status <> 'approved' then
        raise exception 'A listing must be approved before publication';
    end if;

    new.updated_at := now();
    return new;
end;
$$;

drop trigger if exists guard_property_moderation_trigger on public.properties;
create trigger guard_property_moderation_trigger
before update on public.properties
for each row execute function public.guard_property_moderation();

create table if not exists public.property_photos (
    id uuid primary key default gen_random_uuid(),
    property_id uuid not null references public.properties(id) on delete cascade,
    storage_path text not null unique,
    caption text,
    display_order integer not null default 0,
    created_at timestamptz not null default now()
);

create index if not exists property_photos_property_idx
on public.property_photos (property_id, display_order);

create table if not exists public.favorites (
    user_id uuid not null references public.profiles(id) on delete cascade,
    property_id uuid not null references public.properties(id) on delete cascade,
    created_at timestamptz not null default now(),
    primary key (user_id, property_id)
);

create table if not exists public.viewing_requests (
    id uuid primary key default gen_random_uuid(),
    property_id uuid not null references public.properties(id) on delete cascade,
    requester_id uuid not null references public.profiles(id) on delete cascade,
    requested_at timestamptz not null,
    message text,
    status text not null default 'pending'
        check (status in ('pending', 'accepted', 'declined', 'cancelled', 'completed')),
    created_at timestamptz not null default now()
);

create table if not exists public.property_reports (
    id uuid primary key default gen_random_uuid(),
    property_id uuid not null references public.properties(id) on delete cascade,
    reporter_id uuid not null references public.profiles(id) on delete cascade,
    reason text not null,
    details text,
    status text not null default 'open'
        check (status in ('open', 'reviewing', 'resolved', 'dismissed')),
    created_at timestamptz not null default now()
);

create table if not exists public.property_verification_documents (
    id uuid primary key default gen_random_uuid(),
    property_id uuid not null references public.properties(id) on delete cascade,
    owner_id uuid not null references public.profiles(id) on delete cascade,
    storage_path text not null unique,
    document_type text not null,
    review_status text not null default 'pending'
        check (review_status in ('pending', 'approved', 'rejected')),
    created_at timestamptz not null default now()
);

-- Enable RLS on every app table.
alter table public.profiles enable row level security;
alter table public.properties enable row level security;
alter table public.property_photos enable row level security;
alter table public.favorites enable row level security;
alter table public.viewing_requests enable row level security;
alter table public.property_reports enable row level security;
alter table public.property_verification_documents enable row level security;

-- Explicit table grants: public visitors can only read published, approved properties/photos.
revoke all on public.profiles, public.properties, public.property_photos,
    public.favorites, public.viewing_requests, public.property_reports,
    public.property_verification_documents from anon, authenticated;

grant select on public.properties, public.property_photos to anon;
grant select, insert, update, delete on public.profiles, public.properties,
    public.property_photos, public.favorites, public.viewing_requests,
    public.property_reports, public.property_verification_documents to authenticated;

-- Profiles: users see and edit only their own profile; admins can manage all profiles.
drop policy if exists "profile read own or admin" on public.profiles;
create policy "profile read own or admin" on public.profiles
for select to authenticated
using (id = (select auth.uid()) or (select public.is_aurevia_admin()));

drop policy if exists "profile insert own" on public.profiles;
create policy "profile insert own" on public.profiles
for insert to authenticated
with check (id = (select auth.uid()) and account_type = 'customer');

drop policy if exists "profile update own or admin" on public.profiles;
create policy "profile update own or admin" on public.profiles
for update to authenticated
using (id = (select auth.uid()) or (select public.is_aurevia_admin()))
with check (id = (select auth.uid()) or (select public.is_aurevia_admin()));

-- Public visitors can read approved published listings. Owners and admins can read their own/unpublished records.
drop policy if exists "properties public or owner read" on public.properties;
create policy "properties public or owner read" on public.properties
for select to anon, authenticated
using (
    (listing_status = 'published' and review_status = 'approved')
    or owner_id = (select auth.uid())
    or (select public.is_aurevia_admin())
);

drop policy if exists "property owner create" on public.properties;
create policy "property owner create" on public.properties
for insert to authenticated
with check (
    owner_id = (select auth.uid())
    and listing_status = 'draft'
    and review_status = 'pending'
);

drop policy if exists "property owner update or admin" on public.properties;
create policy "property owner update or admin" on public.properties
for update to authenticated
using (owner_id = (select auth.uid()) or (select public.is_aurevia_admin()))
with check (owner_id = (select auth.uid()) or (select public.is_aurevia_admin()));

drop policy if exists "property owner delete draft or admin" on public.properties;
create policy "property owner delete draft or admin" on public.properties
for delete to authenticated
using (
    (owner_id = (select auth.uid()) and listing_status = 'draft')
    or (select public.is_aurevia_admin())
);

-- Photos: public reads only when the parent property is public; owners manage their own.
drop policy if exists "photos public or owner read" on public.property_photos;
create policy "photos public or owner read" on public.property_photos
for select to anon, authenticated
using (
    exists (
        select 1 from public.properties p
        where p.id = property_id
          and (
            (p.listing_status = 'published' and p.review_status = 'approved')
            or p.owner_id = (select auth.uid())
            or (select public.is_aurevia_admin())
          )
    )
);

drop policy if exists "photo owner insert" on public.property_photos;
create policy "photo owner insert" on public.property_photos
for insert to authenticated
with check (
    exists (
        select 1 from public.properties p
        where p.id = property_id and p.owner_id = (select auth.uid())
    )
);

drop policy if exists "photo owner update" on public.property_photos;
create policy "photo owner update" on public.property_photos
for update to authenticated
using (
    exists (select 1 from public.properties p
            where p.id = property_id and p.owner_id = (select auth.uid()))
)
with check (
    exists (select 1 from public.properties p
            where p.id = property_id and p.owner_id = (select auth.uid()))
);

drop policy if exists "photo owner delete" on public.property_photos;
create policy "photo owner delete" on public.property_photos
for delete to authenticated
using (
    exists (select 1 from public.properties p
            where p.id = property_id and p.owner_id = (select auth.uid()))
    or (select public.is_aurevia_admin())
);

-- Favorites: each user manages only their own saved listings.
drop policy if exists "favorites own rows" on public.favorites;
create policy "favorites own rows" on public.favorites
for all to authenticated
using (user_id = (select auth.uid()))
with check (user_id = (select auth.uid()));

-- Viewing requests: requester and property owner can view; only requester creates.
drop policy if exists "viewing request requester or owner read" on public.viewing_requests;
create policy "viewing request requester or owner read" on public.viewing_requests
for select to authenticated
using (
    requester_id = (select auth.uid())
    or exists (select 1 from public.properties p
               where p.id = property_id and p.owner_id = (select auth.uid()))
    or (select public.is_aurevia_admin())
);

drop policy if exists "viewing request requester create" on public.viewing_requests;
create policy "viewing request requester create" on public.viewing_requests
for insert to authenticated
with check (requester_id = (select auth.uid()) and status = 'pending');

drop policy if exists "viewing request participants update" on public.viewing_requests;
create policy "viewing request participants update" on public.viewing_requests
for update to authenticated
using (
    requester_id = (select auth.uid())
    or exists (select 1 from public.properties p
               where p.id = property_id and p.owner_id = (select auth.uid()))
    or (select public.is_aurevia_admin())
)
with check (
    requester_id = (select auth.uid())
    or exists (select 1 from public.properties p
               where p.id = property_id and p.owner_id = (select auth.uid()))
    or (select public.is_aurevia_admin())
);

-- Reports: reporters can create and view their own; moderators can view/update all.
drop policy if exists "reports reporter or admin read" on public.property_reports;
create policy "reports reporter or admin read" on public.property_reports
for select to authenticated
using (reporter_id = (select auth.uid()) or (select public.is_aurevia_admin()));

drop policy if exists "reports authenticated create" on public.property_reports;
create policy "reports authenticated create" on public.property_reports
for insert to authenticated
with check (reporter_id = (select auth.uid()));

drop policy if exists "reports admin update" on public.property_reports;
create policy "reports admin update" on public.property_reports
for update to authenticated
using ((select public.is_aurevia_admin()))
with check ((select public.is_aurevia_admin()));

-- Ownership/authorization evidence is private. Only its owner and admins can access metadata.
drop policy if exists "verification docs owner or admin read" on public.property_verification_documents;
create policy "verification docs owner or admin read" on public.property_verification_documents
for select to authenticated
using (owner_id = (select auth.uid()) or (select public.is_aurevia_admin()));

drop policy if exists "verification docs owner create" on public.property_verification_documents;
create policy "verification docs owner create" on public.property_verification_documents
for insert to authenticated
with check (
    owner_id = (select auth.uid())
    and exists (select 1 from public.properties p
                where p.id = property_id and p.owner_id = (select auth.uid()))
);

-- Storage buckets: public property photos; private verification evidence.
insert into storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
values
    ('property-photos', 'property-photos', true, 10485760,
     array['image/jpeg', 'image/png', 'image/webp']),
    ('verification-documents', 'verification-documents', false, 10485760,
     array['image/jpeg', 'image/png', 'application/pdf'])
on conflict (id) do nothing;

drop policy if exists "property photo upload own folder" on storage.objects;
create policy "property photo upload own folder" on storage.objects
for insert to authenticated
with check (
    bucket_id = 'property-photos'
    and (storage.foldername(name))[1] = (select auth.uid())::text
);

drop policy if exists "property photo update own folder" on storage.objects;
create policy "property photo update own folder" on storage.objects
for update to authenticated
using (
    bucket_id = 'property-photos'
    and (storage.foldername(name))[1] = (select auth.uid())::text
)
with check (
    bucket_id = 'property-photos'
    and (storage.foldername(name))[1] = (select auth.uid())::text
);

drop policy if exists "property photo delete own folder" on storage.objects;
create policy "property photo delete own folder" on storage.objects
for delete to authenticated
using (
    bucket_id = 'property-photos'
    and (storage.foldername(name))[1] = (select auth.uid())::text
);

drop policy if exists "verification upload own folder" on storage.objects;
create policy "verification upload own folder" on storage.objects
for insert to authenticated
with check (
    bucket_id = 'verification-documents'
    and (storage.foldername(name))[1] = (select auth.uid())::text
);

drop policy if exists "verification read own folder or admin" on storage.objects;
create policy "verification read own folder or admin" on storage.objects
for select to authenticated
using (
    bucket_id = 'verification-documents'
    and (
        (storage.foldername(name))[1] = (select auth.uid())::text
        or (select public.is_aurevia_admin())
    )
);

drop policy if exists "verification delete own folder or admin" on storage.objects;
create policy "verification delete own folder or admin" on storage.objects
for delete to authenticated
using (
    bucket_id = 'verification-documents'
    and (
        (storage.foldername(name))[1] = (select auth.uid())::text
        or (select public.is_aurevia_admin())
    )
);

-- IMPORTANT: promote the first trusted moderator manually from the SQL editor
-- only after that person has registered:
-- update public.profiles set account_type = 'admin' where id = '<AUTH_USER_UUID>';


-- v0.10 viewing appointment integrity rules.
-- A requester can only create pending requests for public, approved properties.
-- Requesters can cancel their own pending/accepted requests; property owners can
-- accept/decline pending requests or mark accepted viewings completed.
create or replace function public.guard_viewing_request_changes()
returns trigger
language plpgsql
security invoker
set search_path = pg_catalog, public
as $$
declare
  v_owner_id uuid;
begin
  if tg_op = 'INSERT' then
    if new.requester_id is distinct from (select auth.uid()) then
      raise exception 'A viewing request must belong to the signed-in requester';
    end if;
    if new.status <> 'pending' then
      raise exception 'New viewing requests must start as pending';
    end if;
    if new.requested_at <= now() then
      raise exception 'Choose a future viewing date and time';
    end if;
    select p.owner_id into v_owner_id
      from public.properties p
      where p.id = new.property_id
        and p.listing_status = 'published'
        and p.review_status = 'approved';
    if v_owner_id is null then
      raise exception 'This property is not currently available for viewing requests';
    end if;
    if v_owner_id = (select auth.uid()) then
      raise exception 'You cannot request a viewing for your own property';
    end if;
    return new;
  end if;

  if new.property_id is distinct from old.property_id
     or new.requester_id is distinct from old.requester_id
     or new.requested_at is distinct from old.requested_at
     or new.message is distinct from old.message
     or new.created_at is distinct from old.created_at then
    raise exception 'Viewing request details cannot be changed after submission';
  end if;

  if (select auth.uid()) = old.requester_id then
    if old.status not in ('pending', 'accepted') or new.status <> 'cancelled' then
      raise exception 'Requesters may only cancel pending or accepted viewing requests';
    end if;
    return new;
  end if;

  select p.owner_id into v_owner_id
    from public.properties p where p.id = old.property_id;

  if (select auth.uid()) = v_owner_id then
    if not (
      (old.status = 'pending' and new.status in ('accepted', 'declined'))
      or (old.status = 'accepted' and new.status = 'completed')
    ) then
      raise exception 'Owners may accept or decline pending requests, or complete accepted viewings';
    end if;
  else
    raise exception 'You are not authorized to change this viewing request';
  end if;

  return new;
end;
$$;

revoke execute on function public.guard_viewing_request_changes() from public, anon, authenticated;
drop trigger if exists guard_viewing_request_update_trigger on public.viewing_requests;
drop function if exists public.guard_viewing_request_update();
drop trigger if exists guard_viewing_request_changes_trigger on public.viewing_requests;
create trigger guard_viewing_request_changes_trigger
before insert or update on public.viewing_requests
for each row execute function public.guard_viewing_request_changes();

-- SECURITY INVOKER keeps the caller's grants and RLS policies in force.
-- POST is used by the Android client because HttpURLConnection PATCH support is inconsistent.
create or replace function public.respond_to_viewing_request(p_request_id uuid, p_status text)
returns void
language plpgsql
security invoker
set search_path = pg_catalog, public
as $$
declare
  v_updated integer;
begin
  if p_status not in ('accepted', 'declined', 'cancelled', 'completed') then
    raise exception 'Unsupported viewing request status';
  end if;

  update public.viewing_requests
     set status = p_status
   where id = p_request_id;

  get diagnostics v_updated = row_count;
  if v_updated = 0 then
    raise exception 'Viewing request not found or you are not authorized to update it';
  end if;
end;
$$;

revoke execute on function public.respond_to_viewing_request(uuid, text) from public, anon;
grant execute on function public.respond_to_viewing_request(uuid, text) to authenticated;

-- v0.11.0 room inventory schema (also available as a standalone migration).
-- See migrations/20261031_property_rooms.sql for the complete idempotent setup.


-- AUREVIA v0.13.0 facilities and map coordinate additions.
-- AUREVIA v0.13.0: public listing facilities and optional map coordinates.
alter table public.properties
  add column if not exists latitude double precision,
  add column if not exists longitude double precision;

do $$
begin
  if not exists (select 1 from pg_constraint where conname = 'properties_latitude_range_check') then
    alter table public.properties add constraint properties_latitude_range_check
      check (latitude is null or latitude between -90 and 90);
  end if;
  if not exists (select 1 from pg_constraint where conname = 'properties_longitude_range_check') then
    alter table public.properties add constraint properties_longitude_range_check
      check (longitude is null or longitude between -180 and 180);
  end if;
  if not exists (select 1 from pg_constraint where conname = 'properties_coordinates_pair_check') then
    alter table public.properties add constraint properties_coordinates_pair_check
      check ((latitude is null and longitude is null) or (latitude is not null and longitude is not null));
  end if;
end $$;

create index if not exists properties_coordinates_idx
  on public.properties(latitude, longitude)
  where latitude is not null and longitude is not null;

create table if not exists public.property_facilities (
  id uuid primary key default gen_random_uuid(),
  property_id uuid not null references public.properties(id) on delete cascade,
  facility_name text not null check (length(trim(facility_name)) between 2 and 100),
  category text not null default 'other'
    check (category in ('utilities','security','parking','recreation','connectivity','nearby','accessibility','other')),
  notes text not null default '',
  created_at timestamptz not null default now(),
  unique (property_id, facility_name)
);

create index if not exists property_facilities_property_idx
  on public.property_facilities(property_id, category, facility_name);

alter table public.property_facilities enable row level security;
revoke all on public.property_facilities from anon, authenticated;
grant select on public.property_facilities to anon, authenticated;
grant insert, update, delete on public.property_facilities to authenticated;

drop policy if exists "Public read facilities for live listings" on public.property_facilities;
drop policy if exists "Owners read facilities for their properties" on public.property_facilities;
drop policy if exists "Facilities visible to owner or public live listing" on public.property_facilities;
create policy "Facilities visible to owner or public live listing"
  on public.property_facilities for select to anon, authenticated
  using (
    exists (
      select 1 from public.properties p
      where p.id = property_facilities.property_id
        and p.listing_status = 'published'
        and p.review_status = 'approved'
    )
    or exists (
      select 1 from public.properties p
      where p.id = property_facilities.property_id
        and p.owner_id = (select auth.uid())
    )
  );

drop policy if exists "Owners add facilities to their properties" on public.property_facilities;
create policy "Owners add facilities to their properties"
  on public.property_facilities for insert to authenticated
  with check (exists (
    select 1 from public.properties p
    where p.id = property_facilities.property_id
      and p.owner_id = (select auth.uid())
  ));

drop policy if exists "Owners update facilities for their properties" on public.property_facilities;
create policy "Owners update facilities for their properties"
  on public.property_facilities for update to authenticated
  using (exists (
    select 1 from public.properties p
    where p.id = property_facilities.property_id
      and p.owner_id = (select auth.uid())
  ))
  with check (exists (
    select 1 from public.properties p
    where p.id = property_facilities.property_id
      and p.owner_id = (select auth.uid())
  ));

drop policy if exists "Owners delete facilities from their properties" on public.property_facilities;
create policy "Owners delete facilities from their properties"
  on public.property_facilities for delete to authenticated
  using (exists (
    select 1 from public.properties p
    where p.id = property_facilities.property_id
      and p.owner_id = (select auth.uid())
  ));


-- v0.15.0 private property messaging
-- AUREVIA v0.15.0: private, participant-only property conversations and messages.
create table if not exists public.property_conversations (
  id uuid primary key default gen_random_uuid(),
  property_id uuid not null references public.properties(id) on delete cascade,
  requester_id uuid not null references auth.users(id) on delete cascade,
  owner_id uuid not null references auth.users(id) on delete cascade,
  created_at timestamptz not null default now(),
  constraint property_conversations_not_self check (requester_id <> owner_id),
  constraint property_conversations_one_requester_per_property unique (property_id, requester_id)
);

create index if not exists property_conversations_requester_created_idx
  on public.property_conversations (requester_id, created_at desc);
create index if not exists property_conversations_owner_created_idx
  on public.property_conversations (owner_id, created_at desc);

create table if not exists public.property_messages (
  id uuid primary key default gen_random_uuid(),
  conversation_id uuid not null references public.property_conversations(id) on delete cascade,
  sender_id uuid not null references auth.users(id) on delete cascade,
  body text not null check (char_length(trim(body)) between 1 and 4000),
  created_at timestamptz not null default now()
);

create index if not exists property_messages_conversation_created_idx
  on public.property_messages (conversation_id, created_at asc);

alter table public.property_conversations enable row level security;
alter table public.property_messages enable row level security;

drop policy if exists "Participants can read property conversations" on public.property_conversations;
create policy "Participants can read property conversations"
  on public.property_conversations for select to authenticated
  using ((select auth.uid()) = requester_id or (select auth.uid()) = owner_id);

drop policy if exists "Requesters can start conversations for live listings" on public.property_conversations;
create policy "Requesters can start conversations for live listings"
  on public.property_conversations for insert to authenticated
  with check (
    requester_id = (select auth.uid())
    and exists (
      select 1 from public.properties p
      where p.id = property_conversations.property_id
        and p.owner_id = property_conversations.owner_id
        and p.owner_id <> (select auth.uid())
        and p.listing_status = 'published'
        and p.review_status = 'approved'
    )
  );

drop policy if exists "Participants can read messages" on public.property_messages;
create policy "Participants can read messages"
  on public.property_messages for select to authenticated
  using (exists (
    select 1 from public.property_conversations c
    where c.id = property_messages.conversation_id
      and ((select auth.uid()) = c.requester_id or (select auth.uid()) = c.owner_id)
  ));

drop policy if exists "Participants can send messages as themselves" on public.property_messages;
create policy "Participants can send messages as themselves"
  on public.property_messages for insert to authenticated
  with check (
    sender_id = (select auth.uid())
    and exists (
      select 1 from public.property_conversations c
      where c.id = property_messages.conversation_id
        and ((select auth.uid()) = c.requester_id or (select auth.uid()) = c.owner_id)
    )
  );

revoke all on table public.property_conversations from anon;
revoke all on table public.property_messages from anon;
revoke update, delete, truncate, references, trigger on table public.property_conversations from authenticated;
revoke update, delete, truncate, references, trigger on table public.property_messages from authenticated;
grant select, insert on table public.property_conversations to authenticated;
grant select, insert on table public.property_messages to authenticated;

-- AUREVIA v0.16.0: harden reports and private verification evidence; add moderator audit fields.
alter table public.property_verification_documents
  add column if not exists reviewed_by uuid references public.profiles(id),
  add column if not exists reviewed_at timestamptz;

create index if not exists property_reports_status_created_idx
  on public.property_reports (status, created_at asc);
create index if not exists property_verification_owner_created_idx
  on public.property_verification_documents (owner_id, created_at desc);
create index if not exists property_verification_status_created_idx
  on public.property_verification_documents (review_status, created_at asc);

create or replace function public.guard_aurevia_report_insert()
returns trigger
language plpgsql
security invoker
set search_path = pg_catalog, public
as $$
begin
  if new.reporter_id is distinct from (select auth.uid()) then
    raise exception 'A report must belong to the signed-in reporter';
  end if;
  if new.status is distinct from 'open' then
    raise exception 'New reports must begin in open status';
  end if;
  if not exists (
    select 1 from public.properties p
    where p.id = new.property_id
      and p.listing_status = 'published'
      and p.review_status = 'approved'
      and p.owner_id <> (select auth.uid())
  ) then
    raise exception 'Only another users published property can be reported';
  end if;
  new.reason := left(trim(new.reason), 80);
  if char_length(new.reason) < 3 then
    raise exception 'A report reason is required';
  end if;
  new.details := nullif(left(trim(coalesce(new.details, '')), 2000), '');
  return new;
end;
$$;

drop trigger if exists guard_aurevia_report_insert_trigger on public.property_reports;
create trigger guard_aurevia_report_insert_trigger
before insert on public.property_reports
for each row execute function public.guard_aurevia_report_insert();

create or replace function public.guard_verification_document_changes()
returns trigger
language plpgsql
security invoker
set search_path = pg_catalog, public
as $$
begin
  if tg_op = 'INSERT' then
    if new.owner_id is distinct from (select auth.uid()) then
      raise exception 'Verification records must belong to the signed-in owner';
    end if;
    if new.review_status is distinct from 'pending' or new.reviewed_by is not null or new.reviewed_at is not null then
      raise exception 'New verification records must be pending and unreviewed';
    end if;
    if new.document_type not in ('ownership_proof', 'authorization_letter', 'identity_document', 'other') then
      raise exception 'Unsupported verification document type';
    end if;
    if split_part(new.storage_path, '/', 1) <> (select auth.uid())::text then
      raise exception 'Verification storage path must be inside the owners private folder';
    end if;
    if not exists (select 1 from public.properties p where p.id = new.property_id and p.owner_id = (select auth.uid())) then
      raise exception 'Verification evidence must refer to a property owned by this account';
    end if;
    return new;
  end if;

  if not (select public.is_aurevia_admin()) then
    raise exception 'Only moderators can review verification evidence';
  end if;
  if new.owner_id is distinct from old.owner_id
     or new.property_id is distinct from old.property_id
     or new.storage_path is distinct from old.storage_path
     or new.document_type is distinct from old.document_type
     or new.created_at is distinct from old.created_at then
    raise exception 'Verification evidence details are immutable after submission';
  end if;
  if new.review_status not in ('approved', 'rejected', 'pending') then
    raise exception 'Invalid verification review status';
  end if;
  new.reviewed_by := (select auth.uid());
  new.reviewed_at := now();
  return new;
end;
$$;

drop trigger if exists guard_verification_document_changes_trigger on public.property_verification_documents;
create trigger guard_verification_document_changes_trigger
before insert or update on public.property_verification_documents
for each row execute function public.guard_verification_document_changes();

drop policy if exists "verification docs admin update" on public.property_verification_documents;
create policy "verification docs admin update" on public.property_verification_documents
for update to authenticated
using ((select public.is_aurevia_admin()))
with check ((select public.is_aurevia_admin()));

-- Owners may submit and read their own evidence; only admins may change review status.
-- Keep this bucket private; no anonymous read access is added.
revoke all on public.property_reports, public.property_verification_documents from anon;
revoke delete, truncate, references, trigger on public.property_reports from authenticated;
revoke delete, truncate, references, trigger on public.property_verification_documents from authenticated;
grant select, insert, update on public.property_reports to authenticated;
grant select, insert, update on public.property_verification_documents to authenticated;



-- AUREVIA v0.17.0: private property-video storage with signed playback URLs.
create table if not exists public.property_videos (
  id uuid primary key default gen_random_uuid(),
  property_id uuid not null references public.properties(id) on delete cascade,
  owner_id uuid not null references public.profiles(id) on delete cascade,
  storage_path text not null unique,
  caption text not null default '' check (char_length(caption) <= 240),
  created_at timestamptz not null default now()
);
create index if not exists property_videos_property_created_idx on public.property_videos(property_id, created_at desc);
create index if not exists property_videos_owner_created_idx on public.property_videos(owner_id, created_at desc);
alter table public.property_videos enable row level security;
revoke all on public.property_videos from anon, authenticated;
grant select on public.property_videos to anon, authenticated;
grant insert, delete on public.property_videos to authenticated;
drop policy if exists "property videos public or owner read" on public.property_videos;
create policy "property videos public or owner read" on public.property_videos for select to anon, authenticated using (
  owner_id = (select auth.uid()) or exists (select 1 from public.properties p where p.id = property_id and p.listing_status = 'published' and p.review_status = 'approved') or (select public.is_aurevia_admin())
);
drop policy if exists "property video owner insert" on public.property_videos;
create policy "property video owner insert" on public.property_videos for insert to authenticated with check (
  owner_id = (select auth.uid()) and split_part(storage_path, '/', 1) = (select auth.uid())::text and exists (select 1 from public.properties p where p.id = property_id and p.owner_id = (select auth.uid()))
);
drop policy if exists "property video owner delete" on public.property_videos;
create policy "property video owner delete" on public.property_videos for delete to authenticated using (owner_id = (select auth.uid()) or (select public.is_aurevia_admin()));
insert into storage.buckets (id, name, public, file_size_limit, allowed_mime_types) values ('property-videos', 'property-videos', false, 52428800, array['video/mp4']) on conflict (id) do update set public = false, file_size_limit = 52428800, allowed_mime_types = array['video/mp4'];
drop policy if exists "property video upload own folder" on storage.objects;
create policy "property video upload own folder" on storage.objects for insert to authenticated with check (bucket_id = 'property-videos' and (storage.foldername(name))[1] = (select auth.uid())::text);
drop policy if exists "property video read owner or published listing" on storage.objects;
create policy "property video read owner or published listing" on storage.objects for select to anon, authenticated using (
  bucket_id = 'property-videos' and ((storage.foldername(name))[1] = (select auth.uid())::text or exists (select 1 from public.property_videos v join public.properties p on p.id = v.property_id where v.storage_path = name and p.listing_status = 'published' and p.review_status = 'approved') or (select public.is_aurevia_admin()))
);
drop policy if exists "property video delete own folder" on storage.objects;
create policy "property video delete own folder" on storage.objects for delete to authenticated using (bucket_id = 'property-videos' and ((storage.foldername(name))[1] = (select auth.uid())::text or (select public.is_aurevia_admin())));
