# AUREVIA + Supabase setup

## Current stage
AUREVIA v0.16.0 uses the linked Supabase project for authentication and marketplace features. This guide also documents how to prepare a fresh project from the full schema. Existing projects should apply any migration not already applied.

## 1. Create a Supabase project
1. Open https://supabase.com/dashboard
2. Sign in or create an account.
3. Create a new project and save the database password securely.
4. Wait until the project is ready.

## 2. Apply the database schema
1. Open the project dashboard.
2. Open SQL Editor and create a new query.
3. Open `supabase/schema.sql` from this project.
4. Copy the complete file into the SQL Editor and run it.
5. Review the SQL Editor result for errors before continuing.

The schema creates profiles, properties, property photos, favorites, viewing requests, reports and private verification-document metadata. It enables Row Level Security and creates photo/evidence storage buckets.

## 3. Important security rules
- Never put the Supabase `service_role` or secret key in the Android app.
- The Android client will use the project URL and publishable key only.
- Private ownership/authorization evidence must remain in the private `verification-documents` bucket.
- Public property photos belong in `property-photos`.
- Do not promote any user to admin until the account identity is trusted. The first admin is promoted manually in SQL after registration.
- This is an initial schema, not a completed security audit. RLS policies must be tested before public launch.

## 4. Android compatibility decision
The current AUREVIA starter uses `minSdk 23` and a plain Android Activity to keep compatibility with the phone-based CodeAssist environment. The official Supabase Kotlin client currently documents Android API 26 as its minimum unless core-library desugaring is enabled. We will not add the SDK blindly. First we will confirm the exact Gradle/SDK support in your CodeAssist build, then either configure desugaring or use the documented Supabase REST endpoints through the existing HTTP client approach.

## 5. What is not connected yet
Authentication, listing queries, publishing, photo uploads, appointments, messaging, admin moderation and account synchronization are not connected to the Android app in this version.

## v0.11.0 Property & Room Management

Before using **Manage rooms**, run `migrations/20261031_property_rooms.sql` in the Supabase SQL Editor for the linked project. The migration creates `property_rooms`, enables RLS, grants only the authenticated Data API role, and limits access to the owner of the parent property. It also installs the invoker-rights `set_property_room_status` RPC. No service-role key is used in the Android app.


## v0.16.0 verification & moderation
- The linked project has the `verification_moderation` migration applied.
- For another project, apply `migrations/20261101_verification_moderation.sql` and `migrations/20261101_verification_moderation_privileges.sql` after the base schema and previous feature migrations.
- Verification evidence is uploaded only to the private `verification-documents` bucket.
- Moderator tools require a trusted admin account promoted manually in SQL after account identity is verified.


### v0.17.0 — Property video discovery
For an existing Supabase project, apply `migrations/20261101_property_video_discovery.sql` after the prior migrations. It creates the `property_videos` table, private `property-videos` bucket (MP4 only, 50 MB limit), and owner/publication-aware RLS policies. Video playback uses expiring signed URLs; do not change the bucket to public.
