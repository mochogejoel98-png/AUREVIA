# AUREVIA Supabase security review checklist

This document describes the Stage 4 static checks. It does not certify the live Supabase project.

## Guardrails added

- `scripts/check_supabase_schema.py` scans the base schema and migrations for public tables without an explicit `ENABLE ROW LEVEL SECURITY` statement.
- The check protects the existence of the public/owner property-read policy and its published + approved condition.
- GitHub Actions runs the static check before Android build/lint/unit tests.
- The Android client continues to use a Supabase publishable key; never put a service-role or secret key in an APK.

## Required before production

1. Apply migrations to a disposable/staging Supabase project first, not blindly to the live database.
2. Test each role (`anon`, ordinary authenticated user, property owner, and admin) against read/write/delete scenarios.
3. Confirm private property addresses, tenant records, financial records, and verification documents cannot be read by unrelated users.
4. Confirm storage policies prevent cross-user uploads, downloads, and deletes.
5. Review `SECURITY DEFINER` functions for fixed `search_path`, explicit execution grants, and caller/ownership checks.
6. Do not add live database credentials to GitHub Actions unless a future integration test has a dedicated least-privilege staging credential stored as a repository secret.

## Limitations

The static checker validates that RLS enable statements and selected policy text exist. It does not parse PostgreSQL, execute migrations, simulate JWT roles, or prove every policy is safe. A passing result must be followed by staging database tests.
