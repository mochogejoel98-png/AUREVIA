# AUREVIA v0.18.0 — Multi-Property Management

## Added
- Dedicated Property Portfolio workspace for owners and property managers.
- Portfolio overview metrics for total properties, published listings, drafts, and items awaiting review.
- Live in-screen search by property title or city.
- Status filters for published, draft, pending review, approved, and rejected records.
- Sorting by newest, oldest, property name A–Z, and property name Z–A.
- Property-specific shortcuts to room/unit management, tenants, facilities and map, financial records, verification evidence, and vertical video upload.
- Portfolio entry points from the landlord dashboard and My Properties screen.
- Empty, loading, retry, and no-match states.

## Backend and security
- No database migration was needed: the portfolio uses the existing owner-scoped property query and existing management endpoints.
- Supabase Row Level Security remains the access-control boundary; no service-role key or new privileged endpoint was added.
- Portfolio counts are computed from the records returned by the existing owner query (currently capped at 100 properties).

## Validation
- Source, ZIP integrity, and Android XML structure checks performed before delivery.
- Full Android Gradle build and on-device end-to-end testing were not available in this environment. Test import/build and each property-specific workflow in CodeAssist before relying on this release.
