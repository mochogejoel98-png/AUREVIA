# AUREVIA v1.0.0 — Integration & Release Preparation

## Integrated
- Set the app version to 1.0.0 (versionCode 26) as the first release-candidate milestone.
- Preserved the existing marketplace, owner dashboard, property portfolio, tenant/unit tools, facilities/maps, financial records, appointments, messaging, verification/moderation and video discovery code.
- Disabled Android app-data backup to avoid restoring encrypted session data onto a device where its Android Keystore key may not exist.
- Explicitly disallowed cleartext HTTP traffic; configured app network calls are expected to use HTTPS.
- Added release checklist, manual regression matrix, store-listing draft and privacy-policy template.

## Important limits
- This is a release-preparation build, not a claim of production certification.
- No full Android Gradle build, signed APK/AAB build, or end-to-end device regression run was available in this environment.
- Before publishing, complete the release checklist, replace every privacy-policy placeholder, provide a real support contact and hosted privacy-policy URL, configure release signing securely, and verify current Play Console policy requirements.
- No Supabase schema migration was added. Existing database policies and storage configuration remain responsible for data access.
