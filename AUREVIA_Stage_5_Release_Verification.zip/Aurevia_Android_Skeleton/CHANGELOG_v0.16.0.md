# AUREVIA v0.16.0 — Verification & Moderation

## Added
- Report a published listing with a selected safety/content reason and optional details.
- Submit ownership proof, an authorization letter, an identity document, or other supporting evidence from the system document picker.
- Verification evidence uploads to the private `verification-documents` bucket; the app never makes these files public.
- Owners can see their own verification submission statuses.
- Moderator tools for pending listings, pending verification evidence, and open/reviewing reports.
- Listing approve/reject actions, evidence approve/reject actions, and report workflow actions (reviewing, resolved, dismissed).
- Database audit fields and trigger enforcement for report creation and verification review.

## Security
- Moderation UI is not an authorization boundary; Supabase RLS and database triggers enforce access.
- New reports must reference another user's published and approved listing and start in `open` status.
- Verification metadata must belong to the signed-in property owner, remain pending on insert, and point into that owner's private storage folder. Only admins can update verification review status.
- The app uses the existing publishable key and the signed-in user's session; no service-role key was added.

## Setup / verification notes
- Migrations: `supabase/migrations/20261101_verification_moderation.sql` and `supabase/migrations/20261101_verification_moderation_privileges.sql` (applied to the linked Supabase project for this release).
- Only a trusted account manually promoted to `profiles.account_type = 'admin'` can use the moderator queue. Do not promote untrusted accounts.
- The Android Gradle build and real-device upload/review flows still require testing in CodeAssist.
