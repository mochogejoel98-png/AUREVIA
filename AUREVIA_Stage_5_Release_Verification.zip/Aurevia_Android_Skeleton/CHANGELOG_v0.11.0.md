# AUREVIA v0.11.0 — Property & Room Management

- Added a per-property room inventory workspace reachable from each property card in Landlord DASH.
- Added room creation with unique room number/name, category, monthly rent in KES and optional description.
- Added room status overview and status updates: Available, Reserved, Occupied and Maintenance.
- Added Supabase `property_rooms` migration with unique room numbers per property, non-negative rent validation, RLS and explicit Data API grants.
- Room reads and writes are scoped to the parent property and authenticated owner. The status RPC uses SECURITY INVOKER and remains subject to RLS.
- No tenant assignment, payment, occupancy inference, manager delegation or booking automation is included in this version.

## Setup

Apply `supabase/migrations/20261031_property_rooms.sql` in the Supabase SQL Editor before using Manage rooms. Existing property and appointment data is not modified.

## Verification

Static source checks, XML parsing and ZIP integrity are performed for this package. A full Android Gradle build and live Supabase/device test are not claimed unless separately reported.
