# AUREVIA v0.10.3 — Landlord DASH data-loading fix

- Gate private DASH data requests until the saved Supabase session restore attempt has completed.
- Re-render DASH, Appointments, or My Drafts after session restoration so a request skipped during startup is not left in a permanent loading state.
- Add a secure reconnect-and-refresh action that retries session restoration before reloading private owner records.
- Preserve the existing dashboard UI, Supabase schema, authentication storage, and property records.

## Verification
- ZIP archive integrity checked.
- Android XML resources parsed successfully.
- Gradle version metadata and package identifiers checked.
- Full Android Gradle compilation and on-device Supabase verification were not run in this environment. Please import into CodeAssist and test with the same signed-in account.
