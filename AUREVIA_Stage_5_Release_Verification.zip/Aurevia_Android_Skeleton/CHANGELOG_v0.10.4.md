# AUREVIA v0.10.4 — DASH request-state diagnostics

- Removed silent early exits from the private property and viewing-request loaders.
- If session restoration is incomplete or no access token is available, the dashboard now records and displays a clear sign-in/session error instead of leaving loading placeholders indefinitely.
- Every started request is wrapped defensively and always updates its loading/loaded state on the UI thread.
- Successful and failed requests now trigger a full screen redraw so stale loading cards are replaced by live data, an empty state, or an actionable error.
- Existing Supabase tables, RLS policies, account data, and dashboard styling are preserved.

## Verification
- ZIP integrity checked.
- All Android XML resources parsed successfully.
- Kotlin source edits and Gradle version metadata inspected.
- Full Android Gradle compilation and live-device/Supabase verification were not run in this environment.
