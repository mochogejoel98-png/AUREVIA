# Stage 2 — Testable validation rules

- Extracted property title/location/country-code/coordinate validation into `FormValidation` and wired it into the existing property form.
- Extracted price/currency validation and wired it into the existing listing form.
- Extracted tenant/rent/lease-date validation, including calendar-valid ISO dates, and wired it into the existing tenant form.
- Added JUnit 4 unit tests for valid and invalid property details, optional coordinates, price/currency, tenant details, impossible dates, and lease date ordering.
- Added JUnit 4 test dependency. The tests exercise the same pure validation methods used by the UI; they do not make network calls or touch Supabase.

## Verification status

Static integration checks were performed on the source and test files. A full Gradle/Android build and execution of `testDebugUnitTest` still require a working Gradle installation and Android SDK/CI run; do not treat the suite as passed until that run is green.


## Stage 2.1 — compile-error correction

- Removed a duplicate local `amount` declaration in `showAddTenantDialog`; the rent is parsed only after shared validation succeeds.
- Kept `targetSdk = 35` and the Android 15+ system-bar inset handling. The manifest-merger edge-to-edge message is a warning, not the reported Kotlin compilation error.
- Verification: duplicate declaration checked and `FormValidation.kt` compiled independently with `kotlinc`. A full Android Gradle build remains unverified in this environment.
