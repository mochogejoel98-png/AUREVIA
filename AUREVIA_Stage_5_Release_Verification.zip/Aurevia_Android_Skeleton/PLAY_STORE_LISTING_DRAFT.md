# AUREVIA — Store Listing Draft

## App name
AUREVIA — Property Marketplace

## Short description
Discover properties, connect with owners, and manage property listings in one place.

## Full description
AUREVIA is a property marketplace designed to bring property discovery and owner tools together. Explore available listings, save properties for later, request viewings, and contact property owners through in-app messaging.

Property owners can create and manage listings, organize property portfolios and units, maintain tenant and facility records, track property-related income and expenses, submit verification evidence, and share video tours. Listings and user-submitted content may be subject to review. Availability, property details, ownership and condition should be independently confirmed before making a transaction.

Features available to an account depend on sign-in status, permissions, listing status and the configuration of the service. AUREVIA does not guarantee property availability, ownership, condition, rental income or transaction outcomes.

## Before publishing
- Confirm the final app name and feature claims against the signed build.
- Add a valid support contact and hosted privacy-policy URL.
- Prepare original screenshots and store artwork from the real app.
- Complete content rating, Data safety and any required declarations accurately.
