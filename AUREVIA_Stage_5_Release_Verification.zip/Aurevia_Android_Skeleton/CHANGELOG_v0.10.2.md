# AUREVIA v0.10.2 — Landlord DASH UI refinement

- Reworked the landlord dashboard into a phone-first, white-and-emerald layout.
- Added a landlord welcome panel and direct Add Property / View Appointments actions.
- Added live overview cards for properties, published listings, pending review, drafts and incoming viewing requests.
- Added compact property cards sourced from the signed-in owner's Supabase records.
- Added a pending viewing-request preview with a direct route to the appointment manager.
- Added clear management shortcuts and transparent placeholders for rooms, tenants and finance, which still require dedicated backend records.
- Kept existing Supabase authentication, property retrieval, property draft flow, and viewing appointment operations.
- Changed the header to emerald on landlord screens.

## Verification status

- ZIP archive integrity: checked after packaging.
- XML parsing: checked.
- Source markers and balanced delimiter counts: checked.
- Full Android Gradle compilation and device installation: not run in this environment; verify in Tyron CodeAssist.
