# AUREVIA v0.17.0 — Vertical Video Property Discovery

## Added
- A vertical-format property video discovery screen reachable from Home and Explore.
- Owners can choose an MP4 tour from Android's document picker and add an optional caption.
- Video uploads stream from the selected document rather than loading the whole file into memory; maximum size is 50 MB.
- Video cards show property details and provide explicit play/pause controls; feed videos do not autoplay.
- Videos use a private Supabase Storage bucket and short-lived signed playback URLs.
- Public feed metadata is limited by RLS to properties that are published and approved. Owners can read their own video metadata for draft properties.
- Added the `property_videos` table, owner-scoped upload/delete policies, and indexes.

## Notes
- Only MP4 video is accepted in this release.
- Videos attached to draft, pending, or rejected properties do not appear in public discovery.
- Full Android Gradle build and physical-device playback/upload testing must still be completed in CodeAssist.
