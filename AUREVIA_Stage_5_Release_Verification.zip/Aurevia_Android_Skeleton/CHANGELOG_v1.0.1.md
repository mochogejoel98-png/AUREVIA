# AUREVIA v1.0.1 — Build Fix

- Fixed the multi-property portfolio compile errors by separating the reusable info-card view builder from the helper that adds cards to the current page.
- Kept existing v1.0.0 features and release-preparation documents.
- Updated Android version to 1.0.1 (versionCode 27).
- Added Android 15+ system-bar inset handling while retaining targetSdk 35; validate layout insets on-device before release.
