# AUREVIA v0.13.0 — Facilities and Maps

## Implemented in source
- Property owners can add and remove facilities from the property-specific Facilities & Map screen.
- Facility categories: utilities, security, parking, recreation, connectivity, nearby services, accessibility, and other.
- Facilities are read from Supabase for public listing details; unpublished or unapproved listing facilities are not exposed to public visitors.
- Property creation accepts optional latitude/longitude coordinates with validation; coordinates are saved with the listing.
- Public property details include an Open location in Maps action. Exact coordinates are used when available; otherwise Maps receives a property-name/location search.
- Facilities and coordinates use a new additive Supabase migration. Existing records remain valid because coordinates are nullable.

## Backend
- Migration: `supabase/migrations/20261101_property_facilities_and_map_coordinates.sql`.
- Applied to live Supabase project `muilsyuudpscpvandgnf`; verify status through the SQL/API checks if deploying to another project.
- `property_facilities` has RLS enabled. Public read access is limited to published and approved properties; authenticated insert/update/delete policies require ownership. The read access policy combines owner and public visibility conditions in one policy.

## Validation report
- Source ZIP integrity and XML parsing are checked at packaging time.
- Kotlin structural checks are not a substitute for an Android Gradle build. Build/APK/device testing has not been run in this environment.
- Maps requires a compatible Android maps application; when coordinates are omitted, the app opens a location search rather than claiming a precise pin.
