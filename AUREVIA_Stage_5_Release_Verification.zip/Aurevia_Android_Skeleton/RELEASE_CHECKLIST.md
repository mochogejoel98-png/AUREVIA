# AUREVIA v1.0.0 Release Checklist

This checklist is intentionally not marked complete. A source ZIP is not a signed or store-ready release by itself.

## 1. Build and artifact
- [ ] Import the project in CodeAssist/Android Studio and sync Gradle successfully.
- [ ] Build and install a debug APK on a real Android device.
- [ ] Build a signed release APK or Android App Bundle (AAB).
- [ ] Keep keystore files, passwords, and signing credentials out of the source ZIP and version control.
- [ ] Confirm `applicationId` is `com.aurevia.app`, version name is `1.0.0`, and version code is `26`.
- [ ] Install the release build over the previous version and verify upgrade behavior.
- [ ] Inspect the final artifact and test on the minimum supported Android version (API 23) and a current Android version.

## 2. Authentication and account safety
- [ ] Register, confirm email if enabled, sign in, restart app, refresh session, and sign out.
- [ ] Test expired/invalid sessions and network loss; errors should be recoverable.
- [ ] Verify private screens require sign-in and account-scoped data never appears for another account.
- [ ] Test password reset and account deletion/retention handling; if not implemented, do not advertise these as available.
- [ ] Confirm no service-role or secret Supabase key is bundled. The client publishable key is not a substitute for RLS.

## 3. Marketplace and owner workflows
- [ ] Browse, search, filter, open, and save/unsave a published approved listing.
- [ ] Create a draft, add photos, review it in My Properties, and verify it is not public before approval.
- [ ] Test viewing request create/respond/cancel with two authorized test accounts and an approved listing.
- [ ] Test tenant/unit records, facilities/map coordinates, and financial records with the property owner account.
- [ ] Test private messages with requester and owner accounts, including attempts to access another conversation.
- [ ] Test verification-document upload and moderator review using a trusted admin test account.
- [ ] Test video upload size/type rejection, private signed playback URL, play/pause, and behavior after URL expiry.
- [ ] Test portfolio search, filters, sorting, empty states, and multiple owned properties.

## 4. Supabase and privacy
- [ ] Verify all required migrations are applied to the intended production project.
- [ ] Review RLS policies, grants, storage policies, database advisor findings, Auth settings, backups and recovery.
- [ ] Use only the intended production project URL and client-safe publishable key. Never put service-role/secret keys in the Android app.
- [ ] Host a completed privacy policy and provide its public URL in the store listing.
- [ ] Provide a monitored support contact, data retention/deletion process, and account/data deletion instructions as required by applicable policies and law.
- [ ] Complete Play Console Data safety, content rating, app access instructions, target API and permission declarations truthfully.

## 5. Accessibility, stability and store assets
- [ ] Check small screens, large text, keyboard navigation, contrast, touch target sizes and screen-reader labels.
- [ ] Test slow/offline connections, server errors, empty catalogue, expired signed URLs and interrupted uploads.
- [ ] Check log output for tokens, passwords, private addresses, message contents or document URLs.
- [ ] Prepare original app icon, screenshots, feature graphic and final store description.
- [ ] Run a final regression test on the exact signed artifact uploaded to internal testing.

## Release gate
Do not publish to the public track until the required checks above have passed and the privacy/support/store information is complete. Some controls, policies and workflows may need additional implementation or manual configuration; this checklist does not imply they are already implemented.
