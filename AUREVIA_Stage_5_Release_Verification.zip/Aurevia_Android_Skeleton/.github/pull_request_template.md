## Summary

<!-- Describe the user-visible change and why it is needed. -->

## Verification

- [ ] `assembleDebug` succeeds
- [ ] `lintDebug` reviewed
- [ ] `testDebugUnitTest` succeeds
- [ ] Tested on an Android device when UI/runtime behavior changes
- [ ] Supabase schema or migrations reviewed separately before applying to a live project
- [ ] No service-role keys, signing keys, passwords, or private tokens added

## Risk / migration notes

<!-- Explain compatibility concerns, data changes, or rollout requirements. -->
